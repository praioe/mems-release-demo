import './input-check.css'
import { createBoundaryPreview } from './boundary-view.ts'
import { inspectGds, MAX_GDS_BYTES } from './gds-inspect.ts'
import type { GdsSummary } from './gds-inspect.ts'

const app = document.querySelector<HTMLDivElement>('#app')
if (!app) throw new Error('앱을 표시할 #app 요소가 없습니다.')
app.innerHTML = `
  <main>
    <header>
      <p class="eyebrow">MEMS RELEASE · 입력 경로 점검</p>
      <h1>GDS 파일을 확인합니다.</h1>
      <p>브라우저에서 실제 파일을 읽고, 원본 바이트를 그대로 다시 내려받습니다.</p>
      <p class="scope">개발용 입출력 점검 화면입니다. 로컬 모드에서는 KLayout 별도 읽기와 도면 열기를 실행합니다. 홀 배치·보정·설계 규칙 검사는 아직 미구현입니다.</p>
    </header>
    <section aria-labelledby="file-title">
      <h2 id="file-title">입력 파일</h2>
      <label for="gds-file">GDS 파일 선택 <span>(최대 16 MiB)</span></label>
      <input id="gds-file" type="file" accept=".gds,.gds2">
      <p id="status" role="status" aria-live="polite">nist_roundtrip.gds를 선택해 주세요.</p>
    </section>
    <section id="boundary-preview" hidden aria-label="선택 셀 도면"></section>
    <section id="summary" hidden aria-labelledby="summary-title">
      <h2 id="summary-title">읽은 파일 정보</h2>
      <dl id="facts"></dl>
      <h3>파일 식별값 · SHA-256</h3>
      <code id="fingerprint"></code>
      <p id="comparison"></p>
      <div class="actions">
        <a id="download" download>원본 그대로 다운로드</a>
        <p>수정한 GDS가 아닙니다. 불러온 원본의 바이트를 보존한 복사본입니다.</p>
      </div>
      <div class="external-run" aria-labelledby="external-title">
        <h3 id="external-title">외부 KLayout 연결</h3>
        <p id="runtime-status" role="status">로컬 연결 상태를 확인하고 있습니다.</p>
        <button id="klayout-run" type="button" disabled>KLayout에서 읽고 열기</button>
        <p id="klayout-status" role="status" aria-live="polite">파일을 읽은 뒤 실행할 수 있습니다.</p>
        <dl id="klayout-facts"></dl>
        <a id="klayout-report" hidden>실제 KLayout 읽기 보고서 다운로드</a>
        <p class="scope">이번 동작은 실제 파일의 별도 읽기·정보 비교입니다. 도형 DRC 통과나 홀 보정 완료를 의미하지 않습니다.</p>
      </div>
      <details open><summary>레이어 목록</summary>
        <p>layer / datatype입니다. TEXT 등은 해당 type 값을 표시합니다.</p>
        <div class="table-wrap"><table><thead><tr><th>레이어 / type</th><th>저장된 요소 수</th></tr></thead><tbody id="layers"></tbody></table></div>
      </details>
      <details><summary id="cell-heading">셀 목록</summary><ul id="cells"></ul></details>
      <details><summary>요소 종류별 개수</summary><dl id="elements"></dl></details>
      <ul id="notes" class="notes"></ul>
    </section>
  </main>
`
function get<T extends HTMLElement>(id: string): T {
  const node = document.getElementById(id)
  if (!node) throw new Error('화면 요소를 찾지 못했습니다: ' + id)
  return node as T
}
function fact(target: HTMLElement, name: string, value: string) {
  const dt = document.createElement('dt')
  const dd = document.createElement('dd')
  dt.textContent = name
  dd.textContent = value
  target.append(dt, dd)
}
const boundaryPreview = createBoundaryPreview(get('boundary-preview'))
const input = get<HTMLInputElement>('gds-file')
const status = get('status')
const summary = get('summary')
const link = get<HTMLAnchorElement>('download')
let revision = 0
let objectUrl: string | null = null
let lastFingerprint: string | null = null
let retainedBuffer: ArrayBuffer | null = null
let retainedInfo: GdsSummary | null = null
let retainedHash: string | null = null
let runtimeToken: string | null = null
let localBusy = false
const localButton = get<HTMLButtonElement>('klayout-run')
function refreshLocalButton() {
  localButton.disabled = !runtimeToken || !retainedBuffer || localBusy
}
function resetLocalResult() {
  get('klayout-facts').replaceChildren()
  get('klayout-report').hidden = true
  get('klayout-status').textContent = '파일을 읽은 뒤 실행할 수 있습니다.'
}
async function discoverLocalRuntime() {
  try {
    const response = await fetch('/api/runtime', { cache: 'no-store' })
    if (!response.ok || !response.headers.get('content-type')?.includes('application/json')) throw new Error('로컬 실행 도우미가 연결되지 않았습니다.')
    const data = await response.json() as { mode?: string; token?: string; klayoutFound?: boolean; error?: string }
    if (data.mode !== 'local-klayout-read' || !data.token || !data.klayoutFound) throw new Error(data.error || 'KLayout 연결 설정을 확인해 주세요.')
    runtimeToken = data.token
    get('runtime-status').textContent = '로컬 실행 도우미 연결됨 · KLayout 경로 확인됨'
  } catch (error) {
    runtimeToken = null
    get('runtime-status').textContent = '브라우저 입력 점검 모드입니다. KLayout 연결은 start-local.cmd로 여는 로컬 모드에서 사용할 수 있습니다. ' + (error instanceof Error ? error.message : '')
  }
  refreshLocalButton()
}
function clearDownload() {
  if (objectUrl) URL.revokeObjectURL(objectUrl)
  objectUrl = null
  link.removeAttribute('href')
}
function showResult(info: GdsSummary, file: File, hash: string, bytes: ArrayBuffer) {
  const facts = get('facts')
  facts.replaceChildren()
  fact(facts, '파일', file.name)
  fact(facts, '크기', file.size.toLocaleString('ko-KR') + ' bytes')
  fact(facts, '라이브러리', info.library)
  fact(facts, 'DBU', Number(info.dbuMicrometers.toPrecision(12)).toString() + ' µm / DBU')
  fact(facts, '사용자 단위', Number(info.userUnitMicrometers.toPrecision(12)).toString() + ' µm')
  fact(facts, '셀 수', info.cells.length.toLocaleString('ko-KR'))
  fact(facts, '최상위 셀', info.topCells.join(', ') || '없음 · 참조 구조 추가 확인 필요')
  fact(facts, '레이어 수', info.layers.length.toString())
  fact(facts, '레코드 수', info.recordCount.toLocaleString('ko-KR'))
  if (info.paddingBytes) fact(facts, '끝부분 0 패딩', info.paddingBytes + ' bytes')
  get('fingerprint').textContent = hash
  get('comparison').textContent = lastFingerprint
    ? (lastFingerprint === hash ? '직전에 읽기에 성공한 파일과 SHA-256이 같습니다.' : '직전에 읽기에 성공한 파일과 SHA-256이 다릅니다.')
    : '다운로드한 파일을 다시 선택하면 직전 파일과 식별값을 비교합니다.'
  lastFingerprint = hash

  const layers = get('layers')
  layers.replaceChildren()
  for (const item of info.layers) {
    const tr = document.createElement('tr')
    for (const value of [item.layer + '/' + item.datatype, item.elements.toLocaleString('ko-KR')]) {
      const td = document.createElement('td')
      td.textContent = value
      tr.append(td)
    }
    layers.append(tr)
  }
  const cells = get('cells')
  cells.replaceChildren()
  for (const cell of info.cells) {
    const li = document.createElement('li')
    li.textContent = cell.name
    cells.append(li)
  }
  get('cell-heading').textContent = '셀 목록 · ' + info.cells.length
  const elements = get('elements')
  elements.replaceChildren()
  for (const [name, count] of Object.entries(info.elements)) fact(elements, name, count.toLocaleString('ko-KR'))
  const notes = get('notes')
  notes.replaceChildren()
  for (const text of info.notes) {
    const li = document.createElement('li')
    li.textContent = text
    notes.append(li)
  }
  objectUrl = URL.createObjectURL(new Blob([bytes], { type: 'application/octet-stream' }))
  link.href = objectUrl
  link.download = file.name.replace(/\.(gds|gds2)$/i, '') + '_io_check.gds'
  retainedBuffer = bytes
  retainedInfo = info
  retainedHash = hash
  get('klayout-status').textContent = '이 파일로 실제 KLayout 읽기를 실행할 수 있습니다.'
  refreshLocalButton()
  summary.hidden = false
  boundaryPreview.load(bytes, hash, file.name)
}
input.addEventListener('change', async () => {
  const current = ++revision
  boundaryPreview.clear()
  clearDownload()
  retainedBuffer = null
  retainedInfo = null
  retainedHash = null
  resetLocalResult()
  refreshLocalButton()
  summary.hidden = true
  status.dataset.state = 'reading'
  const file = input.files?.[0]
  if (!file) {
    status.textContent = 'GDS 파일을 선택해 주세요.'
    return
  }
  try {
    if (file.size > MAX_GDS_BYTES) throw new Error('현재 점검은 16 MiB 이하 파일만 지원합니다.')
    status.textContent = file.name + ' 파일을 읽고 있습니다.'
    const buffer = await file.arrayBuffer()
    if (current !== revision) return
    const info = inspectGds(new Uint8Array(buffer))
    const digest = await crypto.subtle.digest('SHA-256', buffer)
    if (current !== revision) return
    const hash = [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('')
    showResult(info, file, hash, buffer)
    status.dataset.state = 'ready'
    status.textContent = '기본 정보 읽기 완료 · 도형·설계 규칙 검사는 미실행'
  } catch (error) {
    if (current !== revision) return
    clearDownload()
    summary.hidden = true
    status.dataset.state = 'error'
    status.textContent = error instanceof Error ? error.message : '파일을 읽지 못했습니다.'
  }
})
interface ExternalResult {
  jobId: string
  elapsedMs: number
  inputFileName: string
  sourceSha256: string
  guiOpenRequested: boolean
  guiWarning: string | null
  report: {
    scope: string
    klayoutVersion: string
    sourceSha256: string
    dbuMicrometers: number
    cells: string[]
    topCells: string[]
    layers: Array<{ layer: number; datatype: number; elements: number }>
    designRulesChecked: boolean
  }
}
localButton.addEventListener('click', async () => {
  if (!runtimeToken || !retainedBuffer || !retainedInfo || !retainedHash || localBusy) return
  const info = retainedInfo
  const hash = retainedHash
  localBusy = true
  input.disabled = true
  refreshLocalButton()
  resetLocalResult()
  get('klayout-status').textContent = '실제 GDS를 로컬 작업 폴더에 전달하고 KLayout 읽기 프로세스를 실행하고 있습니다.'
  try {
    const response = await fetch('/api/klayout/read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream', 'X-Mems-Token': runtimeToken, 'X-Mems-Sha256': hash },
      body: retainedBuffer,
    })
    const payload: unknown = await response.json()
    if (!response.ok) throw new Error((payload as { error?: string }).error || 'KLayout 읽기 요청을 완료하지 못했습니다.')
    const result = payload as ExternalResult
    if (result.report.scope !== 'file_read_and_metadata_only' || result.report.designRulesChecked !== false || result.sourceSha256 !== hash || result.report.sourceSha256 !== hash) throw new Error('KLayout 보고서가 이번 파일의 읽기 결과와 일치하지 않습니다.')
    const sameCells = JSON.stringify([...result.report.cells].sort()) === JSON.stringify(info.cells.map(cell => cell.name).sort())
    const sameTop = JSON.stringify([...result.report.topCells].sort()) === JSON.stringify([...info.topCells].sort())
    const sameLayers = JSON.stringify(result.report.layers) === JSON.stringify(info.layers)
    const sameUnit = Math.abs(result.report.dbuMicrometers - info.dbuMicrometers) <= Math.abs(info.dbuMicrometers) * 1e-12
    const matches = sameCells && sameTop && sameLayers && sameUnit
    const facts = get('klayout-facts')
    fact(facts, '작업 ID', result.jobId)
    fact(facts, '실행 도구', result.report.klayoutVersion)
    fact(facts, '셀 / 레이어', result.report.cells.length + ' / ' + result.report.layers.length)
    fact(facts, '파일 식별값', '브라우저·저장 파일·KLayout 보고서 일치')
    fact(facts, '기본 정보 비교', matches ? '셀·최상위 셀·레이어별 개수·DBU 일치' : '차이 있음 · 보고서 확인 필요')
    fact(facts, 'KLayout 대상 파일', result.inputFileName)
    fact(facts, '실제 읽기 시간', (result.elapsedMs / 1000).toFixed(2) + ' s')
    fact(facts, '설계 규칙 검사', '미실행')
    const reportLink = get<HTMLAnchorElement>('klayout-report')
    reportLink.href = '/api/jobs/' + encodeURIComponent(result.jobId) + '/report'
    reportLink.download = 'klayout-report.json'
    reportLink.hidden = false
    get('klayout-status').textContent = (matches ? 'KLayout 별도 읽기 및 기본 정보 비교 완료. ' : 'KLayout 별도 읽기 완료 · 기본 정보 차이가 있어 확인이 필요합니다. ') + (result.guiOpenRequested ? '도면 창 열기 요청을 전달했습니다. 실제 KLayout 창을 확인해 주세요.' : (result.guiWarning || '도면 창 열기 요청은 완료하지 못했습니다.'))
  } catch (error) {
    get('klayout-status').textContent = '외부 읽기 실패 · ' + (error instanceof Error ? error.message : '상세 오류를 확인해 주세요.')
  } finally {
    localBusy = false
    input.disabled = false
    refreshLocalButton()
  }
})
void discoverLocalRuntime()
window.addEventListener('pagehide', () => { clearDownload(); boundaryPreview.clear() })

