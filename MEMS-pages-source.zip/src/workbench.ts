import './studio.css'
import './studio-design.css'
import {base64,fetchJob,stageList,localTime} from './pipeline-client.ts'
import type {PipelineJob} from './pipeline-client.ts'
import {studioTemplate} from './studio-template.ts'
import {icon} from './icons.ts'
import {createBoundaryPreview} from './boundary-view.ts'
import {inspectGds,MAX_GDS_BYTES} from './gds-inspect.ts'
import {buildChecker,pairBox,rectPoints,validateInput} from './design-engine.ts'
import {createOutput} from './gds-output.ts'
import type {BoundaryCell,BoundaryShape,Bounds,Point} from './boundary-data.ts'
import type {DesignInput,DesignResult,Pair,Protection,Rules} from './design-engine.ts'
import {releaseDemo} from './release-demo.ts'
import {releaseGrid,releaseSettings,solveReleaseReference} from './release-grid.ts'
import type {ReleaseGrid} from './release-grid.ts'
const defaults:Rules={lowerSize:3,upperSize:7,spacing:3,enclosure:2,boundaryGap:1,protectGap:1,pitch:15,grid:1,searchRadius:20}
const labels=['아래 홀 크기','위 홀 크기','홀 간격','둘러쌈','구조 경계 여유','보호 경계 여유','배치 피치','탐색 그리드','탐색 반경']
export function mountWorkbench(root:HTMLElement,onHome:()=>void){
root.innerHTML=studioTemplate(defaults,labels)
root=root.querySelector<HTMLElement>('.studio')!
const el=<T extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id) as T
const f=(id:string)=>el<HTMLInputElement>(id),s=(id:string)=>el<HTMLSelectElement>(id),b=(id:string)=>el<HTMLButtonElement>(id)
const say=(t:string)=>{el('status').textContent=t},error=(e:unknown)=>e instanceof Error?e.message:String(e)
let source:Uint8Array|null=null,hash='',name='',dbu=.001,cell:BoundaryCell|null=null,selected:BoundaryShape|null=null
let pairs:Pair[]=[],before:Pair[]=[],protection:Protection[]=[],result:DesignResult|null=null,task:DesignInput|null=null,out:ReturnType<typeof createOutput>|null=null
let worker:Worker|null=null,run=0,revision=0,dirty=true,token='',externalBusy=false,drawing=false,start:Point|null=null,rubber:Bounds|null=null,demoPending=false,pending:Project|null=null
let pipelineId='',pipelinePending=false,pipelineRevision=0
let releasePending=false
let demonstration:ReturnType<typeof releaseDemo>|null=null
let projection:{grid:ReleaseGrid;values:number[];conflicts:Set<string>}|null=null
const ids=[...Object.keys(defaults).map(k=>'r-'+k),'lower','upper','layer0','layer1',...['minX','minY','maxX','maxY'].map(k=>'roi-'+k)]
interface Snapshot{pairs:Pair[];protection:Protection[];fields:Record<string,string>}
interface Project{schema:string;sourceSha256:string;cellName:string;snapshot:Snapshot}
const history:Snapshot[]=[],future:Snapshot[]=[],urls:string[]=[]
const snap=():Snapshot=>({pairs:structuredClone(pairs),protection:structuredClone(protection),fields:Object.fromEntries(ids.map(id=>[id,(el(id) as HTMLInputElement).value]))})
function remember(){history.push(snap());if(history.length>30)history.shift();future.length=0}
function restore(v:Snapshot){pairs=structuredClone(v.pairs);protection=structuredClone(v.protection);for(const[k,value]of Object.entries(v.fields))if(ids.includes(k))(el(k) as HTMLInputElement).value=value;changed();lists()}
function actions(){const busy=!!worker||externalBusy;for(const node of el('viewport').querySelectorAll<HTMLInputElement|HTMLSelectElement>('input,select')){if(busy){if(node.dataset.wasDisabled===undefined)node.dataset.wasDisabled=String(node.disabled);node.disabled=true}else if(node.dataset.wasDisabled!==undefined){node.disabled=node.dataset.wasDisabled==='true';delete node.dataset.wasDisabled}}for(const x of root.querySelectorAll<HTMLInputElement|HTMLButtonElement|HTMLSelectElement>('.design-tools input,.design-tools button,.design-tools select,.file-actions input,.file-actions button,#empty-open,#source-demo,#studio-home,#file,#project,#demo'))x.disabled=busy;for(const id of ['generate','check','repair'])b(id).disabled=busy||!cell;for(const id of ['gds','report','external'])b(id).disabled=busy||dirty||!out;b('cancel').disabled=!worker&&!pipelineId&&!pipelinePending;b('original').disabled=!source||busy;b('save-project').disabled=!source||busy;b('undo').disabled=!history.length||busy;b('redo').disabled=!future.length||busy;b('external').disabled=busy||dirty||!out||!token;syncUI()}
function changed(){projection=null;dirty=true;out=null;result=null;task=null;say(cell?'재검사 필요':'도면 대기');el('runtime').textContent=token?'연결됨':'로컬 도우미 미연결';el('runtime').dataset.state=token?'connected':'offline';el('summary').textContent='재검사 필요';el('conflicts').replaceChildren();el('trace').textContent='';el('external-status').textContent='외부 검사 미실행 · 입력 변경';el('external-report').hidden=true;actions();overlay()}
function db(v:string){const n=Number(v)/dbu,q=Math.round(n);if(!v.trim()||!Number.isFinite(n)||Math.abs(n-q)>1e-7||!Number.isSafeInteger(q))throw Error('µm 값을 파일 DBU의 정확한 배수로 입력해 주세요.');return q}
function input(mode:DesignInput['mode']):DesignInput{if(!cell)throw Error('셀 선택 필요');const rules=Object.fromEntries(Object.keys(defaults).map(k=>[k,db(f('r-'+k).value)])) as unknown as Rules;const roi=Object.fromEntries(['minX','minY','maxX','maxY'].map(k=>[k,db(f('roi-'+k).value)])) as unknown as Bounds;const value:DesignInput={cell,structures:[s('lower').value,s('upper').value],holeLayers:[f('layer0').value.trim(),f('layer1').value.trim()],rules,roi,protected:structuredClone(protection),baseline:structuredClone(pairs),mode};validateInput(value);return value}
function download(v:Uint8Array|string,file:string,type:string){const u=URL.createObjectURL(new Blob([typeof v==='string'?v:Uint8Array.from(v).buffer],{type})),a=document.createElement('a');a.href=u;a.download=file;a.click();urls.push(u);if(urls.length>10)URL.revokeObjectURL(urls.shift()!)}
const json=(v:unknown,file:string)=>download(JSON.stringify(v,null,2),file,'application/json')
function node(tag:string,attrs:Record<string,string>,parent:Element){const n=document.createElementNS('http://www.w3.org/2000/svg',tag);for(const[k,v]of Object.entries(attrs))n.setAttribute(k,v);parent.append(n);return n}
function overlay(){for(const node of root.querySelectorAll<SVGPolygonElement>('#preview-shapes > polygon[data-id]')){node.classList.toggle('assigned-lower',node.dataset.id===s('lower').value);node.classList.toggle('assigned-upper',node.dataset.id===s('upper').value)}const group=el('viewport').querySelector('#preview-shapes');if(!group)return;group.querySelector('#design-overlay')?.remove();const g=node('g',{id:'design-overlay'},group),mode=s('compare').value;
if(projection){const {grid,values}=projection;grid.cells.forEach((c,i)=>{
  const shortage=1-values[i]!
  if(shortage<.65)return
  node('rect',{x:String(c.x-grid.step/2),y:String(c.y-grid.step/2),width:String(grid.step),height:String(grid.step),fill:'#ff9d45','fill-opacity':String(.10+.28*(shortage-.65)/.35),'pointer-events':'none'},g)
})}
const draw=(items:Pair[],old:boolean)=>{for(const p of items)for(const i of [1,0]as const){let size:number;try{size=task?(i===0?task.rules.lowerSize:task.rules.upperSize):db(f('r-'+(i===0?'lowerSize':'upperSize')).value)}catch{continue}size=i===0?(p.lowerSize??size):(p.upperSize??size);const n=node('polygon',{points:rectPoints(pairBox(p,size)).map(v=>v.join(',')).join(' '),class:old?'old-hole':i===0?'lower-hole':'upper-hole','data-pair':p.id},g);if(p.locked)n.classList.add('locked');if(s('pair').value===p.id)n.classList.add('chosen');if(projection?.conflicts.has(p.id)||result?.conflicts.some(c=>c.pairId===p.id))n.classList.add('violating')}};if(mode!=='after')draw(before,true);if(mode!=='before')draw(pairs,false);for(const p of protection)node('polygon',{points:p.points.map(v=>v.join(',')).join(' '),class:'protected-region'},g);if(rubber)node('polygon',{points:rectPoints(rubber).map(v=>v.join(',')).join(' '),class:'protected-region'},g)}
function choose(id:string){s('pair').value=id;f('lock').checked=pairs.find(p=>p.id===id)?.locked??false;overlay()}
function lists(){const old=s('pair').value;s('pair').replaceChildren(new Option('선택 없음',''));for(const p of pairs)s('pair').append(new Option(p.id+' · '+(p.x*dbu).toFixed(3)+','+(p.y*dbu).toFixed(3)+(p.locked?' · 잠금':''),p.id));el('protections').replaceChildren();for(const[index,p]of protection.entries()){const li=document.createElement('li'),remove=document.createElement('button');li.textContent='보호 영역 '+(index+1)+' ';li.title=p.id;remove.textContent='삭제';remove.onclick=()=>{remember();protection=protection.filter(v=>v.id!==p.id);changed();lists()};li.append(remove);el('protections').append(li)}choose(old)}
function fit(){if(!cell)return;const a=cell.boundaries.find(v=>v.id===s('lower').value),c=cell.boundaries.find(v=>v.id===s('upper').value);if(!a||!c)return;for(const[k,v]of Object.entries({minX:Math.max(a.bounds.minX,c.bounds.minX),minY:Math.max(a.bounds.minY,c.bounds.minY),maxX:Math.min(a.bounds.maxX,c.bounds.maxX),maxY:Math.min(a.bounds.maxY,c.bounds.maxY)}))f('roi-'+k).value=String(Number((v*dbu).toPrecision(12)))}
const preview=createBoundaryPreview(el('viewport'),{onLoading(){cell=null;changed()},onSelect(shape){selected=shape;el('selection').textContent=shape?shape.layer+'/'+shape.datatype+' · '+shape.points.length+'개 꼭짓점':'선택 없음'},onCell(next,unit){cell=next;dbu=unit;pairs=[];before=[];protection=[];history.length=future.length=0;for(const id of ['lower','upper']){s(id).replaceChildren(new Option('구조 선택',''));for(const[index,shape]of next.boundaries.entries())s(id).append(new Option(shape.layer+'/'+shape.datatype+' · '+(shape.sourceCell??next.name)+' · #'+(index+1),shape.id))}if(demoPending){demoPending=false;f('r-pitch').value='30';s('lower').value=next.boundaries.find(v=>v.layer===100)?.id??'';s('upper').value=next.boundaries.find(v=>v.layer===101)?.id??'';fit()}if(releasePending&&next.name==='PLATES'){
  releasePending=false
  demonstration=releaseDemo(next,dbu)
  const sample=demonstration.repair
  pairs=structuredClone(sample.baseline)
  protection=structuredClone(demonstration.before)
  for(const [k,v] of Object.entries(sample.rules))f('r-'+k).value=String(Number((v*dbu).toPrecision(12)))
  for(const [k,v] of Object.entries(sample.roi))f('roi-'+k).value=String(Number((v*dbu).toPrecision(12)))
  s('lower').value=sample.structures[0];s('upper').value=sample.structures[1]
  changed();lists()
  b('move-demo-protection').hidden=false
  showPanel('protection')
  say('63쌍과 중심 잠금 준비 · 시연 보호 영역을 이동하세요.')
  wire();return
}if(pending?.cellName===next.name){const p=pending;pending=null;restore(p.snapshot)}else changed();lists();wire()}})
const releaseDemoButton=document.createElement('button')
releaseDemoButton.id='release-demo'
releaseDemoButton.textContent='보호 영역 보정 시연'
root.querySelector('.navigator-bottom')!.prepend(releaseDemoButton)
const moveDemoButton=document.createElement('button')
moveDemoButton.id='move-demo-protection'
moveDemoButton.className='full-button'
moveDemoButton.textContent='시연 보호 영역 이동'
moveDemoButton.hidden=true
el('protections').after(moveDemoButton)
releaseDemoButton.onclick=async()=>{
  if(worker||externalBusy)return
  try{
    const response=await fetch(import.meta.env.BASE_URL+'demo-paired.gds')
    if(!response.ok)throw Error('시연 입력 GDS 읽기 실패')
    demoPending=true;releasePending=true
    await load(new File([await response.arrayBuffer()],'synthetic-paired-plates.gds'))
  }catch(e){releasePending=false;say(error(e))}
}
moveDemoButton.onclick=()=>{
  if(!demonstration||worker||externalBusy)return
  remember()
  protection=structuredClone(demonstration.repair.protected)
  changed();lists()
  try{
    const value=input('repair'), check=buildChecker(value)
    const conflicts=new Set(pairs.filter(pair=>check(pair,pairs).length).map(pair=>pair.id))
    const grid=releaseGrid(value,dbu)
    const field=solveReleaseReference(grid,pairs,value.rules.lowerSize,releaseSettings.diffusionLengthUm)
    projection={grid,values:field.values,conflicts}
    overlay()
    say(`보호 영역 이동 · 충돌 ${conflicts.size}쌍 · 주황색은 공급 부족도 ≥ 0.65 · 국소 보정을 실행하세요.`)
  }catch(e){say(error(e))}
}
function wire(){const canvas=el('viewport').querySelector<SVGSVGElement>('svg')!;if(canvas.dataset.wired)return;canvas.dataset.wired='1';canvas.addEventListener('pointermove',e=>{const p=new DOMPoint(e.clientX,e.clientY).matrixTransform(canvas.getScreenCTM()!.inverse());el('cursor-position').textContent='X '+(p.x*dbu).toFixed(3)+'   Y '+(-p.y*dbu).toFixed(3)});const point=(e:PointerEvent):Point=>{const p=new DOMPoint(e.clientX,e.clientY).matrixTransform(canvas.getScreenCTM()!.inverse());return[Math.round(p.x),Math.round(-p.y)]};canvas.addEventListener('pointerdown',e=>{if(!drawing||worker||externalBusy)return;e.stopImmediatePropagation();e.preventDefault();start=point(e);canvas.setPointerCapture(e.pointerId)},true);canvas.addEventListener('pointermove',e=>{if(!start)return;e.stopImmediatePropagation();const p=point(e);rubber={minX:Math.min(start[0],p[0]),minY:Math.min(start[1],p[1]),maxX:Math.max(start[0],p[0]),maxY:Math.max(start[1],p[1])};overlay()},true);canvas.addEventListener('pointerup',e=>{if(!start)return;e.stopImmediatePropagation();if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);if(rubber&&rubber.minX<rubber.maxX&&rubber.minY<rubber.maxY){remember();protection.push({id:'PROTECT-'+crypto.randomUUID().slice(0,8),points:rectPoints(rubber)});changed();lists()}start=null;rubber=null;drawing=false;b('draw').innerHTML=icon('draw')+'사각형 그리기';b('draw').setAttribute('aria-pressed','false');overlay()},true);canvas.addEventListener('pointercancel',()=>{start=null;rubber=null;overlay()});canvas.addEventListener('click',e=>{const id=(e.target as Element).closest('[data-pair]')?.getAttribute('data-pair');if(id){choose(id);showPanel('protection')}})}
async function load(file:File){if(worker||externalBusy)return;const rev=++revision;demonstration=null;moveDemoButton.hidden=true;source=null;cell=null;out=null;pairs=[];before=[];result=null;hash='';preview.clear();actions();try{if(file.size>MAX_GDS_BYTES)throw Error('파일 한도 16 MiB');const bytes=new Uint8Array(await file.arrayBuffer()),info=inspectGds(bytes),digest=await crypto.subtle.digest('SHA-256',bytes);if(rev!==revision)return;source=bytes;hash=Array.from(new Uint8Array(digest)).map(v=>v.toString(16).padStart(2,'0')).join('');name=file.name;dbu=info.dbuMicrometers;el('file-status').textContent=name+' · '+bytes.length+' bytes · DBU '+dbu+' µm · SHA-256 '+hash;preview.load(Uint8Array.from(bytes).buffer,hash,name);if(demoPending){const timer=setInterval(()=>{if(rev!==revision){clearInterval(timer);return}const menu=root.querySelector<HTMLSelectElement>('#preview-cell');if(menu&&!menu.disabled){clearInterval(timer);preview.selectCell('PLATES')}},50);setTimeout(()=>clearInterval(timer),10000)}say('셀 선택');actions()}catch(e){demoPending=false;el('file-status').textContent='읽기 실패 · '+error(e);actions()}}
f('file').onchange=()=>{const file=f('file').files?.[0];if(file)void load(file)}
b('demo').onclick=async()=>{try{const r=await fetch(import.meta.env.BASE_URL+'demo-paired.gds');if(!r.ok)throw Error('합성 예제 읽기 실패');demoPending=true;await load(new File([await r.arrayBuffer()],'synthetic-paired-plates.gds'))}catch(e){say(error(e))}}
b('original').onclick=()=>{if(source)download(source,name.replace(/\.gds2?$/i,'')+'_original.gds','application/octet-stream')}
for(const id of ids)el(id).addEventListener('focusin',()=>{if(!worker&&!externalBusy)remember()});
for(const id of ids)el(id).addEventListener('change',()=>{changed();if(id==='lower'||id==='upper')fit()})
for(const[id,target]of [['assign-lower','lower'],['assign-upper','upper']]as const)b(id).onclick=()=>{if(!selected)return say('먼저 도형을 선택해 주세요.');remember();s(target).value=selected.id;fit();changed()}
b('fit-roi').onclick=()=>{remember();fit();changed()}
b('protect').onclick=()=>{if(!selected)return say('보호할 도형을 선택해 주세요.');remember();protection.push({id:'PROTECT-'+crypto.randomUUID().slice(0,8),points:structuredClone(selected.points)});changed();lists()}
b('draw').onclick=()=>{drawing=!drawing;b('draw').innerHTML=icon('draw')+(drawing?'그리기 취소':'사각형 그리기');b('draw').setAttribute('aria-pressed',String(drawing));say(drawing?'도면에서 드래그하세요.':'그리기 취소')}
s('pair').onchange=()=>choose(s('pair').value)
f('lock').onchange=()=>{const p=pairs.find(v=>v.id===s('pair').value);if(p){remember();p.locked=f('lock').checked;changed();lists()}}
s('compare').onchange=overlay
const ruleDescriptions:Record<string,string>={GRID:'그리드 불일치',ROI_CENTER:'중심 ROI 이탈',SIZE_SETTING:'요청 크기 불일치',ENCLOSURE:'둘러쌈 위반',LOWER_CONTAINMENT:'아래 구조 포함·경계 여유',UPPER_CONTAINMENT:'위 구조 포함·경계 여유',PROTECTION:'보호 영역 침범',EXISTING_HOLE_SPACING:'원본 홀과 간격 부족',PAIR_SPACING:'생성 쌍 사이 간격 부족',NO_MANAGED_PAIRS:'배치 가능한 홀 쌍 없음'}
b('clear').onclick=()=>{remember();before=structuredClone(pairs);pairs=[];changed();lists()}
b('undo').onclick=()=>{const v=history.pop();if(v){future.push(snap());restore(v)}}
b('redo').onclick=()=>{const v=future.pop();if(v){history.push(snap());restore(v)}}
function display(){if(!result)return;el('summary').textContent=result.status==='feasible'?'선택 범위 조건 충족':'미해결 충돌 '+result.conflicts.length+'건';el('metric-pairs').textContent=String(pairs.length);el('metric-moved').textContent=String(result.changes.filter(c=>c.kind==='moved').length);el('metric-conflicts').textContent=String(result.conflicts.length);showPanel('result');const table=document.createElement('table');el('conflicts').replaceChildren(table);for(const c of result.conflicts.slice(0,200)){const tr=document.createElement('tr');for(const t of [c.pairId,(ruleDescriptions[c.rule]??c.rule)+' ['+c.rule+']',(c.x*dbu).toFixed(3)+','+(c.y*dbu).toFixed(3)+' µm',c.related??'']){const td=document.createElement('td');td.textContent=t;tr.append(td)}tr.tabIndex=0;tr.setAttribute('role','button');tr.setAttribute('aria-label',c.pairId+' 충돌 위치');tr.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();tr.click()}};tr.onclick=()=>{choose(c.pairId);preview.focus(pairBox({id:'',x:c.x,y:c.y,locked:false},Math.max(task!.rules.upperSize*8,20000)))};table.append(tr)}el('trace').textContent=JSON.stringify({rejected:result.rejected,records:result.trace},null,2)}
function calculate(mode:DesignInput['mode']){if(worker||externalBusy)return;if(f('auto').checked&&token){void automatedCalculate(mode);return}try{const value=input(mode);task=value;before=structuredClone(pairs);out=null;dirty=true;el('events').replaceChildren();el('external-status').textContent='외부 검사 미실행';el('external-report').hidden=true;const id=++run;worker=new Worker(new URL('./design-worker.ts',import.meta.url),{type:'module'});actions();say('실제 계산 실행 중');worker.onmessage=e=>{const m=e.data;if(m.id!==run)return;if(m.type==='event'){const li=document.createElement('li');li.textContent=m.event.at+' · '+m.event.message;el('events').append(li)}else if(m.type==='error'){worker?.terminate();worker=null;say('계산 실패 · '+m.error);actions()}else if(m.type==='result'){worker?.terminate();worker=null;try{remember();result=m.result;pairs=structuredClone(result!.pairs);out=createOutput(source!,value,result!,hash,'MEMS_'+crypto.randomUUID().replaceAll('-','').slice(0,20));dirty=false;lists();display();say(result!.status==='feasible'?'조건 충족':'충돌 확인 필요');actions();if(f('auto').checked&&token)void externalCheck()}catch(e){dirty=true;out=null;say('출력 준비 실패 · '+error(e));actions()}}};worker.onerror=e=>{worker?.terminate();worker=null;say('Worker 오류 · '+e.message);actions()};worker.postMessage({id,input:value})}catch(e){worker?.terminate();worker=null;say('실행 실패 · '+error(e));actions()}}
for(const mode of ['generate','check','repair']as const)b(mode).onclick=()=>calculate(mode)
b('cancel').onclick=()=>{if(pipelinePending||pipelineId){pipelineRevision++;if(pipelineId)void fetch('/api/pipeline/'+pipelineId+'/cancel',{method:'POST',headers:{'X-Mems-Token':token}});pipelinePending=false;pipelineId='';externalBusy=false;dirty=true;out=null;say('계산 취소 요청');actions();return}run++;worker?.terminate();worker=null;dirty=true;out=null;say('계산 취소');actions()}
b('gds').onclick=()=>{if(out&&!dirty)download(out.bytes,out.manifest.workCell+(result?.status==='unresolved'?'_UNRESOLVED':'')+'.gds','application/octet-stream')}
b('save-project').onclick=()=>json({schema:'mems-release-project-v1',sourceSha256:hash,sourceName:name,cellName:cell?.name,snapshot:snap(),result},'mems-project.json')
b('report').onclick=()=>{if(out)json(out.manifest,'mems-changes-and-evidence.json')}
f('project').onchange=async()=>{try{const file=f('project').files?.[0];if(!file)return;if(file.size>4*1024*1024)throw Error('프로젝트 한도 4 MiB');const p=JSON.parse(await file.text()) as Project;if(p.schema!=='mems-release-project-v1'||p.sourceSha256!==hash)throw Error('같은 원본 GDS를 먼저 불러와 주세요. SHA-256이 다릅니다.');if(!p.snapshot||!Array.isArray(p.snapshot.pairs)||p.snapshot.pairs.length>3000||!Array.isArray(p.snapshot.protection)||p.snapshot.protection.length>200||p.snapshot.protection.some(v=>!Array.isArray(v.points)||v.points.length>2000)||typeof p.snapshot.fields!=='object'||Object.values(p.snapshot.fields).some(v=>typeof v!=='string'))throw Error('프로젝트 형식 오류');if(cell?.name===p.cellName){remember();restore(p.snapshot);input('check');say('프로젝트 복원 · 재검사가 필요합니다.')}else{pending=p;preview.selectCell(p.cellName)}}catch(e){pending=null;say('복원 실패 · '+error(e))}}

async function automatedCalculate(mode:DesignInput['mode']){
 let value:DesignInput
 try{value={...input(mode),releaseModel:true}}catch(e){say('입력 확인 · '+error(e));return}
 const rev=++pipelineRevision;task=value;before=structuredClone(pairs);out=null;result=null;dirty=true;externalBusy=true;pipelinePending=true;el('events').replaceChildren();el('external-report').hidden=true;el('pipeline-result').hidden=true;el('summary').textContent='새 작업 실행 중';el('external-status').textContent='새 출력 검사 대기';el('pipeline-status').hidden=false;showPanel('result');say('자동화 실행 연결 중');actions()
 const resultWindow=window.open('/#run=pending','mems-result-'+crypto.randomUUID())
 const auditWindow=mode==='check'||!resultWindow?null:window.open('/#crosscheck=pending','mems-crosscheck-'+crypto.randomUUID())
 let accepted=false
 try{
  const response=await fetch('/api/pipeline/start',{method:'POST',headers:{'Content-Type':'application/json','X-Mems-Token':token},body:JSON.stringify({sourceBase64:base64(source!),sourceSha256:hash,input:value})})
  const initial=await response.json() as PipelineJob&{error?:string};if(!response.ok)throw Error(initial.error??'자동화 실행 실패')
  if(rev!==pipelineRevision){void fetch('/api/pipeline/'+initial.id+'/cancel',{method:'POST',headers:{'X-Mems-Token':token}});auditWindow?.close();resultWindow?.close();return}
  accepted=true
  pipelinePending=false;pipelineId=initial.id;const href='/#run='+pipelineId
  if(resultWindow&&!resultWindow.closed)resultWindow.location.href=href
  if(auditWindow&&!auditWindow.closed)auditWindow.location.href='/#crosscheck='+pipelineId
  const link=el<HTMLAnchorElement>('pipeline-result');link.href=href;link.hidden=false;actions()
  let job=initial
  while(true){
   if(rev!==pipelineRevision)return
   stageList(el('pipeline-stages'),job);say(job.stages.find(s=>s.state==='running')?.label??'실제 실행 중')
   el('events').replaceChildren();for(const e of job.events){const li=document.createElement('li');li.textContent=localTime(e.at)+' · '+e.message+(e.pid?' · '+e.program+' · PID '+e.pid:'');el('events').append(li)}
   if(job.status!=='running')break
   await new Promise(resolve=>setTimeout(resolve,250));job=await fetchJob(pipelineId)
  }
  if(job.status!=='completed'||!job.result)throw Error(job.error??'자동화 실행이 중단되었습니다.')
  const bytes=new Uint8Array(await(await fetch('/api/jobs/'+job.id+'/input')).arrayBuffer())
  const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(v=>v.toString(16).padStart(2,'0')).join('')
  if(digest!==job.outputSha256||digest!==job.result.check.report.outputSha256)throw Error('검사·화면 결과 파일의 식별값이 다릅니다.')
  if(rev!==pipelineRevision)return
  remember();result=job.result.manifest.result;pairs=structuredClone(result.pairs);out={bytes,manifest:job.result.manifest};dirty=false;lists();display();const check=job.result.check
  say(check.report.passed?'계산·출력 검사 완료':'미해결 충돌 확인 필요');el('runtime').textContent=check.report.passed?'검사 통과':'검사 미통과';el('runtime').dataset.state=check.report.passed?'passed':'failed';el('external-status').textContent=check.report.klayoutVersion+' · 오류 '+check.report.violations.length+'건 · '+(check.guiOpenedConfirmed?'KLayout 작업 셀 열림 확인':'KLayout 창 열기 요청/생략')+' · SHA-256 '+digest
  const report=el<HTMLAnchorElement>('external-report');report.href='/api/jobs/'+job.id+'/report';report.download='klayout-report.json';report.hidden=false
  if(job.portableAudit&&!auditWindow&&resultWindow&&!resultWindow.closed&&location.hash==='#workspace'){
   location.hash='crosscheck='+job.id
  }
 }catch(e){if(!accepted){resultWindow?.close();auditWindow?.close()}if(rev===pipelineRevision){out=null;dirty=true;say('실행 중단 · '+error(e));el('external-status').textContent=error(e)}}
 finally{if(rev===pipelineRevision){externalBusy=false;pipelinePending=false;pipelineId='';actions()}}
}

async function discover(){try{if(import.meta.env.BASE_URL!=='/')throw Error();const r=await fetch('/api/runtime');if(!r.ok)throw Error();const d=await r.json();token=d.token??'';el('runtime').textContent=d.klayoutFound?'자동화 연결됨':'경로 확인 필요';f('auto').checked=!!token&&!!d.klayoutFound;if(!d.klayoutFound)token=''}catch{token='';f('auto').checked=false;el('runtime').textContent='로컬 도우미 미연결'}}
async function externalCheck(){if(!out||dirty||externalBusy||!token)return;externalBusy=true;actions();el('external-status').textContent='출력 저장 → KLayout 별도 검사 실행 중';try{let raw='';for(let i=0;i<out.bytes.length;i+=8192)raw+=String.fromCharCode(...out.bytes.subarray(i,i+8192));const r=await fetch('/api/klayout/check',{method:'POST',headers:{'Content-Type':'application/json','X-Mems-Token':token},body:JSON.stringify({gdsBase64:btoa(raw),manifest:out.manifest})});const d=await r.json();if(!r.ok)throw Error(d.error??'외부 검사 실패');if(d.guiOpenRequested&&!d.guiOpenedConfirmed){el('external-status').textContent='외부 검사 완료 · KLayout 작업 셀 열림 확인 중';for(let i=0;i<80;i++){const reply=await fetch('/api/jobs/'+d.jobId+'/viewer');if(reply.ok&&(await reply.json()).confirmed){d.guiOpenedConfirmed=true;break}await new Promise(resolve=>setTimeout(resolve,250))}}el('runtime').textContent=d.report.passed?'검사 통과':'검사 미통과';el('runtime').dataset.state=d.report.passed?'passed':'failed';el('external-status').textContent=d.report.klayoutVersion+' · '+(d.report.passed?'지원 범위 검사 통과':'미통과')+' · 오류 '+d.report.violations.length+'건 · SHA-256 '+d.report.outputSha256+' · '+(d.guiOpenedConfirmed?'작업 셀 열림 확인':d.guiOpenRequested?'작업 셀 창 열기 요청':'창 열기 생략/실패');const a=el<HTMLAnchorElement>('external-report');a.href='/api/jobs/'+d.jobId+'/report';a.download='klayout-independent-report.json';a.hidden=false}catch(e){el('runtime').textContent='검사 실패';el('runtime').dataset.state='failed';el('external-status').textContent='외부 검사 실패 · '+error(e)}finally{externalBusy=false;actions()}}
b('external').onclick=()=>void externalCheck()
window.addEventListener('keydown',e=>{if(e.key==='Escape'){drawing=false;start=null;rubber=null;b('draw').innerHTML=icon('draw')+'사각형 그리기';b('draw').setAttribute('aria-pressed','false');overlay()}})
window.addEventListener('pagehide',()=>{worker?.terminate();preview.clear();urls.forEach(v=>URL.revokeObjectURL(v))})

function showPanel(name:string){for(const tab of root.querySelectorAll<HTMLButtonElement>('[data-panel]')){const active=tab.dataset.panel===name;tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;el('panel-'+tab.dataset.panel).hidden=!active}}
function activity(open:boolean){el('activity-panel').hidden=!open;b('activity-toggle').setAttribute('aria-expanded',String(open))}
function syncUI(){root.classList.toggle('has-source',!!source);root.classList.toggle('is-running',!!worker||!!pipelineId||pipelinePending);root.classList.toggle('external-running',externalBusy);root.dataset.state=worker||pipelineId||pipelinePending?'running':dirty?'dirty':result?.status??'empty';el('document-name').textContent=name||'새 설계';el('document-name').title=name;el('cell-title').textContent=cell?.name??'도면';el('pair-count').textContent=pairs.length+'쌍';el('canvas-units').textContent=source?'DBU '+dbu+' µm':'µm';el('canvas-empty').hidden=!!cell;el('empty-title').textContent=source?'셀을 선택하세요.':'도면에서 시작하세요.';b('empty-open').hidden=!!source;b('demo').hidden=!!source;b('show-conflicts').disabled=!result?.conflicts.length;if(dirty){for(const id of ['metric-pairs','metric-moved','metric-conflicts'])el(id).textContent='—'}}
b('studio-home').onclick=onHome
for(const[id,cls]of [['toggle-navigator','navigator-open'],['toggle-inspector','inspector-open']]as const)b(id).onclick=()=>{const active=root.classList.toggle(cls);b(id).setAttribute('aria-expanded',String(active))}
b('open-file').onclick=()=>f('file').click()
function revealTool(id:string){
 const toggle=b(id)
 if(getComputedStyle(toggle).display!=='none'&&toggle.getAttribute('aria-expanded')==='false')toggle.click()
}
b('workflow-file').onclick=()=>{revealTool('toggle-navigator');b('open-file').focus()}
function focusDesignPanel(panel:string){
 revealTool('toggle-inspector')
 showPanel(panel)
 b('tab-'+panel).focus()
}
b('workflow-target').onclick=()=>focusDesignPanel('target')
b('workflow-protection').onclick=()=>focusDesignPanel('protection')
b('workflow-run').onclick=()=>{
 focusDesignPanel('result')
 if(!b('generate').disabled)b('generate').focus()
}
b('empty-open').onclick=()=>f('file').click()
b('open-project').onclick=()=>f('project').click()
b('source-demo').onclick=()=>b('demo').click()
const help=el<HTMLDialogElement>('help-dialog')
for(const id of ['studio-help','source-info','rule-help'])b(id).onclick=()=>help.showModal()
b('help-close').onclick=()=>help.close()
help.addEventListener('click',e=>{if(e.target===help)help.close()})
b('activity-toggle').onclick=()=>activity(!!el('activity-panel').hidden)
b('activity-close').onclick=()=>activity(false)
b('show-conflicts').onclick=()=>activity(true)
const tabs=[...root.querySelectorAll<HTMLButtonElement>('[data-panel]')]
for(const[index,tab]of tabs.entries()){tab.onclick=()=>showPanel(tab.dataset.panel!);tab.onkeydown=e=>{let n=index;if(e.key==='ArrowRight')n=(index+1)%tabs.length;else if(e.key==='ArrowLeft')n=(index+tabs.length-1)%tabs.length;else if(e.key==='Home')n=0;else if(e.key==='End')n=tabs.length-1;else return;e.preventDefault();tabs[n]!.click();tabs[n]!.focus()}}
const cellSelect=root.querySelector<HTMLSelectElement>('#preview-cell')!
el('cell-slot').append(cellSelect)
cellSelect.setAttribute('aria-label','셀 선택')
const layerList=el('preview-layers');el('layer-slot').replaceChildren(layerList)
const shapeSelect=root.querySelector<HTMLSelectElement>('#preview-shape')!;el('shape-slot').append(shapeSelect);shapeSelect.setAttribute('aria-label','도형 선택')
el('geometry-slot').append(el('preview-selected'))
for(const[id,name]of [['preview-fit','fit'],['preview-in','plus'],['preview-out','minus']]as const){const button=b(id);button.innerHTML=icon(name);button.className='icon-button';button.setAttribute('aria-label',id==='preview-fit'?'전체 맞춤':id==='preview-in'?'도면 확대':'도면 축소');button.title=button.getAttribute('aria-label')!;el('viewport-actions').append(button)}
const hierarchy=f('preview-hierarchy');const label=hierarchy.closest('label')!;label.className='hierarchy-control';label.title='SREF/AREF 하위 셀 펼치기';label.childNodes.forEach(n=>{if(n.nodeType===Node.TEXT_NODE)n.textContent=' 하위 셀'});el('viewport-actions').prepend(label)
root.querySelector('.preview-layout aside')?.remove();root.querySelector('.preview-controls')?.remove()
for(const node of root.querySelectorAll('#viewport > h2,#viewport > p:not(#preview-status),.preview-stage > p'))node.remove()
el('preview-status').className='visually-hidden'
root.addEventListener('dragover',e=>{e.preventDefault()})
root.addEventListener('drop',e=>{e.preventDefault();const file=e.dataTransfer?.files[0];if(file)void load(file)})

actions();void discover().finally(actions)
return {openFile:load,openDemo:()=>b('demo').click()}
}

