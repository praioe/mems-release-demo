import './crosscheck-view.css'
import {brand,icon} from './icons.ts'
import {fetchJob} from './pipeline-client.ts'
import type {PipelineJob, PortableAuditReport} from './pipeline-client.ts'

const scientific=(value:number)=>value.toExponential(2).replace('e-','e−')

export function mountCrosscheck(root:HTMLElement, id:string) {
  const title=document.title
  document.title='SciPy 독립 검산 · MEMS Release'
  root.innerHTML=`<main class="crosscheck-page">
    <header class="crosscheck-header">
      <a class="brand" href="#home">${brand}</a>
      <a data-result hidden>${icon('back')} 배치 결과</a>
    </header>
    <section class="crosscheck-intro" aria-labelledby="crosscheck-title">
      <div class="crosscheck-message">
        <p class="crosscheck-label">SciPy 독립 검산 · Windows 실행 기록</p>
        <h1 id="crosscheck-title">검산 결과 : 대기</h1>
        <output class="crosscheck-lead" data-state role="status">작업을 연결하고 있습니다.</output>
      </div>
      <span class="crosscheck-mark" data-pass-mark hidden aria-hidden="true">${icon('check')}</span>
    </section>
    <div data-evidence hidden>
      <div class="crosscheck-findings">
        <section class="crosscheck-finding">
          <h2>두 계산의 최대 공급도 차이</h2>
          <p class="crosscheck-value" data-field-delta></p>
          <p data-field-summary></p>
        </section>
        <section class="crosscheck-finding">
          <h2>채택 좌표와 GDS</h2>
          <p class="crosscheck-value" data-gds-result></p>
          <p data-gds-summary></p>
        </section>
      </div>
    </div>
    <section class="crosscheck-calculation" aria-labelledby="crosscheck-method" data-calculation hidden>
      <h2 id="crosscheck-method">실제 검산 계산 기록</h2>
      <p class="crosscheck-runtime" data-grid></p>
      <div class="crosscheck-calculation-grid">
        <ol class="crosscheck-steps">
          <li><strong>같은 입력으로 방정식 구성</strong><code>A c = b</code><span>격자와 홀 좌표로 방정식 구성 · c는 격자별 공급도</span></li>
          <li><strong>SciPy로 독립 풀이</strong><code>spsolve(A, b, use_umfpack=False)</code><span>설계는 공액기울기 반복법, 검산은 SuperLU 직접 풀이</span></li>
          <li><strong>목적값과 방정식 잔차 비교</strong><code>mean((1 − c)²) · max |A c − b|</code><span data-residual></span></li>
        </ol>
        <div class="crosscheck-comparison">
          <div class="crosscheck-table" tabindex="0" aria-label="배치별 계산값 표"><table><thead><tr><th scope="col">배치</th><th scope="col">설계 목적값</th>
          <th scope="col">SciPy 목적값</th><th scope="col">최대 공급도 차이</th><th scope="col">판정</th></tr></thead><tbody data-fields></tbody></table></div>
          <p class="crosscheck-scope">검산 범위 · 모델 수치 계산과 저장된 GDS. 실제 식각 오차는 실측 비교 필요.</p>
        </div>
      </div>
    </section>
    <div data-record hidden>
      <div class="crosscheck-links">
        <button class="action-primary" type="button" data-notebook>이 작업의 Colab 노트북 ${icon('down')}</button>
        <a class="action-text" data-report download="scipy-crosscheck.json">검산 보고서 ${icon('down')}</a>
        <a class="action-text" data-gds download="output.gds">검산 대상 GDS ${icon('down')}</a>
      </div>
      <p class="crosscheck-replay"><a href="https://colab.research.google.com/" target="_blank" rel="noopener">Colab 열기 ↗</a> · 같은 작업을 재검산하려면 노트북을 업로드한 뒤 전체 실행합니다.</p>
      <p class="crosscheck-replay" data-notebook-status role="status" hidden></p>
      <details class="crosscheck-details">
        <summary>GDS 레이어와 작업 기록</summary>
        <p data-klayout></p>
        <div class="crosscheck-table"><table><thead><tr><th scope="col">홀층</th><th scope="col">채택 홀</th><th scope="col">GDS 홀</th>
        <th scope="col">누락</th><th scope="col">추가</th><th scope="col">좌표·크기</th></tr></thead><tbody data-layers></tbody></table></div>
        <p class="crosscheck-job" data-job></p>
      </details>
    </div>
  </main>`
  const get=<T extends HTMLElement=HTMLElement>(query:string)=>root.querySelector<T>(query)!
  const state=get<HTMLOutputElement>('[data-state]')
  const page=get('.crosscheck-page')
  const controller=new AbortController()
  let disposed=false
  let timer:ReturnType<typeof setTimeout>|undefined
  function setState(text:string,result:'passed'|'failed'|'pending'|'unavailable'='pending'){
    if(page.dataset.verdict!==result){
      const headings={
        passed:'검산 결과 : 통과',
        failed:'검산 결과 : 확인 필요',
        pending:'검산 결과 : 대기',
        unavailable:'검산 결과 : 기록 없음',
      }
      page.dataset.verdict=result
      get('#crosscheck-title').textContent=headings[result]
      get('[data-pass-mark]').hidden=result!=='passed'
    }
    if(state.textContent!==text)state.textContent=text
  }
  function rows(selector:string,values:(string|number)[][]) {
    const body=get(selector)
    body.replaceChildren()
    for(const parts of values){
      const row=document.createElement('tr')
      parts.forEach((value,i)=>{
        const cell=document.createElement(i===0?'th':'td')
        if(i===0)cell.setAttribute('scope','row')
        cell.textContent=String(value)
        row.append(cell)
      })
      body.append(row)
    }
  }
  function show(job:PipelineJob, report:PortableAuditReport) {
    if(!job.result||report.jobId!==job.id||report.gds.outputSha256!==job.outputSha256)
      throw Error('검산 보고서와 설계 작업의 식별값이 일치하지 않습니다.')
    setState(report.passed
      ?'다른 풀이법으로도 모델 계산값이 허용 오차 안에서 재현됐고, 채택한 홀의 좌표와 크기가 저장된 GDS와 일치했습니다.'
      :'수치 계산 또는 GDS 대조에서 차이가 확인됐습니다. 아래 근거에서 확인할 수 있습니다.',report.passed?'passed':'failed')
    const largest=Math.max(report.before.maxFieldDifference,report.after.maxFieldDifference)
    const tolerance=report.fieldTolerance
    const share=tolerance>0?largest/tolerance*100:undefined
    const shareText=share===undefined?'':share>0&&share<.01?' · 허용치의 0.01% 미만':` · 허용치의 ${share.toLocaleString('ko-KR',{maximumFractionDigits:2})}%`
    get('[data-field-delta]').textContent=scientific(largest)
    get('[data-field-summary]').textContent=`기준안·채택안 전체 격자에서 비교 · 허용 차이 ${scientific(tolerance)}${shareText}`
    get('[data-gds-result]').textContent=report.gds.passed?'일치':'불일치'
    const found=report.gds.layers.reduce((sum,layer)=>sum+layer.found,0)
    get('[data-gds-summary]').textContent=report.gds.passed
      ?`${report.gds.layers.length}개 레이어의 홀 ${found}개 · 채택 좌표와 크기 확인`
      :'레이어별 좌표·크기와 파일 식별값을 비교했습니다.'
    const beforeResidual=report.before.maxEquationResidual
    const afterResidual=report.after.maxEquationResidual
    get('[data-residual]').textContent=beforeResidual!==undefined&&afterResidual!==undefined&&report.residualTolerance!==undefined
      ?`방정식 최대 잔차 ${scientific(Math.max(beforeResidual,afterResidual))} · 허용치 ${scientific(report.residualTolerance)}`
      :'목적값과 공급도를 설계 실행 기록의 값과 대조'
    get('[data-grid]').textContent=`작업 ${job.id.slice(0,8)} · ${report.cells.toLocaleString('ko-KR')}셀 · 확산 길이 ${report.diffusionLengthUm} µm · SciPy ${report.versions.scipy} · ${report.elapsedMs} ms`
    rows('[data-fields]',([['격자 기준안',report.before],['모델 채택안',report.after]]as const).map(([label,field])=>[
      label,field.referenceObjective.toFixed(8),field.objective.toFixed(8),scientific(field.maxFieldDifference),field.passed?'통과':'미통과'
    ]))
    rows('[data-layers]',report.gds.layers.map(layer=>[
      layer.layer,layer.expected,layer.found,layer.missing,layer.unexpected,layer.passed?'일치':'불일치'
    ]))
    const checked=job.result.check.report
    get('[data-klayout]').textContent=`파일 식별값 ${report.gds.hashesMatch?'일치':'불일치'} · 별도 KLayout 설계 규칙 검사 ${checked.passed?'통과':'미통과'} · 위반 ${checked.violations.length}건`
    get('[data-job]').textContent='작업 ID '+id
    get<HTMLAnchorElement>('[data-report]').href='/api/pipeline/'+id+'/crosscheck'
    get<HTMLAnchorElement>('[data-gds]').href='/api/jobs/'+id+'/input'
    const notebook=get<HTMLButtonElement>('[data-notebook]')
    notebook.onclick=async()=>{
      const message=get('[data-notebook-status]')
      message.hidden=false
      message.textContent='이 작업의 재검산 자료를 준비하는 중입니다.'
      notebook.disabled=true
      try{
        const {downloadAuditNotebook}=await import('./crosscheck-notebook.ts')
        await downloadAuditNotebook(job,report,controller.signal)
        message.textContent='노트북 다운로드를 시작했습니다.'
      }catch(error){
        if(!disposed)message.textContent=error instanceof Error?error.message:String(error)
      }finally{
        notebook.disabled=false
      }
    }
    for(const section of ['[data-evidence]','[data-calculation]','[data-record]'])get(section).hidden=false
  }
  async function poll() {
    try{
      const job=await fetchJob(id)
      if(disposed)return
      if(job.status==='running'){
        const phase=job.stages.find(stage=>stage.id==='crosscheck')
        setState(phase?.state==='running'?'저장한 GDS와 수치를 독립 검산하는 중입니다.':'배치 계산과 GDS 저장을 기다리고 있습니다.')
        timer=setTimeout(()=>void poll(),400)
      }else if(job.status==='completed'){
        const audit=job.portableAudit
        if(audit&&'report' in audit)show(job,audit.report)
        else setState(audit?.message??'배치 결과 화면에서 이 작업의 실행 기록을 확인할 수 있습니다.',audit?.state==='failed'?'failed':'unavailable')
      }else setState(job.error??'작업이 중단됐습니다.','failed')
    }catch(error){
      if(!disposed)setState(error instanceof Error?error.message:String(error),'failed')
    }
  }
  if(id!=='pending'){
    if(/^[a-f0-9-]{36}$/.test(id)){
      const result=get<HTMLAnchorElement>('[data-result]')
      result.href='/#run='+id
      result.hidden=false
      void poll()
    }else setState('작업 ID를 확인해 주세요.','failed')
  }
  return ()=>{disposed=true;controller.abort();if(timer)clearTimeout(timer);document.title=title}
}
