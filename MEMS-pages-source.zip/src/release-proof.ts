import type { Conflict, Pair } from './design-engine.ts'
import type { ReleaseGrid } from './release-grid.ts'

export interface ReleaseMetrics { objective:number; worstDeficit:number }
export interface ReleaseField extends ReleaseMetrics { values:number[]; iterations:number }
export interface ReleaseProof {
  schema:string
  status:'improved'|'no-improvement'|'infeasible'|'unavailable'
  reason?:string
  settings:{diffusionLengthUm:number;exchange:number;sensitivityUm:number[]}
  grid:ReleaseGrid
  baseline:Pair[]
  chosen:Pair[]
  originalField?:ReleaseField
  before?:ReleaseField
  after?:ReleaseField
  evaluated:number
  groups:number
  options:number
  strideDbu:number
  spacingRejected:number
  conflicts:Conflict[]
  originalConflicts?:Conflict[]
  sensitivity?:{lengthUm:number;before:ReleaseMetrics;after:ReleaseMetrics}[]
  independent?:{solver:string;fieldMaxAbsError:number;objectiveMaxAbsError:number;evaluated:number}
}
