import { parseGDS, RecordType } from './vendor/gdsii/dist/esm/index.js'
import { inspectGds } from './gds-inspect.ts'
import type { ElementCounts, GdsSummary } from './gds-inspect.ts'

export type Point = [number, number]
export type Bounds = { minX: number; minY: number; maxX: number; maxY: number }
export interface BoundaryShape {
  id: string
  recordOffset: number
  layer: number
  datatype: number
  points: Point[]
  bounds: Bounds
  sourceCell?: string
  sourceId?: string
  instancePath?: string
}
export interface BoundaryCell {
  name: string
  boundaries: BoundaryShape[]
  omitted: ElementCounts
  bounds: Bounds | null
  viewMode?: 'direct' | 'expanded'
  expandedInstances?: number
}
export interface BoundaryInstance {
  kind: 'SREF' | 'AREF'
  recordOffset: number
  cellName: string
  points: Point[]
  columns: number
  rows: number
  flags: number
  angle: number | null
  magnification: number | null
}
export interface CellCatalog {
  name: string
  boundaryCount: number
  omitted: ElementCounts
}
export interface BoundaryLayout {
  summary: GdsSummary
  cells: Map<string, BoundaryCell>
  instances: Map<string, BoundaryInstance[]>
}
export type GeometryRequest =
  | { type: 'load'; revision: number; bytes: ArrayBuffer }
  | { type: 'cell'; revision: number; requestId: number; cellName: string; includeHierarchy: boolean }
export type GeometryResponse =
  | { type: 'ready'; revision: number; catalog: CellCatalog[]; dbuMicrometers: number; boundaryCount: number }
  | { type: 'cell'; revision: number; requestId: number; cell: BoundaryCell }
  | { type: 'error'; revision: number; requestId?: number; error: string }

export function pointBounds(points: Point[]): Bounds {
  if (!points.length) throw new Error('다각형 좌표가 없습니다.')
  let minX = Infinity
  let minY = Infinity
  let maxX = -Infinity
  let maxY = -Infinity
  for (const [x, y] of points) {
    if (!Number.isSafeInteger(x) || !Number.isSafeInteger(y)) throw new Error('DBU 좌표가 안전한 정수 범위를 벗어났습니다.')
    minX = Math.min(minX, x); minY = Math.min(minY, y)
    maxX = Math.max(maxX, x); maxY = Math.max(maxY, y)
  }
  return { minX, minY, maxX, maxY }
}
// Read all seven mantissa bytes. The vendored parser omits the last byte of REAL8.
// A transform is supported only when its value is exactly an integer, without rounding.
function exactReal8Integer(view: DataView, offset: number): number | null {
  const head = view.getUint8(offset)
  let mantissa = 0n
  for (let i = 1; i <= 7; i++) mantissa = (mantissa << 8n) | BigInt(view.getUint8(offset + i))
  const shift = 4 * ((head & 0x7f) - 64) - 56
  let value: bigint
  if (shift >= 0) value = mantissa << BigInt(shift)
  else {
    const divisor = 1n << BigInt(-shift)
    if (mantissa % divisor !== 0n) return null
    value = mantissa / divisor
  }
  if (head & 0x80) value = -value
  const number = Number(value)
  return Number.isSafeInteger(number) ? number : null
}
export function parseBoundaryLayout(input: Uint8Array): BoundaryLayout {
  const summary = inspectGds(input)
  // gdsii 0.1.0 assumes byteOffset=0 and does not handle zero block padding.
  // Make a new exact-length Uint8Array, also when input is a Node.js Buffer.
  const bytes = new Uint8Array(input.byteLength - summary.paddingBytes)
  bytes.set(input.subarray(0, bytes.length))
  const view = new DataView(bytes.buffer)
  const cells = new Map<string, BoundaryCell>()
  const instances = new Map<string, BoundaryInstance[]>()
  for (const info of summary.cells) {
    if (/[^\x00-\x7f]/.test(info.name)) throw new Error('현재 도형 보기는 ASCII 셀 이름을 지원합니다.')
    const omitted: ElementCounts = {}
    for (const [kind, count] of Object.entries(info.elements)) if (kind !== 'BOUNDARY') omitted[kind] = count
    cells.set(info.name, { name: info.name, boundaries: [], omitted, bounds: null })
    instances.set(info.name, [])
  }
  let currentCell: BoundaryCell | null = null
  let boundary: { recordOffset: number; layer: number | null; datatype: number | null; points: Point[] | null } | null = null
  let instance: BoundaryInstance | null = null
  let recordOffset = 0
  let totalPoints = 0
  try {
    for (const record of parseGDS(bytes)) {
      const length = view.getUint16(recordOffset, false)
      switch (record.tag) {
        case RecordType.STRNAME:
          currentCell = cells.get(record.data) ?? null
          if (!currentCell) throw new Error('셀 이름을 기본 정보와 대응하지 못했습니다.')
          break
        case RecordType.ENDSTR:
          currentCell = null
          break
        case RecordType.BOUNDARY:
          boundary = { recordOffset, layer: null, datatype: null, points: null }
          break
        case RecordType.SREF:
        case RecordType.AREF:
          instance = { kind: record.tag === RecordType.SREF ? 'SREF' : 'AREF', recordOffset, cellName: '', points: [], columns: 1, rows: 1, flags: 0, angle: 0, magnification: 1 }
          break
        case RecordType.SNAME:
          if (instance) instance.cellName = record.data
          break
        case RecordType.COLROW:
          if (instance) { instance.columns = record.data.columns; instance.rows = record.data.rows }
          break
        case RecordType.STRANS:
          if (instance) instance.flags = record.data & 0xffff
          break
        case RecordType.ANGLE:
          if (instance) instance.angle = length === 12 ? exactReal8Integer(view, recordOffset + 4) : null
          break
        case RecordType.MAG:
          if (instance) instance.magnification = length === 12 ? exactReal8Integer(view, recordOffset + 4) : null
          break
        case RecordType.LAYER:
          if (boundary) boundary.layer = record.data & 0xffff
          break
        case RecordType.DATATYPE:
          if (boundary) boundary.datatype = record.data & 0xffff
          break
        case RecordType.XY:
          if (boundary) boundary.points = record.data
          if (instance) instance.points = record.data
          break
        case RecordType.ENDEL:
          if (boundary) {
            if (!currentCell || boundary.layer === null || boundary.datatype === null || !boundary.points) throw new Error('BOUNDARY 정보가 완성되지 않았습니다.')
            const raw = boundary.points
            if (raw.length < 4 || raw[0]![0] !== raw[raw.length - 1]![0] || raw[0]![1] !== raw[raw.length - 1]![1]) throw new Error('닫히지 않았거나 점이 부족한 BOUNDARY입니다.')
            const points = raw.slice(0, -1)
            totalPoints += points.length
            if (totalPoints > 1000000) throw new Error('현재 도형 보기의 파일당 좌표 한도 100만 점을 넘었습니다.')
            const bounds = pointBounds(points)
            currentCell.boundaries.push({
              id: currentCell.name + '@' + boundary.recordOffset,
              recordOffset: boundary.recordOffset,
              layer: boundary.layer,
              datatype: boundary.datatype,
              points,
              bounds,
            })
          }
          boundary = null
          if (instance) {
            if (!currentCell || !instance.cellName || instance.points.length !== (instance.kind === 'SREF' ? 1 : 3)) throw new Error('셀 참조의 이름 또는 좌표가 완성되지 않았습니다.')
            if (!Number.isInteger(instance.columns) || !Number.isInteger(instance.rows) || instance.columns < 1 || instance.rows < 1) throw new Error('배열 참조의 행·열 수가 올바르지 않습니다.')
            instances.get(currentCell.name)!.push(instance)
          }
          instance = null
          break
        default:
          break
      }
      recordOffset += length
    }
  } catch (error) {
    throw new Error('도형 읽기를 완료하지 못했습니다. ' + (error instanceof Error ? error.message : String(error)))
  }
  for (const cell of cells.values()) {
    for (const shape of cell.boundaries) {
      if (!cell.bounds) cell.bounds = { ...shape.bounds }
      else {
        cell.bounds.minX = Math.min(cell.bounds.minX, shape.bounds.minX)
        cell.bounds.minY = Math.min(cell.bounds.minY, shape.bounds.minY)
        cell.bounds.maxX = Math.max(cell.bounds.maxX, shape.bounds.maxX)
        cell.bounds.maxY = Math.max(cell.bounds.maxY, shape.bounds.maxY)
      }
    }
    const expected = summary.cells.find(info => info.name === cell.name)?.elements.BOUNDARY ?? 0
    if (cell.boundaries.length !== expected) throw new Error('기본 정보와 실제 BOUNDARY 수가 다릅니다: ' + cell.name)
    const info = summary.cells.find(item => item.name === cell.name)!
    const expectedRefs = (info.elements.SREF ?? 0) + (info.elements.AREF ?? 0)
    if (instances.get(cell.name)!.length !== expectedRefs) throw new Error('기본 정보와 셀 참조 수가 다릅니다: ' + cell.name)
  }
  return { summary, cells, instances }
}

