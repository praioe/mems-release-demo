import type { BoundaryCell, BoundaryShape, Bounds, GeometryRequest, GeometryResponse } from './boundary-data.ts'

type ViewBox = { x: number; y: number; width: number; height: number }
const colors = ['#87a9bb', '#729fa6', '#a4b9bd', '#959bb5', '#7b9d86', '#b4aa8c', '#a88e8a', '#8c9da8']
export function createBoundaryPreview(root: HTMLElement, hooks: { onCell?:(cell:BoundaryCell,dbu:number)=>void; onSelect?:(shape:BoundaryShape|null)=>void; onLoading?:()=>void } = {}) {
  root.innerHTML = `
    <h2>셀 도면 · BOUNDARY</h2>
    <p class="scope">하위 셀 펼쳐보기에서는 SREF·AREF의 위치·90도 단위 회전·반사·양의 정수 배율을 적용합니다. PATH·TEXT·BOX·NODE는 표시하지 않습니다.</p>
    <p id="preview-source"></p>
    <div class="preview-controls">
      <label for="preview-cell">볼 셀</label>
      <select id="preview-cell" disabled><option value="">파일을 읽어 주세요.</option></select>
      <button id="preview-fit" type="button" disabled>전체 맞춤</button>
      <button id="preview-in" type="button" disabled aria-label="도면 확대">＋</button>
      <button id="preview-out" type="button" disabled aria-label="도면 축소">－</button>
    </div>
    <label class="hierarchy-toggle"><input id="preview-hierarchy" type="checkbox" checked disabled> 하위 셀 펼쳐보기 (SREF/AREF)</label>
    <p id="preview-status" role="status" aria-live="polite"></p>
    <div class="preview-layout">
      <div class="preview-stage">
        <svg id="preview-svg" viewBox="0 0 1000 700" tabindex="0" role="img" aria-label="선택 셀 좌표계의 다각형. 드래그로 이동하고 확대·축소 버튼을 사용할 수 있습니다.">
          <g id="preview-shapes" transform="scale(1,-1)"></g>
        </svg>
        <p class="scope">드래그로 이동 · 버튼으로 확대/축소 · 도면에 초점을 둔 상태에서 방향키로 이동, +/−로 확대/축소, 0으로 전체 맞춤</p>
      </div>
      <aside aria-label="도면 표시와 선택 정보">
        <h3>레이어 표시</h3>
        <div id="preview-layers"></div>
        <label for="preview-shape">도형 선택</label>
        <select id="preview-shape" disabled><option value="">선택 없음</option></select>
        <p class="scope">도형 클릭이나 이 목록으로 선택합니다.</p>
        <dl id="preview-selected"></dl>
      </aside>
    </div>
  `
  const get = <T extends Element>(selector: string): T => {
    const element = root.querySelector<T>(selector)
    if (!element) throw new Error('도면 요소를 찾지 못했습니다: ' + selector)
    return element
  }
  const cellSelect = get<HTMLSelectElement>('#preview-cell')
  const hierarchyToggle = get<HTMLInputElement>('#preview-hierarchy')
  const shapeSelect = get<HTMLSelectElement>('#preview-shape')
  const status = get<HTMLElement>('#preview-status')
  const source = get<HTMLElement>('#preview-source')
  const svg = get<SVGSVGElement>('#preview-svg')
  const group = get<SVGGElement>('#preview-shapes')
  const layerList = get<HTMLElement>('#preview-layers')
  const selectedInfo = get<HTMLElement>('#preview-selected')
  const fitButton = get<HTMLButtonElement>('#preview-fit')
  const zoomIn = get<HTMLButtonElement>('#preview-in')
  const zoomOut = get<HTMLButtonElement>('#preview-out')
  let worker: Worker | null = null
  let revision = 0
  let requestId = 0
  let cell: BoundaryCell | null = null
  let dbu = 1
  let fileHash = ''
  let view: ViewBox = { x: 0, y: 0, width: 1000, height: 700 }
  const polygons = new Map<string, SVGPolygonElement>()
  const layerElements = new Map<string, SVGPolygonElement[]>()
  const hiddenLayers = new Set<string>()
  let selectedId = ''
  let drag: { pointerId: number; clientX: number; clientY: number; start: ViewBox; matrix: DOMMatrix; targetId: string; moved: boolean } | null = null

  function setView(next: ViewBox) {
    view = next
    svg.setAttribute('viewBox', [next.x, next.y, next.width, next.height].join(' '))
  }
  function clearCanvas() {
    cell = null
    drag = null
    group.replaceChildren()
    polygons.clear(); layerElements.clear(); hiddenLayers.clear()
    selectedId = ''
    selectedInfo.replaceChildren()
    layerList.replaceChildren()
    shapeSelect.replaceChildren(new Option('선택 없음', ''))
    shapeSelect.disabled = true
    fitButton.disabled = zoomIn.disabled = zoomOut.disabled = true
    setView({ x: 0, y: 0, width: 1000, height: 700 })
  }
  function fit(bounds: Bounds | null) {
    if (!bounds) return
    const width = Math.max(bounds.maxX - bounds.minX, 1)
    const height = Math.max(bounds.maxY - bounds.minY, 1)
    const padding = Math.max(width, height) * 0.06
    setView({ x: bounds.minX - padding, y: -bounds.maxY - padding, width: width + padding * 2, height: height + padding * 2 })
  }
  function zoom(factor: number) {
    const width = view.width * factor
    const height = view.height * factor
    if (Math.min(width, height) < 1 || Math.max(width, height) > 2 ** 35) return
    setView({ x: view.x + (view.width - width) / 2, y: view.y + (view.height - height) / 2, width, height })
  }
  function addFact(name: string, value: string) {
    const dt = document.createElement('dt')
    const dd = document.createElement('dd')
    dt.textContent = name
    dd.textContent = value
    selectedInfo.append(dt, dd)
  }
  function unit(value: number) {
    return Number((value * dbu).toPrecision(12)).toLocaleString('en-US', { useGrouping: false, maximumFractionDigits: 9 })
  }
  function selectShape(id: string) {
    if (selectedId) polygons.get(selectedId)?.classList.remove('is-selected')
    selectedId = ''
    selectedInfo.replaceChildren()
    shapeSelect.value = id
    hooks.onSelect?.(null)
    if (!id || !cell) return
    const shape = cell.boundaries.find(item => item.id === id)
    if (!shape || hiddenLayers.has(shape.layer + '/' + shape.datatype)) { shapeSelect.value = ''; return }
    selectedId = id
    hooks.onSelect?.(shape)
    polygons.get(id)?.classList.add('is-selected')
    addFact('표시 좌표계', cell.name)
    addFact('원본 셀', shape.sourceCell ?? cell.name)
    addFact('원본 ID', shape.sourceId ?? shape.id)
    if (shape.instancePath) addFact('참조 경로', shape.instancePath)
    addFact('레이어', shape.layer + '/' + shape.datatype)
    addFact('최소 XY', unit(shape.bounds.minX) + ', ' + unit(shape.bounds.minY) + ' µm')
    addFact('최대 XY', unit(shape.bounds.maxX) + ', ' + unit(shape.bounds.maxY) + ' µm')
    addFact('점 수', shape.points.length.toString())
    addFact('표시 첫 점 · DBU', shape.points[0]!.join(', '))
    addFact('파일 SHA', fileHash.slice(0, 16) + '…')
  }
  function updateStatus() {
    if (!cell) return
    const visible = cell.boundaries.filter(shape => !hiddenLayers.has(shape.layer + '/' + shape.datatype)).length
    const omitted = Object.entries(cell.omitted).map(([kind, count]) => kind + ' ' + count).join(', ')
    const expanded = cell.viewMode === 'expanded'
    status.textContent = cell.name + (expanded ? ' · 하위 셀 포함 BOUNDARY ' : ' · 직접 BOUNDARY ') + cell.boundaries.length + '개 중 ' + visible + '개 표시'
      + (expanded ? ' · 펼친 하위 셀 인스턴스 ' + cell.expandedInstances + '개' : ' · 하위 셀 참조는 펼치지 않음')
      + (omitted ? ' · 미표시: ' + omitted : '')
    if (!cell.boundaries.length) status.textContent += expanded ? ' · 표시할 BOUNDARY가 없습니다.' : ' · 직접 다각형이 없는 셀입니다. 하위 셀 펼쳐보기를 켜거나 하위 셀을 선택해 주세요.'
  }
  function render(next: BoundaryCell) {
    clearCanvas()
    cell = next
    const keys = [...new Set(next.boundaries.map(shape => shape.layer + '/' + shape.datatype))].sort((a, b) => {
      const [al, ad] = a.split('/').map(Number); const [bl, bd] = b.split('/').map(Number)
      return al! - bl! || ad! - bd!
    })
    const palette = new Map(keys.map((key, index) => [key, colors[index % colors.length]!]))
    const fragment = document.createDocumentFragment()
    for (const [index, shape] of next.boundaries.entries()) {
      const polygon = document.createElementNS('http://www.w3.org/2000/svg', 'polygon')
      const key = shape.layer + '/' + shape.datatype
      polygon.setAttribute('points', shape.points.map(point => point.join(',')).join(' '))
      polygon.setAttribute('fill', palette.get(key)!)
      polygon.setAttribute('stroke', palette.get(key)!)
      polygon.setAttribute('vector-effect', 'non-scaling-stroke')
      polygon.dataset.id = shape.id
      polygon.dataset.layer = key
      const title = document.createElementNS('http://www.w3.org/2000/svg', 'title')
      title.textContent = shape.id + ' · ' + key
      polygon.append(title)
      fragment.append(polygon)
      polygons.set(shape.id, polygon)
      const items = layerElements.get(key) ?? []
      items.push(polygon); layerElements.set(key, items)
      shapeSelect.append(new Option('#' + (index + 1) + ' · ' + key, shape.id))
    }
    group.append(fragment)
    for (const key of keys) {
      const label = document.createElement('label')
      const checkbox = document.createElement('input')
      checkbox.type = 'checkbox'; checkbox.checked = true
      checkbox.setAttribute('aria-label', '레이어 ' + key + ' 표시')
      const swatch = document.createElement('span')
      swatch.className = 'layer-swatch'
      swatch.style.backgroundColor = palette.get(key)!
      const text = document.createTextNode(key + ' · ' + layerElements.get(key)!.length)
      label.append(checkbox, swatch, text)
      checkbox.addEventListener('change', () => {
        if (checkbox.checked) hiddenLayers.delete(key); else hiddenLayers.add(key)
        for (const polygon of layerElements.get(key)!) polygon.style.display = checkbox.checked ? '' : 'none'
        if (selectedId && polygons.get(selectedId)?.dataset.layer === key && !checkbox.checked) selectShape('')
        updateStatus()
      })
      layerList.append(label)
    }
    shapeSelect.disabled = !next.boundaries.length
    fitButton.disabled = zoomIn.disabled = zoomOut.disabled = !next.boundaries.length
    fit(next.bounds)
    updateStatus()
    hooks.onCell?.(next,dbu)
  }
  function requestCell() {
    hooks.onLoading?.()
    ++requestId
    clearCanvas()
    if (!cellSelect.value || !worker) { status.textContent = '볼 셀을 선택해 주세요.'; return }
    status.textContent = cellSelect.value + (hierarchyToggle.checked ? '의 하위 셀 좌표를 펼치고 있습니다.' : '의 직접 다각형을 준비하고 있습니다.')
    const message: GeometryRequest = { type: 'cell', revision, requestId, cellName: cellSelect.value, includeHierarchy: hierarchyToggle.checked }
    worker.postMessage(message)
  }
  cellSelect.addEventListener('change', requestCell)
  hierarchyToggle.addEventListener('change', requestCell)
  shapeSelect.addEventListener('change', () => selectShape(shapeSelect.value))
  fitButton.addEventListener('click', () => fit(cell?.bounds ?? null))
  zoomIn.addEventListener('click', () => zoom(0.8))
  zoomOut.addEventListener('click', () => zoom(1.25))
  svg.addEventListener('keydown', event => {
    if (!cell?.boundaries.length) return
    const shifts: Record<string, [number, number]> = { ArrowLeft: [-0.1, 0], ArrowRight: [0.1, 0], ArrowUp: [0, -0.1], ArrowDown: [0, 0.1] }
    const shift = shifts[event.key]
    if (shift) { event.preventDefault(); setView({ ...view, x: view.x + shift[0] * view.width, y: view.y + shift[1] * view.height }) }
    else if (event.key === '+' || event.key === '=') { event.preventDefault(); zoom(0.8) }
    else if (event.key === '-') { event.preventDefault(); zoom(1.25) }
    else if (event.key === '0') { event.preventDefault(); fit(cell.bounds) }
  })
  svg.addEventListener('pointerdown', event => {
    if (event.button !== 0 || !cell?.boundaries.length || drag) return
    const matrix = svg.getScreenCTM()?.inverse()
    if (!matrix) return
    const target = event.target instanceof Element ? event.target.closest<SVGPolygonElement>('polygon[data-id]') : null
    drag = { pointerId: event.pointerId, clientX: event.clientX, clientY: event.clientY, start: { ...view }, matrix, targetId: target?.dataset.id ?? '', moved: false }
    svg.setPointerCapture(event.pointerId)
    svg.focus()
  })
  svg.addEventListener('pointermove', event => {
    if (!drag || drag.pointerId !== event.pointerId) return
    const cx = event.clientX - drag.clientX
    const cy = event.clientY - drag.clientY
    if (Math.hypot(cx, cy) < 3 && !drag.moved) return
    drag.moved = true
    const dx = cx * drag.matrix.a + cy * drag.matrix.c
    const dy = cx * drag.matrix.b + cy * drag.matrix.d
    setView({ ...drag.start, x: drag.start.x - dx, y: drag.start.y - dy })
  })
  svg.addEventListener('pointerup', event => {
    if (!drag || drag.pointerId !== event.pointerId) return
    const completed = drag
    drag = null
    if (svg.hasPointerCapture(event.pointerId)) svg.releasePointerCapture(event.pointerId)
    if (!completed.moved) selectShape(completed.targetId)
  })
  svg.addEventListener('pointercancel', () => { drag = null })

  function clear() {
    revision++
    requestId++
    worker?.terminate(); worker = null
    clearCanvas()
    root.hidden = true
    cellSelect.replaceChildren(new Option('파일을 읽어 주세요.', ''))
    cellSelect.disabled = true
    hierarchyToggle.disabled = true
    hierarchyToggle.checked = true
  }
  function load(buffer: ArrayBuffer, hash: string, fileName: string) {
    clear()
    root.hidden = false
    fileHash = hash
    source.textContent = '파일: ' + fileName + ' · SHA-256: ' + hash.slice(0, 16) + '…'
    status.textContent = 'Web Worker에서 실제 도형 좌표를 읽고 있습니다.'
    const current = revision
    try {
      worker = new Worker(new URL('./geometry-worker.ts', import.meta.url), { type: 'module' })
      worker.onmessage = (event: MessageEvent<GeometryResponse>) => {
        const message = event.data
        if (message.revision !== current || current !== revision) return
        if (message.type === 'ready') {
          dbu = message.dbuMicrometers
          cellSelect.replaceChildren(new Option('셀을 선택하세요.', ''))
          for (const item of message.catalog) cellSelect.append(new Option(item.name + ' · 직접 다각형 ' + item.boundaryCount, item.name))
          cellSelect.disabled = false
          hierarchyToggle.disabled = false
          status.textContent = '직접 BOUNDARY ' + message.boundaryCount + '개를 읽었습니다. 볼 셀을 선택해 주세요.'
        } else if (message.type === 'cell' && message.requestId === requestId) render(message.cell)
        else if (message.type === 'error' && (message.requestId === undefined || message.requestId === requestId)) {
          clearCanvas()
          status.textContent = '도형 보기 실패 · ' + message.error + ' 하위 셀 펼쳐보기를 끄면 직접 도형만 볼 수 있습니다. 기본 정보와 원본 다운로드는 계속 사용할 수 있습니다.'
        }
      }
      worker.onerror = (event) => {
        if (current !== revision) return
        clearCanvas()
        status.textContent = '도형 Worker 실행 실패 · ' + event.message
      }
      // Keep the original ArrayBuffer for exact download and KLayout transfer.
      const copy = buffer.slice(0)
      const message: GeometryRequest = { type: 'load', revision: current, bytes: copy }
      worker.postMessage(message, [copy])
    } catch (error) {
      status.textContent = '도형 보기 시작 실패 · ' + (error instanceof Error ? error.message : String(error))
    }
  }
  return { load, clear, selectCell:(name:string)=>{cellSelect.value=name;requestCell()}, focus:(bounds:Bounds)=>fit(bounds) }
}

