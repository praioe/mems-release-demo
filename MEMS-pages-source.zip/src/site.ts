import './site.css'
import './presentation.css'
import {brand,icon} from './icons.ts'

const app=document.querySelector('#app')!
const media=import.meta.env.BASE_URL+'media/'
app.innerHTML=`
<div id="landing">
  <main id="home">
  <div class="landing-scene" aria-hidden="true"><div class="hero-media">
    <picture>
      <source media="(max-width: 700px)" srcset="${media}plates-portrait.jpg">
      <img src="${media}plates-motion.jpg" alt="" fetchpriority="high" decoding="async">
    </picture>
    <video id="hero-film" muted loop playsinline preload="none" disablepictureinpicture></video>
  </div></div>
    <section class="hero" aria-labelledby="home-title">
  <header class="site-header">
    <a href="#home" class="brand" aria-label="MEMS Release 메인">${brand}</a>
    <nav aria-label="주 메뉴"><a href="#method">설계 과정</a><a href="#release-example">검증 예제</a></nav>
    <button id="header-open" class="quiet-button">${icon('open')} GDS 열기</button>
  </header>
      <div class="hero-copy">
        <h1 id="home-title" tabindex="-1"><span>MEMS 릴리스 홀</span> <span>배치 설계</span></h1>
        <div class="hero-actions">
          <a href="#workspace" class="action-primary">작업 시작 ${icon('arrow')}</a>
          <a href="#release-example" class="action-text">예제 보기 ${icon('arrow')}</a>
        </div>
      </div>
      <div class="hero-footer">
        <a href="#method" class="hero-next">설계 과정 <span aria-hidden="true">↓</span></a>
        <div class="film-controls">
          <span>PLATES <span class="film-detail">· 합성 GDS</span></span>
          <button type="button" id="film-toggle" aria-label="배경 영상 일시정지" hidden>${icon('pause')}</button>
        </div>
      </div>
    </section>
    <section id="method" class="method-section" aria-labelledby="method-title">
      <div class="method-nav"><a href="#home" class="brand" aria-label="MEMS Release 메인">${brand}</a><a href="#home">맨 위로 <span aria-hidden="true">↑</span></a></div>
      <div class="method-header">
        <h2 id="method-title" tabindex="-1">GDS에서 시작해,<br>검산한 도면으로</h2>
      </div>
      <ol class="method-steps">
        <li><span class="method-index">01</span><div><h3>도면과 규칙 입력</h3><p>GDS의 구조층을 고르고 보호 영역, 홀 간격, 잠금 조건을 설정합니다.</p></div></li>
        <li><span class="method-index">02</span><div><h3>홀 후보 계산</h3><p>Python이 후보 배치의 확산·반응 모델을 풀고 공급 부족도를 비교합니다.</p></div></li>
        <li><span class="method-index">03</span><div><h3>수치와 GDS 검산</h3><p>Scilab이 모델을 다시 풀고, KLayout이 저장된 GDS의 좌표와 규칙을 검사합니다.</p></div></li>
      </ol>
      <div class="method-actions"><button type="button" id="bottom-demo" class="action-primary">예제로 시작 ${icon('arrow')}</button><a href="#release-example" class="action-text">검사 기록 보기 ${icon('arrow')}</a></div>
    </section>
  </main>
  <input id="home-file" class="visually-hidden" type="file" accept=".gds,.gds2" aria-label="불러올 GDS 파일">
</div><div id="editor" hidden></div><div id="run-screen" hidden></div>`

const landing=document.getElementById('landing')!,editor=document.getElementById('editor')!,runScreen=document.getElementById('run-screen')!
const film=document.querySelector<HTMLVideoElement>('#hero-film')!
const filmToggle=document.querySelector<HTMLButtonElement>('#film-toggle')!
const hero=document.querySelector<HTMLElement>('.hero')!
const portrait=matchMedia('(max-width: 700px)')
const reduced=matchMedia('(prefers-reduced-motion: reduce)')
let userPaused=false
let heroVisible=false
let transitionFrame=0

function syncLandingTransition(){
  if(transitionFrame||landing.hidden)return
  transitionFrame=requestAnimationFrame(()=>{
    transitionFrame=0
    if(landing.hidden)return
    const progress=1-hero.getBoundingClientRect().bottom/hero.offsetHeight
    const fraction=Math.min(1,Math.max(0,(progress-.15)/.85))
    const blend=reduced.matches?0:fraction*fraction*(3-2*fraction)
    landing.style.setProperty('--scene-blend',blend.toFixed(4))
  })
}
addEventListener('scroll',syncLandingTransition,{passive:true})
addEventListener('resize',syncLandingTransition)

function updateFilm(){
  if(landing.hidden||!heroVisible||document.hidden||reduced.matches||userPaused){
    film.pause()
    return
  }
  const source=media+(portrait.matches?'plates-portrait.mp4':'plates-motion.mp4')
  if(film.getAttribute('src')!==source){
    film.classList.remove('is-playing')
    film.setAttribute('src',source)
  }
  void film.play().catch(()=>{})
}
function updateFilmButton(){
  filmToggle.innerHTML=icon(film.paused?'play':'pause')
  filmToggle.setAttribute('aria-label',film.paused?'배경 영상 재생':'배경 영상 일시정지')
}
film.addEventListener('playing',()=>{film.classList.add('is-playing');filmToggle.hidden=false;updateFilmButton()})
film.addEventListener('pause',updateFilmButton)
film.addEventListener('error',()=>{film.classList.remove('is-playing');filmToggle.hidden=true})
filmToggle.onclick=()=>{userPaused=!film.paused;updateFilm()}
portrait.addEventListener('change',updateFilm)
reduced.addEventListener('change',()=>{
  filmToggle.hidden=reduced.matches
  if(reduced.matches)film.classList.remove('is-playing')
  updateFilm()
  syncLandingTransition()
})
document.addEventListener('visibilitychange',updateFilm)
new IntersectionObserver(([entry])=>{heroVisible=!!entry?.isIntersecting;updateFilm()},{threshold:.15})
  .observe(hero)
let mounting:Promise<Awaited<ReturnType<typeof openStudio>>>|undefined
let runDispose:(()=>void)|undefined
let routeVersion=0
async function openStudio(){
  const {mountWorkbench}=await import('./workbench.ts')
  return mountWorkbench(editor,()=>{location.hash='home'})
}
function workspace(){
  return mounting??=openStudio()
}
async function route(){
  const version=++routeVersion
  const value=location.hash.slice(1)
  runDispose?.()
  runDispose=undefined
  document.body.classList.remove('in-studio','on-run')
  const wasLanding=!landing.hidden
  const isRun=value==='release-example'||value.startsWith('run=')||(value.startsWith('crosscheck=')&&import.meta.env.BASE_URL==='/')
  landing.hidden=value==='workspace'||isRun
  editor.hidden=runScreen.hidden=true
  if(landing.hidden)updateFilm()
  if(value==='workspace'){
    editor.hidden=false
    document.body.classList.add('in-studio')
    await workspace()
    return
  }
  if(isRun){
    runScreen.hidden=false
    runScreen.replaceChildren()
    document.body.classList.add('on-run')
    scrollTo(0,0)
    if(value==='release-example'){
      const {mountReleasePublic}=await import('./release-public.ts')
      if(version===routeVersion)runDispose=mountReleasePublic(runScreen)
    }else if(value.startsWith('run=')){
      const {mountRun}=await import('./run-view.ts')
      if(version===routeVersion)runDispose=mountRun(runScreen,value.slice(4))
    }else{
      const {mountCrosscheck}=await import('./crosscheck-view.ts')
      if(version===routeVersion)runDispose=mountCrosscheck(runScreen,value.slice('crosscheck='.length))
    }
    return
  }
  const behavior=wasLanding&&version>1&&!reduced.matches?'smooth':'instant'
  if(value==='method'){
    document.getElementById('method-title')!.focus({preventScroll:true})
    document.getElementById('method')!.scrollIntoView({behavior})
  }else{
    if(version>1)document.getElementById('home-title')!.focus({preventScroll:true})
    scrollTo({top:0,behavior})
  }
  updateFilm()
  syncLandingTransition()
}
const fileInput=document.querySelector<HTMLInputElement>('#home-file')!
document.getElementById('header-open')!.onclick=()=>fileInput.click()
fileInput.onchange=async()=>{
  const file=fileInput.files?.[0]
  if(!file)return
  fileInput.value=''
  location.hash='workspace'
  const studio=await workspace()
  await studio.openFile(file)
}
document.getElementById('bottom-demo')!.onclick=async()=>{
  location.hash='workspace'
  const studio=await workspace()
  studio.openDemo()
}
addEventListener('hashchange',()=>void route())
landing.addEventListener('click',event=>{
  const link=(event.target as Element).closest<HTMLAnchorElement>('a[href="#home"], a[href="#method"]')
  if(!link||event.button||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return
  event.preventDefault()
  if(link.hash!==location.hash)history.pushState(null,'',link.hash)
  void route()
})
void route()
