import { solveDesign } from './design-engine.ts'
import type { DesignInput } from './design-engine.ts'
const scope=globalThis as unknown as {onmessage:(e:MessageEvent<{id:number;input:DesignInput}>)=>void;postMessage:(v:unknown)=>void}
scope.onmessage=e=>{const{id,input}=e.data;try{const result=solveDesign(input,event=>scope.postMessage({id,type:'event',event}));scope.postMessage({id,type:'result',result})}catch(error){scope.postMessage({id,type:'error',error:error instanceof Error?error.message:String(error)})}}
