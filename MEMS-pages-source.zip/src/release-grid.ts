import { inPolygon } from './design-engine.ts'
import type { DesignInput, Pair } from './design-engine.ts'

export interface ReleaseCell { x:number; y:number; open:number; neighbors:number[] }
export interface ReleaseGrid { step:number; dbu:number; cells:ReleaseCell[] }
export const releaseSettings = { diffusionLengthUm:24, exchange:8, sensitivityUm:[12,24,48] }
const faces = [[-1,0],[1,0],[0,-1],[0,1]] as const

export function releaseGrid(input:DesignInput, dbu:number):ReleaseGrid {
  const {roi} = input
  const shapes = input.structures.map(id=>input.cell.boundaries.find(s=>s.id===id)!)
  const width=roi.maxX-roi.minX, height=roi.maxY-roi.minY
  const step=Math.max(2,2*Math.ceil(Math.max(4/dbu,Math.hypot(width,height)/42)/2))
  const cells:ReleaseCell[]=[], indices=new Map<string,number>()
  const inside=(x:number,y:number)=>shapes.every(s=>inPolygon([x,y],s.points))
  const key=(x:number,y:number)=>x+','+y
  for(let y=roi.minY+step/2;y<roi.maxY;y+=step){
    for(let x=roi.minX+step/2;x<roi.maxX;x+=step){
      if(!inside(x,y))continue
      indices.set(key(x,y),cells.length)
      cells.push({x,y,open:0,neighbors:[]})
    }
  }
  for(const cell of cells){
    for(const [dx,dy] of faces){
      const x=cell.x+dx*step, y=cell.y+dy*step, neighbor=indices.get(key(x,y))
      if(neighbor!==undefined)cell.neighbors.push(neighbor)
      else if(!inside(x,y))cell.open++
    }
  }
  return {step,dbu,cells}
}

export function releaseSources(grid:ReleaseGrid,pairs:Pair[],size:number) {
  const half=grid.step/2
  return grid.cells.map(({x,y})=>{
    let area=0
    for(const p of pairs){
      const r=(p.lowerSize??size)/2
      const w=Math.max(0,Math.min(x+half,p.x+r)-Math.max(x-half,p.x-r))
      const h=Math.max(0,Math.min(y+half,p.y+r)-Math.max(y-half,p.y-r))
      area+=w*h
    }
    return releaseSettings.exchange*area/(grid.step*grid.step)
  })
}

// Gauss-Seidel independently solves the same discrete balances as Python CG.
export function solveReleaseReference(grid:ReleaseGrid,pairs:Pair[],size:number,length:number) {
  if(!grid.cells.length)throw Error('모델 영역에 격자 셀이 없습니다.')
  const beta=(grid.step*grid.dbu/length)**2
  const source=releaseSources(grid,pairs,size).map((v,i)=>v+2*grid.cells[i]!.open)
  const diagonal=grid.cells.map((c,i)=>c.neighbors.length+source[i]!+beta)
  const values=grid.cells.map(()=>0)
  for(let pass=0;pass<15000;pass++){
    let change=0
    for(let i=0;i<values.length;i++){
      const next=(source[i]!+grid.cells[i]!.neighbors.reduce((sum,n)=>sum+values[n]!,0))/diagonal[i]!
      change=Math.max(change,Math.abs(next-values[i]!))
      values[i]=next
    }
    if(change<1e-12)return {values,...releaseMetrics(values)}
  }
  throw Error('독립 수치 풀이가 수렴하지 않았습니다.')
}

export function releaseMetrics(values:number[]) {
  return {
    objective:values.reduce((sum,v)=>sum+(1-v)**2,0)/values.length,
    worstDeficit:1-Math.min(...values)
  }
}
