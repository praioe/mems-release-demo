import {base64} from './pipeline-client.ts'
import type {PipelineJob,PortableAuditReport} from './pipeline-client.ts'

const markdown=(id:string,source:string)=>({id,cell_type:'markdown',metadata:{},source})
const code=(id:string,source:string)=>({id,cell_type:'code',metadata:{},source,execution_count:null,outputs:[]})

async function readAuditFile(url:string,signal:AbortSignal){
  const response=await fetch(url,{signal})
  if(!response.ok)throw Error('재검산에 필요한 파일을 읽지 못했습니다.')
  return response
}

export async function downloadAuditNotebook(job:PipelineJob,report:PortableAuditReport,signal:AbortSignal){
  const manifest=job.result?.manifest
  const release=manifest?.result.release
  if(!manifest||!release?.before||!release.after)throw Error('이 작업의 격자와 모델 계산값이 없습니다.')
  const id=encodeURIComponent(job.id)
  const [sourceFile,outputFile,helperFile]=await Promise.all([
    readAuditFile('/api/pipeline/'+id+'/source',signal).then(file=>file.arrayBuffer()),
    readAuditFile('/api/jobs/'+id+'/input',signal).then(file=>file.arrayBuffer()),
    readAuditFile(import.meta.env.BASE_URL+'release-audit/crosscheck.py',signal).then(file=>file.text()),
  ])
  const helper=helperFile.split('\nif __name__ == "__main__":')[0]!
  if(!helper.includes('def audit(folder):'))throw Error('검산 코드의 형식을 확인할 수 없습니다.')
  const snapshot={
    input:{rules:manifest.input.rules,holeLayers:manifest.input.holeLayers},
    proof:{grid:release.grid,settings:release.settings,baseline:release.baseline,chosen:release.chosen,before:release.before,after:release.after},
    report:{workCell:report.gds.workCell,sourceSha256:report.gds.sourceSha256,outputSha256:report.gds.outputSha256},
  }
  const encoded=(bytes:Uint8Array)=>JSON.stringify(base64(bytes))
  const snapshotData=encoded(new TextEncoder().encode(JSON.stringify(snapshot)))
  const cells=[
    markdown('overview',`# MEMS Release 독립 재검산\n\n작업 ID ${job.id}\n\n이 노트북에는 이 작업의 격자, 기준안과 채택안 좌표, 원본·출력 GDS가 들어 있습니다. 모든 셀을 실행하면 SciPy 직접 풀이와 KLayout GDS 대조를 새로 수행합니다.`),
    code('setup','%pip -q install scipy klayout'),
    code('solver',helper.trimEnd()),
    code('inputs',`from base64 import b64decode\nfrom tempfile import TemporaryDirectory\n\ntemporary_case = TemporaryDirectory(prefix="mems-crosscheck-")\nfolder = Path(temporary_case.name)\nreplay_bytes = b64decode(${snapshotData})\nreplay = json.loads(replay_bytes)\n(folder / "replay.json").write_bytes(replay_bytes)\n(folder / "source.gds").write_bytes(b64decode(${encoded(new Uint8Array(sourceFile))}))\n(folder / "output.gds").write_bytes(b64decode(${encoded(new Uint8Array(outputFile))}))\n(folder / "klayout-report.json").write_text(json.dumps(replay["report"]), encoding="utf-8")`),
    code('recompute',`result = audit(folder)\nresult["jobId"] = ${JSON.stringify(job.id)}\nfor label in ("before", "after"):\n    row = result[label]\n    print(f"{label}: design={row['referenceObjective']:.12f}  SciPy={row['objective']:.12f}")\n    print(f"max |delta c|={row['maxFieldDifference']:.3e}  max |Ac-b|={row['maxEquationResidual']:.3e}")\nprint("GDS:", result["gds"]["layers"])\nprint("Output SHA-256:", result["gds"]["outputSha256"])\nprint("Verdict:", "PASS" if result["passed"] else "FAIL")\nPath("colab-report.json").write_text(json.dumps(result, indent=2), encoding="utf-8")`),
  ]
  const notebook={cells,metadata:{kernelspec:{display_name:'Python 3',language:'python',name:'python3'}},nbformat:4,nbformat_minor:5}
  const url=URL.createObjectURL(new Blob([JSON.stringify(notebook,null,2)],{type:'application/x-ipynb+json'}))
  const link=document.createElement('a')
  link.href=url
  link.download='MEMS-colab-'+job.id.slice(0,8)+'.ipynb'
  link.click()
  setTimeout(()=>URL.revokeObjectURL(url),30000)
}
