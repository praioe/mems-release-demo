import type {Manifest} from './gds-output.ts'
import type {DesignInput} from './design-engine.ts'
export interface WindowEvidence {state:string;pid?:number;title?:string;status?:string;error?:string}
export interface PortableAuditReport {
 jobId:string
 passed:boolean
 solver:string
 versions:{scipy:string;klayout:string}
 cells:number
 elapsedMs:number
 diffusionLengthUm:number
 fieldTolerance:number
 residualTolerance?:number
 before:{objective:number;referenceObjective:number;worstDeficit:number;maxFieldDifference:number;maxEquationResidual?:number;passed:boolean}
 after:{objective:number;referenceObjective:number;worstDeficit:number;maxFieldDifference:number;maxEquationResidual?:number;passed:boolean}
 gds:{passed:boolean;workCell:string;sourceSha256:string;outputSha256:string;hashesMatch:boolean;dbuMatches:boolean;
  layers:{layer:string;expected:number;found:number;missing:number;unexpected:number;passed:boolean}[]}
}
export interface PipelineJob {
 modelWindow?:WindowEvidence
 auditWindow?:WindowEvidence
 scilab?:WindowEvidence & {report?:boolean}
 terminal?:WindowEvidence
 idle?:WindowEvidence & {runtime?:string;modelMs?:number}
 excel?:WindowEvidence & {filename?:string}
 portableAudit?:{state:'passed'|'mismatch';report:PortableAuditReport}|{state:'skipped'|'failed';message:string}
}
export interface PipelineStage{id:string;label:string;state:string;startedAt?:string;finishedAt?:string}
export interface PipelineJob{id:string;status:string;mode:string;preview?:DesignInput;stages:PipelineStage[];events:Array<{at:string;stage:string;message:string;pid?:number;program?:string}>;startedAt:string;finishedAt?:string;error?:string;code?:string;stats?:{pairs:number;candidates:number;conflicts:number;calculationMs:number;moved:number};outputSha256?:string;result?:{manifest:Manifest;check:{jobId:string;report:{passed:boolean;klayoutVersion:string;outputSha256:string;violations:unknown[]};guiOpenedConfirmed:boolean;guiOpenRequested:boolean;guiWarning?:string}}}
export const base64=(bytes:Uint8Array)=>{let raw='';for(let i=0;i<bytes.length;i+=8192)raw+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(raw)}
export async function fetchJob(id:string):Promise<PipelineJob>{const r=await fetch('/api/pipeline/'+encodeURIComponent(id),{cache:'no-store'});const d=await r.json();if(!r.ok)throw Error(d.error??'작업 연결 실패');return d}
export const localTime=(at:string)=>new Date(at).toLocaleTimeString('ko-KR',{timeZone:'Asia/Seoul',hour12:false})
export function stageList(target:HTMLElement,job:PipelineJob){target.replaceChildren();for(const item of job.stages){const li=document.createElement('li');li.dataset.state=item.state;const label=document.createElement('span');label.textContent=item.label;li.append(label);const detail=document.createElement('small');detail.textContent=item.state==='completed'&&item.finishedAt&&item.startedAt?((Date.parse(item.finishedAt)-Date.parse(item.startedAt))/1000).toFixed(2)+' s':({running:'실행 중',completed:'완료',requested:'열기 요청',skipped:'생략',failed:'실패',cancelled:'취소'}[item.state]??'대기');li.append(detail);target.append(li)}}
