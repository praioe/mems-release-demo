import { inspectGds } from './gds-inspect.ts'
import { pairBox,rectPoints,validateInput } from './design-engine.ts'
import type { DesignInput,DesignResult } from './design-engine.ts'

export interface Manifest { schema:'mems-release-output-v1'; workCell:string; sourceCell:string; sourceSha256:string; dbuMicrometers:number; input:DesignInput; result:DesignResult; scope:string; createdAt:string }
function record(tag:number,payload=new Uint8Array()):Uint8Array {
  const bytes=new Uint8Array(payload.length+4),v=new DataView(bytes.buffer)
  if(bytes.length>65535||bytes.length%2)throw Error('출력 GDS 레코드 길이가 올바르지 않습니다.')
  v.setUint16(0,bytes.length);v.setUint16(2,tag);bytes.set(payload,4);return bytes
}
function text(tag:number,value:string) {const payload=new Uint8Array(value.length+(value.length%2));for(let i=0;i<value.length;i++){if(value.charCodeAt(i)>127)throw Error('출력 셀 이름은 ASCII여야 합니다.');payload[i]=value.charCodeAt(i)}return record(tag,payload)}
function int16(tag:number,value:number) {const b=new Uint8Array(2);new DataView(b.buffer).setUint16(0,value);return record(tag,b)}
function xy(points:number[][]) {const b=new Uint8Array(points.length*8),v=new DataView(b.buffer);points.forEach((p,i)=>p.forEach((n,j)=>{if(!Number.isSafeInteger(n)||n< -2147483648||n>2147483647)throw Error('출력 좌표가 GDS INT32 범위를 벗어났습니다.');v.setInt32(i*8+j*4,n)}));return record(0x1003,b)}
function concat(parts:Uint8Array[]) {const b=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let offset=0;for(const p of parts){b.set(p,offset);offset+=p.length}return b}
export function createOutput(source:Uint8Array,input:DesignInput,result:DesignResult,sourceSha256:string,workCell:string):{bytes:Uint8Array;manifest:Manifest} {
  validateInput(input)
  const summary=inspectGds(source)
  if(!/^[A-Za-z0-9_]{1,32}$/.test(workCell)||summary.cells.some(c=>c.name===workCell))throw Error('중복되지 않는 32자 이내 ASCII 작업 셀 이름이 필요합니다.')
  if(!summary.cells.some(c=>c.name===input.cell.name))throw Error('출력 대상 셀이 원본에 없습니다.')
  const stamp=new Uint8Array(24),date=new Date(),values=[date.getUTCFullYear(),date.getUTCMonth()+1,date.getUTCDate(),date.getUTCHours(),date.getUTCMinutes(),date.getUTCSeconds()]
  const stampView=new DataView(stamp.buffer);[...values,...values].forEach((n,i)=>stampView.setUint16(i*2,n))
  const pieces=[record(0x0502,stamp),text(0x0606,workCell),record(0x0a00),text(0x1206,input.cell.name),xy([[0,0]]),record(0x1100)]
  for(const p of result.pairs)for(const i of [0,1]as const) {
    const [layer,datatype]=input.holeLayers[i].split('/').map(Number)
    const points=rectPoints(pairBox(p,i===0?(p.lowerSize??input.rules.lowerSize):(p.upperSize??input.rules.upperSize)))
    pieces.push(record(0x0800),int16(0x0d02,layer!),int16(0x0e02,datatype!),xy([...points,points[0]!]),record(0x1100))
  }
  pieces.push(record(0x0700))
  const end=source.length-summary.paddingBytes-4
  const bytes=concat([source.subarray(0,end),...pieces,source.subarray(end)])
  if(bytes.length>16*1024*1024)throw Error('출력이 현재 지원 한도 16 MiB를 넘습니다.')
  const recordedInput={...input,cell:{...input.cell,boundaries:input.cell.boundaries.filter(s=>input.structures.includes(s.id))}}
  return {bytes,manifest:{schema:'mems-release-output-v1',workCell,sourceCell:input.cell.name,sourceSha256,dbuMicrometers:summary.dbuMicrometers,input:recordedInput,result,scope:'selected-boundary-pair/square-metric/managed-pairs-only; original cells preserved',createdAt:date.toISOString()}}
}
