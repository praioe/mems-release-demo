import type {DesignInput,DesignResult} from './design-engine.ts'
import {pairBox,rectPoints} from './design-engine.ts'
import type {Point} from './boundary-data.ts'
/** View of actual manifest XY geometry. Z separation is illustrative only. */
export class ResultGeometry{
 private c:CanvasRenderingContext2D;private w=1;private h=1;private angle=-.35;private tilt=.85;private frame=0;private last=0;private active=true;private rotating=true;private flat=false;private resize:ResizeObserver;private reduced=matchMedia('(prefers-reduced-motion: reduce)')
 private m:{input:DesignInput;result?:DesignResult};private before:boolean;private traceCount=0
 constructor(privateCanvas:HTMLCanvasElement,m:{input:DesignInput;result?:DesignResult},before:boolean){this.m=m;this.before=before;this.canvas=privateCanvas;this.c=privateCanvas.getContext('2d')!;this.resize=new ResizeObserver(()=>this.measure());this.resize.observe(privateCanvas);let drag:number|null=null;privateCanvas.onpointerdown=e=>{drag=e.clientX;this.rotating=false;privateCanvas.setPointerCapture(e.pointerId)};privateCanvas.onpointermove=e=>{if(drag===null||this.flat)return;this.angle+=(e.clientX-drag)*.006;drag=e.clientX;this.draw()};privateCanvas.onpointerup=()=>{drag=null};privateCanvas.onpointercancel=()=>{drag=null};this.measure();this.animate(0)}
 private canvas:HTMLCanvasElement
 setFlat(v:boolean){this.flat=v;this.draw()}
 setRotating(v:boolean){this.rotating=v}
 setTraceCount(v:number){this.traceCount=v;this.draw()}
 private measure(){const r=this.canvas.getBoundingClientRect(),d=Math.min(devicePixelRatio,1.7);this.w=r.width;this.h=r.height;this.canvas.width=Math.round(r.width*d);this.canvas.height=Math.round(r.height*d);this.c.setTransform(d,0,0,d,0,0);this.draw()}
 private animate(t:number){if(!this.active)return;if(t-this.last>40){if(this.rotating&&!this.flat&&!document.hidden&&!this.reduced.matches){this.angle+=.0015;this.draw();}this.last=t}this.frame=requestAnimationFrame(v=>this.animate(v))}
 private draw(){const c=this.c,w=this.w,h=this.h;if(!w||!h)return;c.clearRect(0,0,w,h);c.fillStyle='#ebeee8';c.fillRect(0,0,w,h);const shapes=this.m.input.structures.map(id=>this.m.input.cell.boundaries.find(s=>s.id===id)!),all=shapes.flatMap(s=>s.points),xs=all.map(p=>p[0]),ys=all.map(p=>p[1]),xmin=Math.min(...xs),xmax=Math.max(...xs),ymin=Math.min(...ys),ymax=Math.max(...ys),cx=(xmin+xmax)/2,cy=(ymin+ymax)/2,span=Math.max(xmax-xmin,ymax-ymin),scale=Math.min(w/(span*1.45),h/(span*(this.flat?1.4:1.05))),angle=this.flat?0:this.angle,tilt=this.flat?0:this.tilt,gap=this.flat?0:span*.18
  const project=(p:Point,z:number):Point=>{const x=p[0]-cx,y=-(p[1]-cy),a=x*Math.cos(angle)-y*Math.sin(angle),b=x*Math.sin(angle)+y*Math.cos(angle);return[w*.5+a*scale,h*.57+(b*Math.cos(tilt)-z*Math.sin(tilt))*scale]}
  const path=(points:Point[],z:number)=>{c.moveTo(...project(points[0]!,z));for(const p of points.slice(1))c.lineTo(...project(p,z));c.closePath()}
  const pairs=this.before?this.m.input.baseline:this.m.result?.pairs??[]
  for(const i of [0,1]as const){const z=i*gap,shape=shapes[i]!,size=i===0?this.m.input.rules.lowerSize:this.m.input.rules.upperSize;c.beginPath();path(shape.points,z);for(const p of pairs)path(rectPoints(pairBox(p,(i===0?p.lowerSize:p.upperSize)??size)),z);c.fillStyle=i===0?'#91adb3ee':'#d3e3df';if(this.flat)c.fillStyle=i===0?'#658c935c':'#d3e3df2a';c.fill('evenodd');c.strokeStyle=i===0?'#4f747d':'#48696b';c.lineWidth=.65;c.stroke();if(!this.flat){for(let j=0;j<shape.points.length;j++){const a=shape.points[j]!,b=shape.points[(j+1)%shape.points.length]!;c.beginPath();c.moveTo(...project(a,z));c.lineTo(...project(a,z-span*.018));c.lineTo(...project(b,z-span*.018));c.lineTo(...project(b,z));c.closePath();c.fillStyle=i===0?'#557078':'#809d9d';c.fill()}}}
  for(const p of this.m.input.protected){c.beginPath();path(p.points,gap+.001);c.fillStyle='#d5963a30';c.fill();c.setLineDash([5,4]);c.strokeStyle='#9c621c';c.lineWidth=1;c.stroke();c.setLineDash([])}
  for(const pair of pairs){
   if(!pair.locked)continue
   c.beginPath()
   path(rectPoints(pairBox(pair,pair.upperSize??this.m.input.rules.upperSize)),gap+.001)
   c.strokeStyle='#126f63';c.lineWidth=1.6;c.setLineDash([2,2]);c.stroke();c.setLineDash([])
  }
  if(!this.before)for(const v of this.m.result?.conflicts??[]){const p=project([v.x,v.y],gap);c.beginPath();c.arc(p[0],p[1],7,0,Math.PI*2);c.strokeStyle='#ad324b';c.lineWidth=2;c.stroke()}
  if(!this.before&&this.traceCount)for(const v of (this.m.result?.trace??[]).slice(0,this.traceCount)){c.beginPath();path(rectPoints(pairBox({id:v.pairId,x:v.x,y:v.y,locked:false},this.m.input.rules.upperSize)),gap+.01);c.strokeStyle=v.accepted?'#31545b':'#9b6424';c.lineWidth=1.5;c.stroke()}
 }
 dispose(){this.active=false;cancelAnimationFrame(this.frame);this.resize.disconnect()}
}
