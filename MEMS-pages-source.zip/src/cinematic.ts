type V=[number,number,number]
const ease=(n:number)=>{const t=Math.max(0,Math.min(1,n));return t*t*(3-2*t)}
/** Geometric product illustration, not a physical etch simulation. */
export class CinematicScene{
 private canvas:HTMLCanvasElement;private c:CanvasRenderingContext2D;private w=1;private h=1;private frame=0;private time=0;private last=0;private running=true;private paused=false;private reduced=matchMedia('(prefers-reduced-motion: reduce)')
 constructor(canvas:HTMLCanvasElement){this.canvas=canvas;this.c=canvas.getContext('2d')!;new ResizeObserver(()=>this.measure()).observe(canvas);document.addEventListener('visibilitychange',()=>this.schedule());this.reduced.addEventListener('change',()=>this.schedule());this.measure();this.schedule()}
 private measure(){const r=this.canvas.getBoundingClientRect(),d=Math.min(devicePixelRatio,1.6);this.w=r.width;this.h=r.height;this.canvas.width=Math.round(r.width*d);this.canvas.height=Math.round(r.height*d);this.c.setTransform(d,0,0,d,0,0);this.draw()}
 setRunning(v:boolean){this.running=v;this.schedule()}
 setPaused(v:boolean){this.paused=v;this.schedule()}
 private schedule(){cancelAnimationFrame(this.frame);this.last=0;if(this.running&&!this.paused&&!document.hidden&&!this.reduced.matches)this.frame=requestAnimationFrame(t=>this.tick(t));else this.draw()}
 private tick(t:number){if(this.last&&t-this.last<32){this.frame=requestAnimationFrame(t=>this.tick(t));return}if(this.last)this.time+=Math.min(t-this.last,80);this.last=t;this.draw();this.frame=requestAnimationFrame(v=>this.tick(v))}
 private draw(){
  const c=this.c,w=this.w,h=this.h,t=this.time/1000;c.clearRect(0,0,w,h);c.fillStyle='#080809';c.fillRect(0,0,w,h)
  const cycle=(t%24)/24,rotation=-.42+Math.sin(t*.1)*.2,tilt=.92+Math.sin(t*.12)*.12,gap=40+40*(.5+.5*Math.sin(t*.2)),scale=Math.min(w/(w<650?385:470),h/300),cx=w*.52,cy=h*.57
  const project=([x,y,z]:V):[number,number]=>{const a=x*Math.cos(rotation)-y*Math.sin(rotation),b=x*Math.sin(rotation)+y*Math.cos(rotation),d=b*Math.sin(tilt)+z*Math.cos(tilt),k=950/(950-d);return[cx+a*scale*k,cy+(b*Math.cos(tilt)-z*Math.sin(tilt))*scale*k]}
  const poly=(v:V[])=>{c.moveTo(...project(v[0]!));for(const q of v.slice(1))c.lineTo(...project(q));c.closePath()}
  const box=(x:number,y:number,s:number,z:number):V[]=>[[x-s/2,y-s/2,z],[x+s/2,y-s/2,z],[x+s/2,y+s/2,z],[x-s/2,y+s/2,z]]
  const outline=(z:number):V[]=>[[-180,-115,z],[165,-115,z],[180,-100,z],[180,115,z],[-165,115,z],[-180,100,z]]
  const shift=ease((cycle-.55)*6)*14-ease((cycle-.89)*12)*14,holes:V[]=[];for(let y=-90;y<=90;y+=20)for(let x=-150;x<=150;x+=20){if(Math.abs(x)<25&&Math.abs(y)<22)continue;holes.push([x,y,0])}holes.push([0,-shift,0])
  const plate=(z:number,upper:boolean)=>{
   const top=outline(z),bottom=outline(z-9)
   for(let i=0;i<top.length;i++){const j=(i+1)%top.length;c.beginPath();poly([top[i]!,top[j]!,bottom[j]!,bottom[i]!]);c.fillStyle=upper?'#77797d':'#690d28';c.fill();c.strokeStyle=upper?'#b2b2b4':'#a02147';c.lineWidth=.45;c.stroke()}
   c.beginPath();poly(top);for(const [x,y]of holes)poly(box(x,y,upper?8:4,z))
   const g=c.createLinearGradient(w*.1,h*.1,w*.9,h*.95);if(upper){g.addColorStop(0,'#76767c');g.addColorStop(.26,'#dedee0');g.addColorStop(.43,'#96969c');g.addColorStop(.7,'#ededee');g.addColorStop(1,'#77777f')}else{g.addColorStop(0,'#4d081c');g.addColorStop(.35,'#ed174f');g.addColorStop(.65,'#930d31');g.addColorStop(1,'#430917')}
   c.fillStyle=g;c.fill('evenodd');c.strokeStyle=upper?'#e8e8e9':'#e64167';c.lineWidth=.55;c.stroke()
   for(const [x,y]of holes){const v=box(x,y,upper?8:4,z);c.beginPath();poly([v[0]!,v[1]!,[v[1]![0],v[1]![1],z-9],[v[0]![0],v[0]![1],z-9]]);c.fillStyle=upper?'#29292e':'#370813';c.fill()}
   for(const x of [-167,167])for(const y of [-103,103]){c.beginPath();c.moveTo(...project([x-3,y,z+.1]));c.lineTo(...project([x+3,y,z+.1]));c.moveTo(...project([x,y-3,z+.1]));c.lineTo(...project([x,y+3,z+.1]));c.strokeStyle=upper?'#54545c':'#fa648b';c.lineWidth=.8;c.stroke()}
  }
  c.save();c.beginPath();poly(outline(-25));c.shadowColor='#000';c.shadowBlur=45;c.shadowOffsetY=35;c.fillStyle='#000';c.fill();c.restore();plate(0,false)
  c.save();c.strokeStyle='#e4326655';c.lineWidth=.6;c.setLineDash([3,5]);for(const [x,y]of holes.filter((_,i)=>i%17===0)){c.beginPath();c.moveTo(...project([x,y,1]));c.lineTo(...project([x,y,gap]));c.stroke()}c.restore();plate(gap,true)
  c.beginPath();poly(box(0,0,40,gap+.3));c.fillStyle='#b2093520';c.fill();c.strokeStyle='#f05b7b';c.setLineDash([3,3]);c.lineWidth=1;c.stroke();c.setLineDash([])
  c.save();c.globalAlpha=.35;for(let i=0;i<6;i++){c.beginPath();poly(outline(-110-i*9));c.strokeStyle=i===0?'#aa123e':'#414149';c.lineWidth=.4;c.stroke()}c.restore()
 }
}
