import { pointBounds } from './boundary-data.ts'
import type { BoundaryCell, BoundaryShape, Bounds, Point } from './boundary-data.ts'
import type { ReleaseProof } from './release-proof.ts'

export interface Rules { lowerSize:number; upperSize:number; spacing:number; enclosure:number; boundaryGap:number; protectGap:number; pitch:number; grid:number; searchRadius:number }
export interface Pair { id:string; x:number; y:number; locked:boolean; lowerSize?:number; upperSize?:number }
export interface Protection { id:string; points:Point[] }
export interface DesignInput { cell:BoundaryCell; structures:[string,string]; holeLayers:[string,string]; rules:Rules; roi:Bounds; protected:Protection[]; baseline:Pair[]; mode:'generate'|'repair'|'check'; releaseModel?:boolean }
export interface DesignResult { release?:ReleaseProof }
export interface Conflict { pairId:string; rule:string; x:number; y:number; related?:string }
export interface Change { id:string; kind:'added'|'moved'|'resized'|'preserved'; from?:Point; to:Point; locked:boolean; sizesBefore?:Point; sizesAfter:Point }
export interface DesignResult { pairs:Pair[]; conflicts:Conflict[]; changes:Change[]; testedCandidates:number; rejected:Record<string,number>; trace:Array<{pairId:string;x:number;y:number;accepted:boolean;reason:string}>; elapsedMs:number; status:'feasible'|'unresolved'; algorithm:string; coverage?:{status:string;targetId?:string;candidatesEvaluated:number;sampleCount:number;sampleStepDbu?:number;fixedOtherPairs?:number;before?:{worstSquaredDbu:number};after?:{worstSquaredDbu:number};independentRankingVerified?:boolean;claim?:string;reason?:string} }
export type EngineEvent = { stage:string; message:string; at:string }
const limits={candidates:30000,pairs:3000,protect:200,vertices:2000}
const cross=(a:Point,b:Point,c:Point)=>(BigInt(b[0])-BigInt(a[0]))*(BigInt(c[1])-BigInt(a[1]))-(BigInt(b[1])-BigInt(a[1]))*(BigInt(c[0])-BigInt(a[0]))
function onSegment(p:Point,a:Point,b:Point) { return cross(a,b,p)===0n && p[0]>=Math.min(a[0],b[0])&&p[0]<=Math.max(a[0],b[0])&&p[1]>=Math.min(a[1],b[1])&&p[1]<=Math.max(a[1],b[1]) }
function intersects(a:Point,b:Point,c:Point,d:Point) {
  const x=cross(a,b,c),y=cross(a,b,d),u=cross(c,d,a),v=cross(c,d,b)
  return (x===0n&&onSegment(c,a,b))||(y===0n&&onSegment(d,a,b))||(u===0n&&onSegment(a,c,d))||(v===0n&&onSegment(b,c,d))||((x>0n)!==(y>0n)&&x!==0n&&y!==0n&&(u>0n)!==(v>0n)&&u!==0n&&v!==0n)
}
export function inPolygon(p:Point,poly:Point[],boundary=true) {
  let winding=0
  for(let i=0;i<poly.length;i++) {
    const a=poly[i]!,b=poly[(i+1)%poly.length]!
    if(onSegment(p,a,b))return boundary
    if(a[1]<=p[1]&&b[1]>p[1]&&cross(a,b,p)>0n)winding++
    if(a[1]>p[1]&&b[1]<=p[1]&&cross(a,b,p)<0n)winding--
  }
  return winding!==0
}
export function rectPoints(b:Bounds):Point[] { return [[b.minX,b.minY],[b.maxX,b.minY],[b.maxX,b.maxY],[b.minX,b.maxY]] }
export function pairBox(p:Pair,size:number,pad=0):Bounds { const h=size/2+pad;return {minX:p.x-h,minY:p.y-h,maxX:p.x+h,maxY:p.y+h} }
function segmentInOpenRect(a:Point,b:Point,r:Bounds) {
  type F=[bigint,bigint]
  const cmp=(u:F,v:F)=>u[0]*v[1]-v[0]*u[1]
  let lo:F=[0n,1n],hi:F=[1n,1n]
  for(const [start,end,min,max]of [[a[0],b[0],r.minX,r.maxX],[a[1],b[1],r.minY,r.maxY]]) {
    const delta=BigInt(end!)-BigInt(start!)
    if(delta===0n) {if(start!<=min!||start!>=max!)return false;continue}
    let low:F=[BigInt(min!)-BigInt(start!),delta],high:F=[BigInt(max!)-BigInt(start!),delta]
    if(delta<0n){low=[-high[0],-high[1]];high=[-(BigInt(min!)-BigInt(start!)),-delta]}
    if(cmp(low,lo)>0n)lo=low
    if(cmp(high,hi)<0n)hi=high
    if(cmp(lo,hi)>=0n)return false
  }
  return cmp(lo,hi)<0n
}
export function containsRect(poly:Point[],b:Bounds) {
  if(!rectPoints(b).every(p=>inPolygon(p,poly)))return false
  return !poly.some((p,i)=>segmentInOpenRect(p,poly[(i+1)%poly.length]!,b))
}
export function overlapsRect(poly:Point[],b:Bounds) {
  const pb=pointBounds(poly)
  if(pb.maxX<=b.minX||pb.minX>=b.maxX||pb.maxY<=b.minY||pb.minY>=b.maxY)return false
  if(rectPoints(b).some(p=>inPolygon(p,poly,false)))return true
  if(inPolygon([(b.minX+b.maxX)/2,(b.minY+b.maxY)/2],poly,false))return true
  return poly.some((p,i)=>segmentInOpenRect(p,poly[(i+1)%poly.length]!,b))
}
export function validatePolygon(points:Point[]) {
  if(points.length<3||points.length>limits.vertices)throw Error('대상·보호 다각형은 3~2,000개 꼭짓점을 지원합니다.')
  pointBounds(points)
  let area=0n
  for(let i=0;i<points.length;i++) {
    const a=points[i]!,b=points[(i+1)%points.length]!
    if(a[0]===b[0]&&a[1]===b[1])throw Error('중복된 연속 꼭짓점이 있습니다.')
    area+=BigInt(a[0])*BigInt(b[1])-BigInt(a[1])*BigInt(b[0])
    for(let j=i+1;j<points.length;j++) {
      if(j===i+1||(i===0&&j===points.length-1))continue
      if(intersects(a,b,points[j]!,points[(j+1)%points.length]!))throw Error('자기 교차·접촉 다각형은 현재 계산 대상에서 제외됩니다.')
    }
  }
  if(area===0n)throw Error('다각형 면적이 0입니다.')
}
export function validateInput(input:DesignInput):[BoundaryShape,BoundaryShape] {
  const r=input.rules
  for(const [key,value]of Object.entries(r))if(!Number.isSafeInteger(value)||value<0||value>1000000000)throw Error('규칙 값은 0~10억 범위의 정수 DBU여야 합니다: '+key)
  if(r.lowerSize<2||r.upperSize<2||r.lowerSize%2||r.upperSize%2)throw Error('정수 중심 좌표를 위해 홀 크기는 양의 짝수 DBU여야 합니다.')
  if(r.upperSize<r.lowerSize+2*r.enclosure)throw Error('위 홀 크기가 아래 홀 크기와 둘러쌈 조건을 만족하지 않습니다.')
  if(r.grid<1||r.pitch<1||r.spacing<1||r.pitch%r.grid||r.searchRadius%r.grid)throw Error('그리드·피치·간격은 양수이며 피치와 탐색 반경은 그리드 배수여야 합니다.')
  if(input.holeLayers[0]===input.holeLayers[1])throw Error('두 홀층을 서로 다르게 지정해 주세요.')
  for(const key of input.holeLayers)if(!/^\d+\/\d+$/.test(key)||key.split('/').some(n=>Number(n)>65535))throw Error('레이어는 0~65535의 layer/datatype 형식입니다.')
  const structures=input.structures.map(id=>input.cell.boundaries.find(s=>s.id===id))
  if(!structures[0]||!structures[1])throw Error('아래·위 구조 도형을 각각 지정해 주세요.')
  const selected=structures as [BoundaryShape,BoundaryShape]
  if(selected[0].layer===selected[1].layer&&selected[0].datatype===selected[1].datatype)throw Error('두 구조층은 서로 다른 layer/datatype이어야 합니다.')
  if(selected.some(s=>input.holeLayers.includes(s.layer+'/'+s.datatype)))throw Error('홀층과 선택한 구조층을 구분해 주세요.')
  selected.forEach(s=>validatePolygon(s.points))
  if(input.protected.length>limits.protect||input.baseline.length>limits.pairs)throw Error('현재 보호 영역 또는 홀 쌍 수 한도를 넘었습니다.')
  for(const p of input.protected)validatePolygon(p.points)
  const ids=new Set<string>()
  for(const p of input.baseline) {
    if(!p.id||ids.has(p.id)||!Number.isSafeInteger(p.x)||!Number.isSafeInteger(p.y)||typeof p.locked!=='boolean')throw Error('홀 쌍 ID·좌표·잠금 정보가 올바르지 않습니다.')
    ids.add(p.id)
    for(const size of [p.lowerSize,p.upperSize])if(size!==undefined&&(!Number.isSafeInteger(size)||size<2||size%2))throw Error('홀 쌍의 저장된 크기가 올바르지 않습니다.')
  }
  for(const v of Object.values(input.roi))if(!Number.isSafeInteger(v))throw Error('ROI 좌표는 정수 DBU여야 합니다.')
  if(input.roi.minX>=input.roi.maxX||input.roi.minY>=input.roi.maxY)throw Error('ROI의 최소·최대 좌표를 확인해 주세요.')
  return selected
}
function gap(a:Bounds,b:Bounds) { return Math.max(b.minX-a.maxX,a.minX-b.maxX,b.minY-a.maxY,a.minY-b.maxY) }
export function buildChecker(input:DesignInput) {
  const structures=validateInput(input),r=input.rules
  const obstacles=input.cell.boundaries.filter(s=>input.holeLayers.includes(s.layer+'/'+s.datatype))
  if(obstacles.length>5000)throw Error('기존 홀층 장애물 5,000개 한도를 넘었습니다.')
  for(const obstacle of obstacles)validatePolygon(obstacle.points)
  return (p:Pair,others:Pair[]):Conflict[]=>{
    const errors:Conflict[]=[]
    const add=(rule:string,related?:string)=>errors.push({pairId:p.id,x:p.x,y:p.y,rule,related})
    if(p.x%r.grid||p.y%r.grid)add('GRID')
    if((p.lowerSize??r.lowerSize)!==r.lowerSize||(p.upperSize??r.upperSize)!==r.upperSize)add('SIZE_SETTING')
    if((p.upperSize??r.upperSize)<(p.lowerSize??r.lowerSize)+2*r.enclosure)add('ENCLOSURE')
    if(p.x<input.roi.minX||p.x>input.roi.maxX||p.y<input.roi.minY||p.y>input.roi.maxY)add('ROI_CENTER')
    for(const i of [0,1]as const) {
      const size=i===0?(p.lowerSize??r.lowerSize):(p.upperSize??r.upperSize)
      if(!containsRect(structures[i].points,pairBox(p,size,r.boundaryGap)))add(i===0?'LOWER_CONTAINMENT':'UPPER_CONTAINMENT',structures[i].id)
      for(const region of input.protected)if(overlapsRect(region.points,pairBox(p,size,r.protectGap)))add('PROTECTION',region.id)
      for(const s of obstacles)if(s.layer+'/'+s.datatype===input.holeLayers[i]&&overlapsRect(s.points,pairBox(p,size,r.spacing)))add('EXISTING_HOLE_SPACING',s.id)
    }
    for(const other of others)if(other.id!==p.id) {
      if(gap(pairBox(p,p.lowerSize??r.lowerSize),pairBox(other,other.lowerSize??r.lowerSize))<r.spacing||gap(pairBox(p,p.upperSize??r.upperSize),pairBox(other,other.upperSize??r.upperSize))<r.spacing)add('PAIR_SPACING',other.id)
    }
    return errors
  }
}
export function solveDesign(input:DesignInput,emit:(e:EngineEvent)=>void=()=>{}):DesignResult {
  const started=performance.now(),r=input.rules
  emit({stage:'validate',message:'실제 구조·규칙·보호 영역 확인',at:new Date().toISOString()})
  const check=buildChecker(input)
  const baseline=input.baseline.map(p=>({...p,lowerSize:p.lowerSize??r.lowerSize,upperSize:p.upperSize??r.upperSize}))
  const result:DesignResult={pairs:[],conflicts:[],changes:[],testedCandidates:0,rejected:{},trace:[],elapsedMs:0,status:'unresolved',algorithm:'paired-square-grid-local-v1'}
  const test=(p:Pair,others:Pair[])=>{
    if(++result.testedCandidates>limits.candidates)throw Error('후보 30,000개 한도를 넘었습니다. ROI를 줄이거나 피치를 늘려 주세요.')
    const errors=check(p,others)
    for(const key of new Set(errors.map(e=>e.rule)))result.rejected[key]=(result.rejected[key]??0)+1
    if(result.trace.length<500)result.trace.push({pairId:p.id,x:p.x,y:p.y,accepted:!errors.length,reason:errors.map(e=>e.rule).join(',')||'ACCEPT'})
    return !errors.length
  }
  if(input.mode==='check')result.pairs=baseline
  else if(input.mode==='generate') {
    // Previously managed holes are kept; generation fills free grid positions.
    result.pairs=[...baseline]
    emit({stage:'candidates',message:'두 홀층을 함께 만족하는 그리드 후보 평가',at:new Date().toISOString()})
    const nx=Math.floor((input.roi.maxX-Math.ceil(input.roi.minX/r.pitch)*r.pitch)/r.pitch)+1
    const ny=Math.floor((input.roi.maxY-Math.ceil(input.roi.minY/r.pitch)*r.pitch)/r.pitch)+1
    if(nx*ny>limits.candidates)throw Error('ROI의 그리드 후보가 30,000개를 넘습니다. ROI 또는 피치를 조정해 주세요.')
    let n=1
    for(let y=Math.ceil(input.roi.minY/r.pitch)*r.pitch;y<=input.roi.maxY;y+=r.pitch)for(let x=Math.ceil(input.roi.minX/r.pitch)*r.pitch;x<=input.roi.maxX;x+=r.pitch) {
      while(result.pairs.some(p=>p.id==='P'+n))n++
      const p:Pair={id:'P'+n,x,y,locked:false,lowerSize:r.lowerSize,upperSize:r.upperSize}
      if(test(p,result.pairs)){result.pairs.push(p);n++;if(result.pairs.length>limits.pairs)throw Error('홀 쌍 3,000개 한도를 넘었습니다.')}
    }
  } else {
    emit({stage:'repair',message:'잠금·정상 쌍 보존 후 충돌 쌍의 가까운 후보 탐색',at:new Date().toISOString()})
    const affected=baseline.filter(p=>!p.locked&&check(p,baseline).length)
    const ids=new Set(affected.map(p=>p.id))
    result.pairs=baseline.filter(p=>!ids.has(p.id))
    const steps=Math.floor(r.searchRadius/r.grid)
    if((steps*2+1)**2>limits.candidates)throw Error('국소 탐색 후보가 너무 많습니다. 탐색 반경을 줄이거나 그리드를 늘려 주세요.')
    const offsets:Point[]=[]
    for(let y=-steps;y<=steps;y++)for(let x=-steps;x<=steps;x++)if(x*x+y*y<=steps*steps)offsets.push([x*r.grid,y*r.grid])
    offsets.sort((a,b)=>a[0]**2+a[1]**2-b[0]**2-b[1]**2||a[1]-b[1]||a[0]-b[0])
    for(const old of affected) {
      let found:Pair|undefined
      for(const [dx,dy]of offsets) {
        const candidate={...old,x:Math.round(old.x/r.grid)*r.grid+dx,y:Math.round(old.y/r.grid)*r.grid+dy,lowerSize:r.lowerSize,upperSize:r.upperSize}
        if(test(candidate,result.pairs)){found=candidate;break}
      }
      result.pairs.push(found??old)
    }
  }
  emit({stage:'check',message:'최종 전체 쌍 재검사와 변경 내역 생성',at:new Date().toISOString()})
  for(const p of result.pairs)result.conflicts.push(...check(p,result.pairs))
  const old=new Map(baseline.map(p=>[p.id,p]))
  result.changes=result.pairs.map(p=>{const before=old.get(p.id);return {id:p.id,kind:!before?'added':before.x!==p.x||before.y!==p.y?'moved':before.lowerSize!==p.lowerSize||before.upperSize!==p.upperSize?'resized':'preserved',from:before?[before.x,before.y]:undefined,to:[p.x,p.y],locked:p.locked,sizesBefore:before?[before.lowerSize,before.upperSize]:undefined,sizesAfter:[p.lowerSize??r.lowerSize,p.upperSize??r.upperSize]}})
  if(!result.pairs.length)result.conflicts.push({pairId:'NONE',x:input.roi.minX,y:input.roi.minY,rule:'NO_MANAGED_PAIRS'})
  result.status=result.conflicts.length?'unresolved':'feasible'
  result.elapsedMs=Math.round(performance.now()-started)
  emit({stage:'done',message:'실제 계산 종료 · '+result.status,at:new Date().toISOString()})
  return result
}
