import './release-comparison.css'
import type { DesignInput, Pair } from './design-engine.ts'
import type { ReleaseMetrics, ReleaseProof } from './release-proof.ts'

type Inspection = {passed:boolean;klayoutVersion:string;outputSha256:string;violations:unknown[]}
const number=(v:number)=>v.toFixed(5)

export function mountReleaseComparison(target:HTMLElement,input:DesignInput,proof:ReleaseProof,report:Inspection) {
  target.classList.add('release-comparison')
  target.innerHTML=`<header><h2>릴리스 모델 비교</h2><p data-status></p><p data-proof></p></header>
    <div class="release-legend"><span>공급 부족도 1 − c</span><i></i><span>0 → 1</span><span>보호 영역은 보라색, 잠금은 청록색</span></div>
    <div class="release-views"></div>
    <label>홀 쌍 위치와 규칙 <select data-pair><option value="">선택</option></select></label>
    <output data-point aria-live="polite">도면을 클릭하면 격자 공급값을 확인할 수 있습니다.</output>
    <p data-rules></p><p data-sensitivity></p>`
  const get=<T extends HTMLElement=HTMLElement>(s:string)=>target.querySelector<T>(s)!
  const statuses={improved:'목적값 개선', 'no-improvement':'비교한 후보에서 개선 없음',
    infeasible:'보호·잠금 등 기하 제약 미해결', unavailable:'모델을 계산할 격자 셀 없음'}
  const describe=(field:ReleaseMetrics)=>`제곱평균 부족도 ${number(field.objective)} · 최대 부족도 ${number(field.worstDeficit)}`
  get('[data-status]').textContent=statuses[proof.status]+(proof.before&&proof.after
    ?` · 제곱평균 부족도 ${number(proof.before.objective)} → ${number(proof.after.objective)}`:'')
  const independent=proof.independent
  const batches=proof.evaluationBackend?.startsWith('NumPy')&&proof.evaluationBatches? ` · ${proof.evaluationBatches}개 묶음 계산`:''
  get('[data-proof]').textContent=`${proof.grid.cells.length}셀 · ${proof.groups}쌍 후보군 · ${proof.evaluated}개 배치 평가${batches}. ${report.klayoutVersion} 검사 ${report.passed?'통과':'미통과'} (${report.violations.length}건).${independent?' 독립 풀이 최대 |Δc| '+independent.fieldMaxAbsError.toExponential(2)+'.':''}`
  const unit=(n:number)=>(n*proof.grid.dbu).toFixed(2)
  const r=input.rules
  get('[data-rules]').textContent=`홀 ${unit(r.lowerSize)} / ${unit(r.upperSize)} µm · 간격 ≥ ${unit(r.spacing)} µm · 둘러쌈 ≥ ${unit(r.enclosure)} µm · 보호 경계 ≥ ${unit(r.protectGap)} µm. HF 공급 대리지표 (무차원).`
  get('[data-sensitivity]').textContent=proof.sensitivity?.map(v=>`ℓ ${v.lengthUm} µm  ${number(v.before.objective)} → ${number(v.after.objective)}`).join('  /  ')??''
  const maps=[
    ...(proof.originalField?[{title:'보호 영역 변경 직후',field:proof.originalField,pairs:input.baseline}]:[]),
    ...(proof.before?[{title:'격자 기준안 · 규칙 보정',field:proof.before,pairs:proof.baseline}]:[]),
    ...(proof.after?[{title:'모델 채택안',field:proof.after,pairs:proof.chosen}]:[])
  ]
  const menu=get<HTMLSelectElement>('[data-pair]')
  const inspect=get<HTMLOutputElement>('[data-point]')
  const xy=(p:Pair|undefined)=>p?`(${unit(p.x)}, ${unit(p.y)})`:'—'
  const moved=new Set(proof.chosen.filter((p,i)=>p.x!==proof.baseline[i]?.x||p.y!==proof.baseline[i]?.y).map(p=>p.id))
  const conflictIds=new Set(proof.conflicts.map(c=>c.pairId))
  const originalConflicts=new Set(proof.originalConflicts?.map(c=>c.pairId))
  const {grid:{step,cells}}=proof
  const {roi}=input
  const structures=input.cell.boundaries.filter(s=>input.structures.includes(s.id))
  const padding=28
  const canvases=maps.map(map=>{
    const figure=document.createElement('figure')
    const caption=document.createElement('figcaption')
    caption.textContent=map.title+' · '+describe(map.field)
    const canvas=document.createElement('canvas')
    canvas.width=600; canvas.height=385
    canvas.tabIndex=0;canvas.setAttribute('aria-label',map.title+' 공급 부족도 지도')
    figure.append(caption,canvas);get('.release-views').append(figure)
    return {map,canvas}
  })
  function transform(canvas:HTMLCanvasElement) {
    const scale=Math.min((canvas.width-padding*2)/(roi.maxX-roi.minX),(canvas.height-padding*2)/(roi.maxY-roi.minY))
    const left=(canvas.width-(roi.maxX-roi.minX)*scale)/2, top=(canvas.height-(roi.maxY-roi.minY)*scale)/2
    return {scale, px:(x:number)=>left+(x-roi.minX)*scale, py:(y:number)=>top+(roi.maxY-y)*scale}
  }
  function draw() {
    for (const {map,canvas} of canvases) {
      const ctx=canvas.getContext('2d')!
      const {scale,px,py}=transform(canvas)
      ctx.fillStyle='#10151c';ctx.fillRect(0,0,canvas.width,canvas.height)
      ctx.save()
      ctx.beginPath();ctx.rect(px(roi.minX),py(roi.maxY),(roi.maxX-roi.minX)*scale,(roi.maxY-roi.minY)*scale);ctx.clip()
      cells.forEach((cell,i)=>{
        const v=Math.max(0,Math.min(1,1-map.field.values[i]!))
        ctx.fillStyle=`rgb(${Math.round(22+218*v)},${Math.round(66+86*v)},${Math.round(116-75*v)})`
        ctx.fillRect(px(cell.x-step/2),py(cell.y+step/2),step*scale+.3,step*scale+.3)
      })
      const drawOutline=(points:number[][],stroke:string,fill?:string)=>{
        ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(px(p[0]!),py(p[1]!)):ctx.moveTo(px(p[0]!),py(p[1]!)));ctx.closePath()
        if(fill){ctx.fillStyle=fill;ctx.fill()}ctx.strokeStyle=stroke;ctx.stroke()
      }
      structures.forEach(s=>drawOutline(s.points,'#8b9ab0'))
      input.protected.forEach(s=>drawOutline(s.points,'#d39bff','#59289985'))
      for(const pair of map.pairs){
        const side=(pair.upperSize??r.upperSize)*scale
        const selected=pair.id===menu.value
        const conflict=map.field===proof.originalField?originalConflicts.has(pair.id):conflictIds.has(pair.id)&&!report.passed
        ctx.strokeStyle=selected?'#ffeb84':conflict?'#ff7470':pair.locked?'#55f2d5':'#fff'
        ctx.lineWidth=selected?3:1.4
        ctx.strokeRect(px(pair.x)-side/2,py(pair.y)-side/2,side,side)
      }
      ctx.restore()
    }
  }
  const pairText=(id:string)=>{
    const initial=input.baseline.find(p=>p.id===id)
    const base=proof.baseline.find(p=>p.id===id)
    const chosen=proof.chosen.find(p=>p.id===id)
    const violations=[...new Set([...(proof.originalConflicts??[]),...proof.conflicts].filter(c=>c.pairId===id).map(c=>c.rule+' '+(c.related??'')))].join(', ')
    return `${id} · 입력 ${xy(initial)} → 기준 ${xy(base)} → 결과 ${xy(chosen)} µm${chosen?.locked?' · 잠금':''}${violations?' · '+violations:''}.`
  }
  for(const pair of [...proof.chosen].sort((a,b)=>Number(moved.has(b.id))-Number(moved.has(a.id)))){
    menu.append(new Option(pair.id+(pair.locked?' · 잠금':moved.has(pair.id)?' · 모델 이동':''),pair.id))
  }
  menu.onchange=()=>{inspect.textContent=menu.value?pairText(menu.value):'';draw()}
  for(const {map,canvas} of canvases)canvas.onclick=event=>{
    const bounds=canvas.getBoundingClientRect(),tr=transform(canvas)
    const x=roi.minX+((event.clientX-bounds.left)*canvas.width/bounds.width-tr.px(roi.minX))/tr.scale
    const y=roi.maxY-((event.clientY-bounds.top)*canvas.height/bounds.height-tr.py(roi.maxY))/tr.scale
    const cell=cells.findIndex(c=>Math.abs(c.x-x)<=step/2&&Math.abs(c.y-y)<=step/2)
    const pair=map.pairs.find(p=>Math.max(Math.abs(p.x-x),Math.abs(p.y-y))<=(p.upperSize??r.upperSize)/2)
    menu.value=pair?.id??''
    inspect.textContent=[pair?pairText(pair.id):'', `${map.title} · (${unit(x)}, ${unit(y)}) µm`,
      cell>=0?'공급 부족도 '+number(1-map.field.values[cell]!):'계산 영역 밖'].filter(Boolean).join(' · ')
    draw()
  }
  draw()
}
