import {solveDesign,rectPoints} from './design-engine.ts'
import {pointBounds} from './boundary-data.ts'
import type {BoundaryCell,BoundaryShape} from './boundary-data.ts'
import type {DesignInput} from './design-engine.ts'
export function explanationData(){
  const shape=(id:string,layer:number,halfX:number,halfY:number):BoundaryShape=>{const points=rectPoints({minX:-halfX,minY:-halfY,maxX:halfX,maxY:halfY});return{id,recordOffset:0,layer,datatype:0,points,bounds:pointBounds(points)}}
  const cell:BoundaryCell={name:'SYNTHETIC_EXPLANATION',boundaries:[shape('lower',100,150000,100000),shape('upper',101,160000,110000)],omitted:{},bounds:null}
  const input:DesignInput={cell,structures:['lower','upper'],holeLayers:['200/0','201/0'],rules:{lowerSize:3000,upperSize:7000,spacing:3000,enclosure:2000,boundaryGap:1000,protectGap:1000,pitch:30000,grid:1000,searchRadius:20000},roi:{minX:-140000,minY:-90000,maxX:140000,maxY:90000},protected:[],baseline:[],mode:'generate'}
  const before=solveDesign(input)
  const after=solveDesign({...input,mode:'repair',baseline:before.pairs,protected:[{id:'protected',points:rectPoints({minX:-10000,minY:-8000,maxX:10000,maxY:8000})}]})
  return{before:before.pairs,after:after.pairs}
}
