declare module '*.css'

