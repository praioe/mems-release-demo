import {rectPoints,solveDesign} from './design-engine.ts'
import type { BoundaryCell } from './boundary-data.ts'
import type { DesignInput } from './design-engine.ts'

export function releaseDemo(cell:BoundaryCell,dbu:number) {
  const u=(um:number)=>Math.round(um/dbu)
  const rectangle=(id:string,x:number,y:number,width:number,height:number)=>({
    id,points:rectPoints({minX:u(x-width/2),maxX:u(x+width/2),minY:u(y-height/2),maxY:u(y+height/2)})
  })
  const initial:DesignInput={
    cell,structures:[cell.boundaries.find(s=>s.layer===100)!.id,cell.boundaries.find(s=>s.layer===101)!.id],
    holeLayers:['200/0','201/0'],
    roi:{minX:u(-140),minY:u(-90),maxX:u(140),maxY:u(90)},
    rules:{lowerSize:u(3),upperSize:u(7),spacing:u(3),enclosure:u(2),boundaryGap:u(1),
      protectGap:u(1),pitch:u(30),grid:u(1),searchRadius:u(20)},
    protected:[],baseline:[],mode:'generate',releaseModel:true
  }
  const baseline=solveDesign(initial).pairs.map(p=>({...p,locked:p.x===0&&p.y===0}))
  const fixed=rectangle('P_FIXED',45,-43,10,10)
  const before=[rectangle('P_MOVED',-45,15,10,14),fixed]
  const moved=[rectangle('P_MOVED',-60,0,10,14),fixed]
  const repair:DesignInput={...initial,mode:'repair',baseline,protected:moved}
  const blocked:DesignInput={...repair,protected:[rectangle('P_MOVED',0,0,10,14),fixed]}
  return {initial,before,repair,blocked}
}
