import { parseBoundaryLayout } from './boundary-data.ts'
import { expandBoundaryCell } from './hierarchy-data.ts'
import type { BoundaryLayout, GeometryRequest, GeometryResponse } from './boundary-data.ts'

const scope = globalThis as unknown as {
  onmessage: ((event: MessageEvent<GeometryRequest>) => void) | null
  postMessage(message: GeometryResponse): void
}
let layout: BoundaryLayout | null = null
let revision = -1
scope.onmessage = (event) => {
  const request = event.data
  try {
    if (request.type === 'load') {
      revision = request.revision
      layout = parseBoundaryLayout(new Uint8Array(request.bytes))
      scope.postMessage({
        type: 'ready', revision,
        dbuMicrometers: layout.summary.dbuMicrometers,
        boundaryCount: [...layout.cells.values()].reduce((sum, cell) => sum + cell.boundaries.length, 0),
        catalog: [...layout.cells.values()].map(cell => ({ name: cell.name, boundaryCount: cell.boundaries.length, omitted: cell.omitted })),
      })
    } else if (request.revision === revision && layout) {
      const cell = request.includeHierarchy ? expandBoundaryCell(layout, request.cellName) : layout.cells.get(request.cellName)
      if (!cell) throw new Error('선택한 셀이 없습니다.')
      if (!request.includeHierarchy && (cell.boundaries.length > 5000 || cell.boundaries.reduce((sum, shape) => sum + shape.points.length, 0) > 200000)) throw new Error('현재 직접 도형 보기 한도인 다각형 5천 개 또는 좌표 20만 점을 넘었습니다.')
      scope.postMessage({ type: 'cell', revision, requestId: request.requestId, cell })
    }
  } catch (error) {
    if (request.type === 'load') layout = null
    scope.postMessage({ type: 'error', revision: request.revision, requestId: request.type === 'cell' ? request.requestId : undefined, error: error instanceof Error ? error.message : String(error) })
  }
}

