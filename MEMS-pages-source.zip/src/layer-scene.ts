import type {Pair} from './design-engine.ts'

type V=[number,number,number]
const clamp=(n:number)=>Math.max(0,Math.min(1,n))
const smooth=(n:number)=>{const t=clamp(n);return t*t*(3-2*t)}
export class LayerScene {
  private ctx:CanvasRenderingContext2D
  private width=1
  private height=1
  private frame=0
  private visible=true
  private running=true
  private paused=false
  private progress=0
  private last=0
  private reduced=matchMedia('(prefers-reduced-motion: reduce)')
  private observer:IntersectionObserver
  private resize:ResizeObserver
  private canvas:HTMLCanvasElement
  private mode:'hero'|'story'
  private before:Pair[]
  private after:Pair[]
  constructor(canvas:HTMLCanvasElement,mode:'hero'|'story',before:Pair[]=[],after:Pair[]=[]) {
    this.canvas=canvas;this.mode=mode;this.before=before;this.after=after
    const ctx=canvas.getContext('2d',{alpha:true});if(!ctx)throw Error('Canvas is unavailable');this.ctx=ctx
    this.resize=new ResizeObserver(()=>this.measure());this.resize.observe(canvas)
    this.observer=new IntersectionObserver(entries=>{this.visible=!!entries[0]?.isIntersecting;this.schedule()},{rootMargin:'100px'});this.observer.observe(canvas)
    this.reduced.addEventListener('change',()=>{this.draw(0);this.schedule()})
    document.addEventListener('visibilitychange',()=>this.schedule())
    this.measure();this.schedule()
  }
  private measure(){const r=this.canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,1.7);this.width=Math.max(r.width,1);this.height=Math.max(r.height,1);this.canvas.width=Math.round(this.width*dpr);this.canvas.height=Math.round(this.height*dpr);this.ctx.setTransform(dpr,0,0,dpr,0,0);this.draw(0)}
  setProgress(value:number){this.progress=clamp(value);if(this.mode==='story')this.draw(0)}
  setRunning(value:boolean){this.running=value;this.schedule()}
  setPaused(value:boolean){this.paused=value;this.schedule();if(value)this.draw(this.last)}
  private schedule(){cancelAnimationFrame(this.frame);if(this.mode==='hero'&&this.running&&this.visible&&!this.paused&&!document.hidden&&!this.reduced.matches)this.frame=requestAnimationFrame(t=>this.tick(t));else if(this.mode==='hero')this.draw(this.last)}
  private tick(t:number){if(t-this.last>32){this.draw(t);this.last=t}if(this.running&&this.visible&&!this.paused&&!document.hidden&&!this.reduced.matches)this.frame=requestAnimationFrame(time=>this.tick(time))}
  private draw(time:number){
    const c=this.ctx,w=this.width,h=this.height;c.clearRect(0,0,w,h)
    const story=this.mode==='story',p=this.progress,phase=time/1000
    const angle=story?-.38+.14*p:-.38+Math.sin(phase*.16)*.055
    const tilt=story?.72:.76,scale=Math.min(w/(story?520:620),h/(story?370:365))
    const cx=w*(story?.54:.83),cy=h*(story?.55:.56)
    const gap=story?76-42*smooth(p*.9):47+Math.sin(phase*.28)*13
    const project=([x,y,z]:V):[number,number]=>{const a=x*Math.cos(angle)-y*Math.sin(angle),b=x*Math.sin(angle)+y*Math.cos(angle);const sy=b*Math.cos(tilt)-z*Math.sin(tilt),depth=b*Math.sin(tilt)+z*Math.cos(tilt),perspective=1050/(1050-depth);return[cx+a*scale*perspective,cy+sy*scale*perspective]}
    const path=(points:V[],close=true)=>{const first=project(points[0]!);c.moveTo(...first);for(const v of points.slice(1))c.lineTo(...project(v));if(close)c.closePath()}
    const outline=(z:number,inset=0):V[]=>[[-164+inset,-110+inset,z],[148-inset,-110+inset,z],[164-inset,-94+inset,z],[164-inset,110-inset,z],[-148+inset,110-inset,z],[-164+inset,94-inset,z]]
    let points:Pair[]
    if(story){const transition=smooth((p-.58)/.34),next=new Map(this.after.map(v=>[v.id,v]));points=this.before.map(old=>{const n=next.get(old.id)??old;return{...old,x:(old.x+(n.x-old.x)*transition)/1000,y:(old.y+(n.y-old.y)*transition)/1000}})}
    else{points=[];for(let y=-80;y<=80;y+=20)for(let x=-140;x<=140;x+=20)if(Math.abs(x)>24||Math.abs(y)>20)points.push({id:x+':'+y,x,y,locked:false})}
    const square=(x:number,y:number,size:number,z:number):V[]=>[[x-size/2,y-size/2,z],[x+size/2,y-size/2,z],[x+size/2,y+size/2,z],[x-size/2,y+size/2,z]]
    const layer=(z:number,upper:boolean)=>{
      const shape=outline(z),bottom=outline(z-6)
      for(let i=0;i<shape.length;i++){const j=(i+1)%shape.length;c.beginPath();path([shape[i]!,shape[j]!,bottom[j]!,bottom[i]!]);c.fillStyle=upper?'#34444e':'#4e1027';c.fill();c.strokeStyle=upper?'#80919a':'#335465';c.lineWidth=.5;c.stroke()}
      const size=upper?(story?7:8):(story?3:4)
      c.beginPath();path(shape);for(const hole of points)path(square(hole.x,hole.y,size,z))
      const metal=c.createLinearGradient(w*.35,h*.1,w*.95,h*.8)
      if(upper){metal.addColorStop(0,'#d2dce0');metal.addColorStop(.28,'#f0f4f4');metal.addColorStop(.53,'#839aa5');metal.addColorStop(.78,'#c7d7dd');metal.addColorStop(1,'#637f8e')}
      else{metal.addColorStop(0,'#6c1436');metal.addColorStop(.45,'#c72a58');metal.addColorStop(1,'#7b1237')}
      c.fillStyle=metal;c.fill('evenodd');c.strokeStyle=upper?'#e6f0f1':'#86a4b5';c.lineWidth=.65;c.stroke()
      c.save();c.clip('evenodd');for(let line=-106;line<110;line+=3){c.beginPath();path([[-165,line,z],[165,line,z]],false);c.strokeStyle=upper?'rgba(255,255,255,.08)':'rgba(169,206,220,.05)';c.lineWidth=.35;c.stroke()}c.restore()
      c.beginPath();path(outline(z+.05,8));c.strokeStyle=upper?'rgba(20,53,68,.35)':'rgba(180,213,223,.28)';c.lineWidth=.65;c.stroke()
      for(const hole of points){c.beginPath();path(square(hole.x,hole.y,size,z));c.strokeStyle=upper?'rgba(28,51,61,.72)':'rgba(13,36,50,.85)';c.lineWidth=.65;c.stroke();const edge=square(hole.x,hole.y,size,z);c.beginPath();path([edge[0]!,edge[1]!,[edge[1]![0],edge[1]![1],z-4],[edge[0]![0],edge[0]![1],z-4]]);c.fillStyle='rgba(3,18,27,.5)';c.fill()}
      // Etched alignment marks are part of the two-layer concept illustration.
      for(const x of [-153,153])for(const y of [-98,98]){c.beginPath();path([[x-3,y,z+.1],[x+3,y,z+.1]],false);path([[x,y-3,z+.1],[x,y+3,z+.1]],false);c.strokeStyle=upper?'#516c79':'#a2c2ce';c.lineWidth=.75;c.stroke()}
    }
    // The subtle contact shadow represents depth, not a computed field.
    c.save();c.beginPath();path(outline(-17));c.fillStyle='rgba(0,0,0,.3)';c.shadowColor='#000';c.shadowBlur=25;c.shadowOffsetY=25;c.fill();c.restore()
    layer(0,false);layer(gap,true)
    const showProtect=story?smooth((p-.27)/.19):.8
    if(showProtect>0){c.save();c.globalAlpha=showProtect;c.beginPath();path(story?[[-10,-8,gap+.2],[10,-8,gap+.2],[10,8,gap+.2],[-10,8,gap+.2]]:square(0,0,54,gap+.2));c.fillStyle='rgba(187,140,65,.14)';c.fill();c.setLineDash([4,3]);c.strokeStyle=story?'#bd8c45':'#dec793';c.lineWidth=1.2;c.stroke();c.restore()}
    if(story&&p>.35){const old=this.before.find(v=>v.x===0&&v.y===0),changed=old?this.after.find(v=>v.id===old.id):null;if(changed){const t=smooth((p-.58)/.34),x=changed.x*t/1000,y=changed.y*t/1000;c.save();c.beginPath();path(square(x,y,11,gap+.8));c.strokeStyle=p<.66?'#d46b53':'#b61a48';c.lineWidth=1.7;c.stroke();c.setLineDash([3,3]);c.globalAlpha=.5;c.beginPath();path(square(0,0,11,gap+.7));c.strokeStyle='#bb7759';c.stroke();c.restore()}}
    if(story){c.font='500 12px "Pretendard Variable", sans-serif';c.fillStyle='#59696e';const label=(text:string,anchor:V,dx:number,dy:number)=>{const [x,y]=project(anchor);c.beginPath();c.moveTo(x,y);c.lineTo(x+dx,y+dy);c.lineTo(x+dx+55,y+dy);c.strokeStyle='#8a9da5';c.lineWidth=.7;c.stroke();c.fillText(text,x+dx+5,y+dy-8)};label('상부 홀층',[164,-70,gap],20,-25);label('하부 홀층',[164,78,0],24,34)}
  }
  dispose(){cancelAnimationFrame(this.frame);this.observer.disconnect();this.resize.disconnect()}
}
