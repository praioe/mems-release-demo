import './run-view.css'
import {brand,icon} from './icons.ts'
import {fetchJob,stageList,localTime} from './pipeline-client.ts'
import type {PipelineJob} from './pipeline-client.ts'
import {mountReleaseComparison} from './release-comparison.ts'
import {ResultGeometry} from './result-geometry.ts'
export function mountRun(root:HTMLElement,id:string){
 root.innerHTML=`<main class="run-page" data-state="running"><div class="run-overview"><header><a class="brand" href="#home">${brand}</a><span class="run-id"></span><a href="#workspace" class="run-back">워크스페이스 ${icon('arrow')}</a></header><div class="run-title"><p id="run-state" class="editorial-label" role="status">계산 연결 중</p><h1 id="run-title">실행 준비 중</h1><div id="run-stats"></div><dl id="run-objective" class="run-objective" hidden><div><dt>제곱평균 부족도 · 무차원</dt><dd id="objective-values"></dd></div><div><dt>기준안 대비</dt><dd id="objective-delta"></dd></div></dl></div><div class="run-layout"><section class="run-drawing"><div class="result-toolbar"><span id="result-cell">실행 모니터</span><div><button id="view-3d" aria-pressed="true">3D</button><button id="view-2d" aria-pressed="false">2D</button><button id="view-motion" aria-label="도면 회전 일시정지" aria-pressed="false">${icon('pause')}</button></div></div><div id="run-wait"><canvas id="live-input" role="img" aria-label="계산 중인 실제 입력 도면"></canvas><div class="live-caption"><span class="wait-line"></span><h2 id="wait-label">계산 준비 중</h2><p id="process-detail"></p></div></div><div id="result-views" hidden><figure><figcaption><span class="comparison-phase" id="layout-baseline-phase">비교 전</span><span id="layout-baseline-title">입력 배치</span></figcaption><canvas id="result-before" aria-labelledby="layout-baseline-phase layout-baseline-title" role="img"></canvas></figure><span class="comparison-arrow" aria-hidden="true"><svg viewBox="0 0 88 52" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round" vector-effect="non-scaling-stroke"><path d="M5 17h48V5l30 21-30 21V35H5z"/></svg></span><figure><figcaption><span class="comparison-phase" id="layout-chosen-phase">비교 후</span><span id="layout-chosen-title">계산 결과</span></figcaption><canvas id="result-after" aria-labelledby="layout-chosen-phase layout-chosen-title" role="img"></canvas></figure></div><div class="result-bottom"><div class="result-note" id="result-note"></div><ul class="result-legend" id="result-legend" aria-label="비교 도면 범례" hidden><li>보호 영역</li><li>잠금</li><li>충돌</li></ul><button id="trace-replay" hidden>계산 기록 재생</button><span id="trace-counter"></span></div></section><aside class="run-evidence"><div id="run-live-stages"><h2>실행 단계</h2><ol id="run-stages"></ol></div><div class="run-downloads" id="run-downloads" hidden><a id="run-gds" class="primary-link">결과 GDS ${icon('down')}</a><a id="run-report">KLayout 검사 기록</a><a id="run-scipy" target="_blank" rel="noopener" hidden>SciPy 독립 검산 ${icon('arrow')}</a><a href="#verification-details" id="verification-link">수치와 변경 좌표 보기 ${icon('arrow')}</a></div><p id="run-error" role="status"></p></aside></div></div><div id="verification-details" class="verification-details" tabindex="-1" hidden><details class="run-artifacts"><summary>실행 단계와 산출물</summary><div id="run-completed-stages"></div><div id="run-extra-downloads"><a id="run-manifest">변경·좌표 기록</a><a id="run-log">실행 로그</a></div></details><details class="run-log"><summary>실제 실행 기록</summary><pre id="live-log"></pre></details><section id="release-fields" hidden></section><section id="change-section" hidden><h2><span id="change-title">변경 좌표</span> <span>µm</span></h2><div class="changes-table"><table><thead><tr><th>홀 쌍</th><th>변경</th><th id="change-before">입력 X, Y</th><th id="change-after">결과 X, Y</th><th>잠금</th></tr></thead><tbody id="change-rows"></tbody></table></div></section></div></main>`
 const el=<T extends HTMLElement=HTMLElement>(s:string)=>root.querySelector<T>('#'+s)!
 let disposed=false,timer:ReturnType<typeof setTimeout>|null=null,rendered=false,seen=0,viewerPolls=0,views:ResultGeometry[]=[],rotating=true,liveView:ResultGeometry|null=null,replayFrame=0
 root.querySelector('.run-id')!.textContent=id==='pending'?'연결 중':id.slice(0,8)
 const flat=(v:boolean)=>{el('view-motion').hidden=v;views.forEach(s=>s.setFlat(v));el('view-2d').setAttribute('aria-pressed',String(v));el('view-3d').setAttribute('aria-pressed',String(!v));el('result-note').textContent=v?'동일 축척 · XY':'실제 GDS 좌표 · 층 간격과 두께는 표시용'}
 el('view-2d').onclick=()=>flat(true);el('view-3d').onclick=()=>flat(false);el('view-motion').onclick=()=>{rotating=!rotating;views.forEach(s=>s.setRotating(rotating));el('view-motion').innerHTML=icon(rotating?'pause':'play');el('view-motion').setAttribute('aria-pressed',String(!rotating));el('view-motion').setAttribute('aria-label',rotating?'도면 회전 일시정지':'도면 회전 재생')}
 el('verification-link').onclick=event=>{
  event.preventDefault()
  const details=el('verification-details')
  details.focus({preventScroll:true})
  details.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'})
 }
 let replayJob:PipelineJob|null=null
 el('trace-replay').onclick=()=>{const trace=replayJob?.result?.manifest.result.trace??[];if(!trace.length)return;cancelAnimationFrame(replayFrame);let n=0,last=0;const advance=(at:number)=>{if(disposed)return;if(at-last>45){n++;views[1]?.setTraceCount(n);el('trace-counter').textContent='기록 재생 '+n+' / '+trace.length;last=at}if(n<trace.length)replayFrame=requestAnimationFrame(advance);else el('trace-counter').textContent='기록 '+trace.length+'개 · 재생 완료'};replayFrame=requestAnimationFrame(advance)}
 function updateStatus(job:PipelineJob){
  const result=job.result
  const passed=result?.check.report.passed&&result.manifest.result.status==='feasible'
  const state=job.status==='completed'?(passed?'passed':'unresolved'):job.status
  const labels:Record<string,string>={running:'계산 진행 중',passed:'독립 검사 통과',unresolved:'검사 확인 필요',failed:'실행 실패',cancelled:'실행 취소'}
  root.querySelector<HTMLElement>('.run-page')!.dataset.state=state
  const label=labels[state]??'실행 준비 중'
  if(el('run-state').textContent!==label)el('run-state').textContent=label
  if(rendered||!result)return
  const proof=result.manifest.result.release
  const before=proof?.before?.objective,after=proof?.after?.objective
  if(before===undefined||after===undefined||!Number.isFinite(before)||!Number.isFinite(after))return
  el('run-objective').hidden=false
  el('objective-values').textContent=before.toFixed(6)+' → '+after.toFixed(6)
  el('objective-delta').textContent=before===after?'변화 없음':before>0?Math.abs((before-after)/before*100).toFixed(2)+'% '+(after<before?'감소':'증가'):'—'
 }
 function renderCoordinates(manifest:NonNullable<PipelineJob['result']>['manifest']){
  const {result,dbuMicrometers:unit}=manifest
  const position=(point:number[]|undefined)=>point?point.map(v=>(v*unit).toFixed(3)).join(', '):'—'
  const proof=result.release
  const hasModelComparison=!!(proof?.before&&proof.after)
  let rows:Pick<(typeof result.changes)[number],'id'|'kind'|'from'|'to'|'locked'>[]=result.changes
  if(hasModelComparison){
   el('change-title').textContent='격자 기준안과 채택 좌표'
   el('change-before').textContent='기준 X, Y'
   el('change-after').textContent='채택 X, Y'
   const baseline=new Map(proof.baseline.map(pair=>[pair.id,pair]))
   rows=proof.chosen.map(pair=>{
    const before=baseline.get(pair.id)
    const moved=before&&(before.x!==pair.x||before.y!==pair.y)
    const resized=before&&(before.upperSize!==pair.upperSize||before.lowerSize!==pair.lowerSize)
    return {id:pair.id,kind:!before?'added':moved?'moved':resized?'resized':'preserved',
     from:before?[before.x,before.y]:undefined,to:[pair.x,pair.y],locked:pair.locked}
   })
  }
  const names={added:'추가',moved:'이동',resized:'크기 변경',preserved:'보존'}
  const fragment=document.createDocumentFragment()
  for(const row of [...rows].sort((a,b)=>Number(a.kind==='preserved')-Number(b.kind==='preserved')).slice(0,3000)){
   const tr=document.createElement('tr')
   for(const value of [row.id,names[row.kind],position(row.from),position(row.to),row.locked?'잠금':'—']){
    const td=document.createElement('td')
    td.textContent=value
    tr.append(td)
   }
   fragment.append(tr)
  }
  el('change-rows').append(fragment)
  el('change-section').hidden=false
 }
 const render=(job:PipelineJob)=>{if(job.preview&&!liveView&&job.preview.structures.every(id=>job.preview!.cell.boundaries.some(s=>s.id===id)))liveView=new ResultGeometry(el<HTMLCanvasElement>('live-input'),{input:job.preview},true);stageList(el('run-stages'),job);updateStatus(job);el('run-title').textContent=job.status==='completed'?(job.result!.check.report.passed&&job.result!.manifest.result.status==='feasible'?'배치 결과':'배치 검토'):job.status==='failed'?'실행 실패':job.status==='cancelled'?'실행 취소':'홀 배치 계산';el('wait-label').textContent=job.stages.find(s=>s.state==='running')?.label??job.error??'결과 준비 중';el('process-detail').textContent=job.events.filter(e=>e.pid).map(e=>e.program+' · PID '+e.pid).join(' / ');el('run-error').textContent=job.error??''
 if(job.events.length!==seen){seen=job.events.length;el('live-log').textContent=job.events.map(e=>localTime(e.at)+'  '+e.message+(e.pid?'  '+e.program+'  PID '+e.pid:'')).join('\n');el('live-log').scrollTop=el('live-log').scrollHeight}
 if(job.stats){el('run-stats').textContent=job.stats.pairs+'쌍 · 충돌 '+job.stats.conflicts+'건'}
 if(job.status==='completed'&&!rendered){rendered=true;liveView?.dispose();liveView=null;replayJob=job;el('trace-replay').hidden=!job.result!.manifest.result.trace.length;const {manifest:m,check}=job.result!;el('run-wait').hidden=true;el('result-views').hidden=false;el('result-legend').hidden=false;const baseline=m.result.release?.baseline;el('layout-baseline-title').textContent=baseline?'격자 기준안':'입력 배치';const feasible=check.report.passed&&m.result.status==='feasible';el('layout-chosen-title').textContent=feasible?'채택안':'검토용 출력';const improved=feasible&&m.result.release?.status==='improved';el('layout-baseline-phase').textContent=improved?'개선 전':'비교 전';el('layout-chosen-phase').textContent=improved?'개선 후':'비교 후';const comparisonInput=baseline?{...m.input,baseline}:m.input;views=[new ResultGeometry(el<HTMLCanvasElement>('result-before'),{input:comparisonInput},true),new ResultGeometry(el<HTMLCanvasElement>('result-after'),m,false)];flat(true);el('result-cell').textContent=m.sourceCell+' → '+m.workCell;el('run-downloads').hidden=false;el('verification-details').hidden=false;el('run-completed-stages').append(el('run-stages'));el('run-live-stages').hidden=true;for(const[key,url,file]of [['run-gds','/api/jobs/'+id+'/input',m.workCell+(check.report.passed?'':'_UNRESOLVED')+'.gds'],['run-report','/api/jobs/'+id+'/report','klayout-report.json'],['run-manifest','/api/pipeline/'+id+'/manifest','manifest.json'],['run-log','/api/pipeline/'+id+'/log','execution.log']]){const a=el<HTMLAnchorElement>(key!);a.href=url!;a.download=file!}if(m.result.release){
  const fields=el('release-fields')
  fields.hidden=false
  mountReleaseComparison(fields,m.input,m.result.release,check.report)
  el('release-fields').after(el('change-section'))
  for(const [name,label,file] of [['source','입력 GDS','source.gds'],['input','입력 규칙·잠금','design-input.json'],['model','모델 보고서','release-proof.json'],['candidates','격자와 후보군','release-candidates.json']]){
    const link=document.createElement('a');link.href='/api/pipeline/'+id+'/'+name;link.download=file!;link.textContent=label!;el('run-extra-downloads').append(link)
  }
  if(job.auditWindow?.state==='confirmed'){
    const audit=document.createElement('a')
    audit.href='/api/pipeline/'+id+'/audit';audit.download='audit-window.json';audit.textContent='Windows 목적값 검산 기록';el('run-extra-downloads').append(audit)
  }
  if(job.excel?.filename){
    const excel=document.createElement('a')
    excel.href='/api/pipeline/'+id+'/excel';excel.download=job.excel.filename;excel.textContent='Excel 검산·그래프 다운로드';el('run-extra-downloads').append(excel)
  }
  if(job.scilab?.report){
    const report=document.createElement('a')
    report.href='/api/pipeline/'+id+'/scilab';report.download='scilab-report.json';report.textContent='Scilab 독립 풀이 보고서';el('run-extra-downloads').append(report)
  }
  if(job.scilab?.error){
    const status=document.createElement('p')
    status.textContent='Scilab 단계 · '+job.scilab.error
    el('run-extra-downloads').append(status)
  }
  if(job.terminal?.error){
    const status=document.createElement('p')
    status.textContent='Windows Terminal · '+job.terminal.error
    el('run-extra-downloads').append(status)
  }
  if(job.excel?.error){
    const status=document.createElement('p')
    status.textContent='Excel 단계 · '+job.excel.error
    el('run-extra-downloads').append(status)
  }
  if(job.portableAudit){
    const audit=el<HTMLAnchorElement>('run-scipy')
    audit.href='/#crosscheck='+id
    audit.hidden=false
  }
}const coverage=m.result.coverage;if(coverage){const box=document.createElement('section');box.className='coverage-proof';const title=document.createElement('h2');title.textContent='접근 거리 검증';const body=document.createElement('p');body.textContent=coverage.status==='finite-candidate-optimum'&&coverage.before&&coverage.after?`고정한 ${coverage.fixedOtherPairs}쌍 · 허용 후보 ${coverage.candidatesEvaluated}곳 전수 비교 · 표본 ${coverage.sampleCount}점. 가장 먼 지점 ${(Math.sqrt(coverage.before.worstSquaredDbu)*m.dbuMicrometers).toFixed(2)} → ${(Math.sqrt(coverage.after.worstSquaredDbu)*m.dbuMicrometers).toFixed(2)} µm. 선택한 한 쌍의 후보 집합 내 최선${coverage.independentRankingVerified?' · 별도 계산 재검증':''}. 실제 식각 성공을 뜻하지 않습니다.`:'접근 거리 최적화 대상이 없어 기하 검사 결과만 표시합니다.';box.append(title,body);el('run-stages').parentElement?.append(box)}renderCoordinates(m);el('run-error').textContent=check.report.klayoutVersion+' · '+(check.guiOpenedConfirmed?'KLayout 작업 셀 열림 확인':check.guiOpenRequested?'KLayout 창 열기 요청':'KLayout 창 열기 생략');el('live-log').textContent+='\nOUTPUT SHA-256  '+job.outputSha256}
 }
 async function poll(){try{const job=await fetchJob(id);if(disposed)return;render(job);if(job.result&&rendered)el('run-error').textContent=job.result.check.report.klayoutVersion+' · '+(job.result.check.guiOpenedConfirmed?'KLayout 작업 셀 열림 확인':job.result.check.guiOpenRequested?'KLayout 창 열기 요청':'KLayout 창 열기 생략');if(job.status==='running'||(job.result?.check.guiOpenRequested&&!job.result.check.guiOpenedConfirmed&&viewerPolls++<120))timer=setTimeout(()=>void poll(),job.status==='running'?300:1000)}catch(e){if(!disposed)el('run-error').textContent=e instanceof Error?e.message:String(e)}}
 if(id!=='pending')void poll()
 return()=>{disposed=true;if(timer)clearTimeout(timer);cancelAnimationFrame(replayFrame);liveView?.dispose();views.forEach(v=>v.dispose())}
}
