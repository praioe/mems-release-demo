import { pointBounds } from './boundary-data.ts'
import type { BoundaryCell, BoundaryInstance, BoundaryLayout, Bounds, Point } from './boundary-data.ts'

// [a,b,c,d,tx,ty]: x'=a*x+c*y+tx; y'=b*x+d*y+ty. Integer DBU only.
type Matrix = [number, number, number, number, number, number]
const identity: Matrix = [1, 0, 0, 1, 0, 0]
export const hierarchyLimits = { depth: 64, instances: 100000, polygons: 25000, points: 1000000 }
function checked(value: number): number {
  if (!Number.isSafeInteger(value)) throw new Error('계층 변환 결과가 정확한 정수 DBU 범위를 벗어났습니다.')
  return value
}
function exactSum(a: number, x: number, b: number, y: number, t = 0): number {
  const value = BigInt(a)*BigInt(x) + BigInt(b)*BigInt(y) + BigInt(t)
  return checked(Number(value))
}
function compose(p: Matrix, q: Matrix): Matrix {
  return [
    exactSum(p[0],q[0],p[2],q[1]), exactSum(p[1],q[0],p[3],q[1]),
    exactSum(p[0],q[2],p[2],q[3]), exactSum(p[1],q[2],p[3],q[3]),
    exactSum(p[0],q[4],p[2],q[5],p[4]), exactSum(p[1],q[4],p[3],q[5],p[5]),
  ]
}
function orientation(ref: BoundaryInstance): Matrix {
  if ((ref.flags & ~0x8000) !== 0) throw new Error('절대 배율·절대 회전 또는 예약 STRANS 플래그는 지원하지 않습니다.')
  if (ref.magnification === null || !Number.isSafeInteger(ref.magnification) || ref.magnification < 1) throw new Error('현재 계층 보기는 양의 정수 배율만 지원합니다. 직접 도형 보기로 확인해 주세요.')
  if (ref.angle === null || ref.angle % 90 !== 0) throw new Error('현재 계층 보기는 90도 단위 회전만 지원합니다. 원본 도형 보기로 확인해 주세요.')
  const quarter = ((ref.angle / 90) % 4 + 4) % 4
  const rotations: Matrix[] = [[1,0,0,1,0,0], [0,1,-1,0,0,0], [-1,0,0,-1,0,0], [0,-1,1,0,0,0]]
  const rotation = rotations[quarter]!
  const oriented = ref.flags & 0x8000 ? compose(rotation, [1,0,0,-1,0,0]) : [...rotation] as Matrix
  return compose(oriented, [ref.magnification,0,0,ref.magnification,0,0])
}
function union(a: Bounds | null, b: Bounds): Bounds {
  return a ? { minX: Math.min(a.minX,b.minX), minY: Math.min(a.minY,b.minY), maxX: Math.max(a.maxX,b.maxX), maxY: Math.max(a.maxY,b.maxY) } : {...b}
}
export function expandBoundaryCell(layout: BoundaryLayout, cellName: string): BoundaryCell {
  const result: BoundaryCell = { name: cellName, boundaries: [], omitted: {}, bounds: null, viewMode: 'expanded', expandedInstances: 0 }
  let points = 0
  const active = new Set<string>()
  function visit(name: string, transform: Matrix, path: string, depth: number) {
    if (depth > hierarchyLimits.depth) throw new Error('하위 셀 깊이가 현재 한도 64단계를 넘었습니다.')
    if (active.has(name)) throw new Error('순환 셀 참조를 발견했습니다: ' + name)
    const cell = layout.cells.get(name)
    if (!cell) throw new Error('참조한 하위 셀이 파일에 없습니다: ' + name)
    active.add(name)
    for (const [kind,count] of Object.entries(cell.omitted)) if (kind !== 'SREF' && kind !== 'AREF') result.omitted[kind] = checked((result.omitted[kind] ?? 0) + count)
    for (const shape of cell.boundaries) {
      points += shape.points.length
      if (result.boundaries.length >= hierarchyLimits.polygons || points > hierarchyLimits.points) throw new Error('펼친 도형이 현재 한도인 다각형 25,000개 또는 좌표 100만 점을 넘었습니다.')
      const transformed: Point[] = shape.points.map(([x,y]) => [exactSum(transform[0],x,transform[2],y,transform[4]), exactSum(transform[1],x,transform[3],y,transform[5])])
      const bounds = pointBounds(transformed)
      result.boundaries.push({ ...shape, id: path + '|' + shape.id, sourceCell: name, sourceId: shape.id, instancePath: path, points: transformed, bounds })
      result.bounds = union(result.bounds, bounds)
    }
    for (const ref of layout.instances.get(name) ?? []) {
      const orient = orientation(ref)
      const origin = ref.points[0]!
      let columnStep: Point = [0,0], rowStep: Point = [0,0]
      if (ref.kind === 'AREF') {
        // GDS endpoints include N spacings, not N-1. They are already in parent axes.
        columnStep = [(ref.points[1]![0]-origin[0])/ref.columns, (ref.points[1]![1]-origin[1])/ref.columns]
        rowStep = [(ref.points[2]![0]-origin[0])/ref.rows, (ref.points[2]![1]-origin[1])/ref.rows]
        if (![...columnStep,...rowStep].every(Number.isSafeInteger)) throw new Error('정수 DBU로 표현할 수 없는 배열 간격입니다. 반올림하여 표시하지 않습니다.')
      }
      for (let row = 0; row < ref.rows; row++) for (let column = 0; column < ref.columns; column++) {
        result.expandedInstances!++
        if (result.expandedInstances! > hierarchyLimits.instances) throw new Error('펼친 셀 인스턴스 수가 현재 한도 100,000개를 넘었습니다.')
        const instance: Matrix = [...orient]
        instance[4] = checked(origin[0] + column*columnStep[0] + row*rowStep[0])
        instance[5] = checked(origin[1] + column*columnStep[1] + row*rowStep[1])
        visit(ref.cellName, compose(transform, instance), path + '/' + ref.recordOffset + '[' + column + ',' + row + ']', depth + 1)
      }
    }
    active.delete(name)
  }
  visit(cellName, identity, cellName, 0)
  return result
}
