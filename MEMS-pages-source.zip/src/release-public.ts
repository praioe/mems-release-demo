import './release-comparison.css'
import {mountReleaseComparison} from './release-comparison.ts'
import {solveReleaseReference} from './release-grid.ts'
import type {DesignInput} from './design-engine.ts'
import type {ReleaseProof} from './release-proof.ts'

interface Replay {
  input:DesignInput
  proof:ReleaseProof
  report:{passed:boolean;klayoutVersion:string;outputSha256:string;violations:unknown[]}
}

export function mountReleasePublic(root:HTMLElement) {
  const controller=new AbortController()
  const assets=import.meta.env.BASE_URL+'release-example/'
  root.innerHTML=`<main class="release-public">
    <nav><a href="#home">메인</a><a href="#workspace">브라우저 도면 작업</a></nav>
    <h1>보호 영역을 옮긴 뒤의 릴리스 홀 배치</h1>
    <p>합성 PLATES 셀의 동일한 63쌍을 비교합니다. 보호 영역 두 곳과 중심 홀 잠금을 적용했습니다.</p>
    <h2>Windows 검증 결과 재생</h2>
    <p>Python 모델 탐색, Node.js 독립 수치 검산, KLayout의 결과 GDS 검사 기록을 불러옵니다.</p>
    <a data-file="source.gds" download>입력 GDS</a><a data-file="output.gds" download>채택 GDS</a>
    <a data-file="klayout-report.json" download>KLayout 검사 보고서</a><a data-file="replay.json" download>모델과 좌표</a>
    <div data-comparison></div>
    <h2>브라우저에서 공급 지표 다시 계산</h2>
    <p>저장된 두 배치의 확산 길이를 바꿔 평가합니다. 워크스페이스에서는 브라우저의 기하 배치·보정과 GDS 내보내기를 사용할 수 있습니다. Python 배치 탐색과 KLayout 검사는 Windows 실행판에서 수행합니다.</p>
    <label>확산 길이 <select data-length><option>12</option><option selected>24</option><option>48</option></select> µm</label>
    <button data-calculate disabled>두 배치 계산</button><output role="status">검증 기록을 읽는 중</output>
    </main>`
  const get=<T extends HTMLElement=HTMLElement>(selector:string)=>root.querySelector<T>(selector)!
  for(const link of root.querySelectorAll<HTMLAnchorElement>('[data-file]'))link.href=assets+link.dataset.file
  const calculate=get<HTMLButtonElement>('[data-calculate]')
  const status=get('output[role=status]')
  void (async()=>{
    try{
      const response=await fetch(assets+'replay.json',{signal:controller.signal})
      if(!response.ok)throw Error('검증 기록 HTTP '+response.status)
      const {input,proof,report}=await response.json() as Replay
      if(controller.signal.aborted)return
      mountReleaseComparison(get('[data-comparison]'),input,proof,report)
      status.textContent='확산 길이를 선택하고 공급 지표를 계산할 수 있습니다.'
      calculate.disabled=false
      calculate.onclick=()=>{
        const length=Number(get<HTMLSelectElement>('[data-length]').value)
        try{
          const before=solveReleaseReference(proof.grid,proof.baseline,input.rules.lowerSize,length)
          const after=solveReleaseReference(proof.grid,proof.chosen,input.rules.lowerSize,length)
          status.textContent=`브라우저 계산 · ℓ ${length} µm · 제곱평균 부족도 ${before.objective.toFixed(5)} → ${after.objective.toFixed(5)} · 최대 부족도 ${before.worstDeficit.toFixed(5)} → ${after.worstDeficit.toFixed(5)}`
        }catch(error){status.textContent=String(error)}
      }
    }catch(error){if(!controller.signal.aborted)status.textContent=String(error)}
  })()
  return ()=>controller.abort()
}
