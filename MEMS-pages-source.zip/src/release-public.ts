import './release-comparison.css'
import {brand,icon} from './icons.ts'
import {mountReleaseComparison} from './release-comparison.ts'
import {solveReleaseReference} from './release-grid.ts'
import type {DesignInput} from './design-engine.ts'
import type {ReleaseProof} from './release-proof.ts'

interface Replay {
  input:DesignInput
  proof:ReleaseProof
  report:{passed:boolean;klayoutVersion:string;outputSha256:string;violations:unknown[]}
}

interface WindowsAudit {
  jobId:string
  report:{
    passed:boolean
    before:{objective:number;maxFieldDifference:number}
    after:{objective:number;maxFieldDifference:number}
    gds:{passed:boolean;layers:{layer:string;found:number}[]}
  }
}

export function mountReleasePublic(root:HTMLElement) {
  const controller=new AbortController()
  let auditReportUrl:string|undefined
  const assets=import.meta.env.BASE_URL+'release-example/'
  root.innerHTML=`<main class="release-public">
    <nav aria-label="예제 화면"><a class="brand" href="#home">${brand}</a><a href="#workspace">워크스페이스 →</a></nav><header class="public-lead"><p class="editorial-label">검증 예제 · PLATES</p>
    <h1>보호 영역을 옮긴 뒤의 릴리스 홀 배치</h1>
    <p>합성 PLATES 셀의 동일한 63쌍을 비교합니다. 보호 영역 두 곳과 중심 홀 잠금을 적용했습니다.</p></header>
    <h2>Windows 검증 결과 재생</h2>
    <p>Python 모델 탐색, Node.js 독립 수치 검산, KLayout의 결과 GDS 검사 기록을 불러옵니다.</p>
    <div class="public-files"><a class="action-primary" data-file="output.gds" download>채택 GDS ${icon('down')}</a><a data-file="source.gds" download>입력 GDS</a>
    <a data-file="klayout-report.json" download>KLayout 검사 보고서</a><a data-file="replay.json" download>모델과 좌표</a></div>
    <div data-comparison></div>
    <h2>브라우저에서 공급 지표 다시 계산</h2>
    <p>저장된 두 배치의 확산 길이를 바꿔 평가합니다. 워크스페이스에서는 브라우저의 기하 배치·보정과 GDS 내보내기를 사용할 수 있습니다. Python 배치 탐색과 KLayout 검사는 Windows 실행판에서 수행합니다.</p>
    <label>확산 길이 <select data-length><option>12</option><option selected>24</option><option>48</option></select> µm</label>
    <button data-calculate disabled>두 배치 계산</button><output data-browser-status role="status">검증 기록을 읽는 중</output>
    <h2>같은 결과를 외부에서 검산</h2>
    <p>동일한 합성 예제의 수치와 GDS 홀 좌표를 SciPy와 KLayout Python API로 확인합니다.</p>
    <a href="https://colab.research.google.com/github/praioe/mems-release-demo/blob/main/MEMS-crosscheck.ipynb" target="_blank" rel="noopener">Google Colab에서 검산</a>
    <a data-notebook download>노트북 파일</a>
    <div data-windows-audit hidden>
      <button data-run-audit disabled>Windows에서 같은 검산 실행</button>
      <output data-audit-status role="status">로컬 환경 확인 중</output>
      <a data-audit-report download="mems-crosscheck-windows.json" hidden>Windows 검산 보고서</a>
    </div>
    </main>`
  const get=<T extends HTMLElement=HTMLElement>(selector:string)=>root.querySelector<T>(selector)!
  for(const link of root.querySelectorAll<HTMLAnchorElement>('[data-file]'))link.href=assets+link.dataset.file
  get<HTMLAnchorElement>('[data-notebook]').href=import.meta.env.BASE_URL+'release-audit/MEMS-crosscheck.ipynb'
  const calculate=get<HTMLButtonElement>('[data-calculate]')
  const status=get('[data-browser-status]')
  if(import.meta.env.BASE_URL==='/')void connectWindowsAudit()

  async function connectWindowsAudit(){
    const panel=get('[data-windows-audit]')
    const run=get<HTMLButtonElement>('[data-run-audit]')
    const auditStatus=get('[data-audit-status]')
    const link=get<HTMLAnchorElement>('[data-audit-report]')
    try{
      const response=await fetch('/api/runtime',{signal:controller.signal,cache:'no-store'})
      if(!response.ok)return
      const runtime=await response.json() as {auditAvailable?:boolean;token?:string}
      if(!runtime.token||controller.signal.aborted)return
      panel.hidden=false
      if(!runtime.auditAvailable){
        auditStatus.textContent='start-audit.cmd를 한 번 실행한 다음 이 화면을 새로고침하세요.'
        return
      }
      run.disabled=false
      auditStatus.textContent='이 PC의 Python에서 검산을 실행합니다.'
      run.onclick=async()=>{
        run.disabled=true
        link.hidden=true
        if(auditReportUrl){URL.revokeObjectURL(auditReportUrl);auditReportUrl=undefined}
        auditStatus.textContent='Windows 검산 실행 중…'
        try{
          const result=await fetch('/api/release-example/audit',{method:'POST',
            headers:{'X-Mems-Token':runtime.token!},signal:controller.signal})
          const data=await result.json() as WindowsAudit&{error?:string}
          if(!result.ok)throw Error(data.error??'Windows 검산 실패')
          if(controller.signal.aborted)return
          const {report}=data
          const delta=Math.max(report.before.maxFieldDifference,report.after.maxFieldDifference)
          const layers=report.gds.layers.map(row=>`${row.layer} ${row.found}개`).join(' / ')
          auditStatus.textContent=`${report.passed?'검산 통과':'검산 미통과'} · 목적값 ${report.before.objective.toFixed(8)} → ${report.after.objective.toFixed(8)} · 최대 |Δc| ${delta.toExponential(2)} · GDS ${report.gds.passed?'일치':'불일치'} (${layers}) · 실행 ID ${data.jobId}`
          auditReportUrl=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}))
          link.href=auditReportUrl
          link.hidden=false
        }catch(error){
          if(!controller.signal.aborted)auditStatus.textContent=String(error)
        }finally{run.disabled=false}
      }
    }catch{ /* A static preview may not have the Windows API. */ }
  }
  void (async()=>{
    try{
      const response=await fetch(assets+'replay.json',{signal:controller.signal})
      if(!response.ok)throw Error('검증 기록 HTTP '+response.status)
      const {input,proof,report}=await response.json() as Replay
      if(controller.signal.aborted)return
      mountReleaseComparison(get('[data-comparison]'),input,proof,report)
      status.textContent='확산 길이를 선택하고 공급 지표를 계산할 수 있습니다.'
      calculate.disabled=false
      calculate.onclick=()=>{
        const length=Number(get<HTMLSelectElement>('[data-length]').value)
        try{
          const before=solveReleaseReference(proof.grid,proof.baseline,input.rules.lowerSize,length)
          const after=solveReleaseReference(proof.grid,proof.chosen,input.rules.lowerSize,length)
          status.textContent=`브라우저 계산 · ℓ ${length} µm · 제곱평균 부족도 ${before.objective.toFixed(5)} → ${after.objective.toFixed(5)} · 최대 부족도 ${before.worstDeficit.toFixed(5)} → ${after.worstDeficit.toFixed(5)}`
        }catch(error){status.textContent=String(error)}
      }
    }catch(error){if(!controller.signal.aborted)status.textContent=String(error)}
  })()
  return ()=>{
    controller.abort()
    if(auditReportUrl)URL.revokeObjectURL(auditReportUrl)
  }
}
