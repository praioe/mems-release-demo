/**
 * Step 1: bounded GDSII metadata inspection, not a geometry/DRC validator.
 * Does not flatten instances, edit polygons, or write a new GDS encoding.
 * All output downloads use the retained original bytes.
 */
export const MAX_GDS_BYTES = 16 * 1024 * 1024

export type ElementCounts = Record<string, number>
export interface CellSummary {
  name: string
  elements: ElementCounts
  children: string[]
}
export interface GdsSummary {
  version: number
  library: string
  dbuMicrometers: number
  userUnitMicrometers: number
  recordCount: number
  paddingBytes: number
  cells: CellSummary[]
  topCells: string[]
  layers: Array<{ layer: number; datatype: number; elements: number }>
  elements: ElementCounts
  notes: string[]
}
const elementNames = new Map([
  [0x08, 'BOUNDARY'], [0x09, 'PATH'], [0x0a, 'SREF'],
  [0x0b, 'AREF'], [0x0c, 'TEXT'], [0x15, 'NODE'], [0x2d, 'BOX'],
])
const increment = (counts: ElementCounts, name: string) => {
  counts[name] = (counts[name] ?? 0) + 1
}

export function inspectGds(bytes: Uint8Array): GdsSummary {
  if (bytes.byteLength > MAX_GDS_BYTES) throw new Error('현재 입력 점검은 16 MiB 이하의 GDS 파일을 지원합니다.')
  if (bytes.byteLength < 6) throw new Error('GDS 레코드를 읽기에는 파일이 너무 짧습니다.')
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
  const decoder = new TextDecoder('ascii')
  const cells = new Map<string, CellSummary>()
  const layerMap = new Map<string, { layer: number; datatype: number; elements: number }>()
  const elements: ElementCounts = {}
  let activeCell: CellSummary | null = null
  let activeElement: { name: string; layer: number | null; purpose: number | null; target: string | null; xy: boolean } | null = null
  let version: number | null = null
  let library: string | null = null
  let units: [number, number] | null = null
  let libraryStarted = false
  let libraryEnded = false
  let recordCount = 0
  let offset = 0

  function fail(message: string): never {
    throw new Error(message + ' (파일 위치 ' + offset + ' bytes)')
  }
  function readReal8(start: number): number {
    const first = bytes[start]!
    let mantissa = 0
    for (let i = 1; i <= 7; i++) mantissa += bytes[start + i]! / 256 ** i
    return (first & 0x80 ? -1 : 1) * mantissa * 16 ** ((first & 0x7f) - 64)
  }

  while (offset < bytes.byteLength && !libraryEnded) {
    if (offset + 4 > bytes.byteLength) fail('레코드 헤더가 중간에 잘렸습니다.')
    const length = view.getUint16(offset, false)
    const type = bytes[offset + 2]!
    const dataType = bytes[offset + 3]!
    if (length < 4 || length % 2 !== 0) fail('레코드 길이가 올바르지 않습니다.')
    if (offset + length > bytes.byteLength) fail('레코드 내용이 파일 끝에서 잘렸습니다.')
    if (offset === 0 && type !== 0x00) fail('GDSII HEADER로 시작하는 파일이 아닙니다. 압축 GDS와 OASIS는 아직 지원하지 않습니다.')
    const check = (expectedType: number, expectedLength?: number) => {
      if (dataType !== expectedType || (expectedLength !== undefined && length !== expectedLength)) fail('레코드 형식이 올바르지 않습니다: 0x' + type.toString(16))
    }
    const stringValue = () => {
      check(6)
      return decoder.decode(bytes.subarray(offset + 4, offset + length)).replace(/\0+$/, '')
    }
    const name = elementNames.get(type)
    if (name) {
      check(0, 4)
      if (!activeCell?.name || activeElement) fail('셀 또는 요소의 시작 순서가 올바르지 않습니다.')
      activeElement = { name, layer: null, purpose: null, target: null, xy: false }
    } else {
      switch (type) {
        case 0x00:
          check(2, 6)
          if (offset !== 0) fail('HEADER가 중복되었습니다.')
          version = view.getUint16(offset + 4, false)
          break
        case 0x01:
          check(2, 28)
          if (libraryStarted || version === null) fail('BGNLIB의 순서가 올바르지 않습니다.')
          libraryStarted = true
          break
        case 0x02:
          if (!libraryStarted || library !== null || activeCell) fail('LIBNAME의 순서가 올바르지 않습니다.')
          library = stringValue()
          if (!library) fail('라이브러리 이름이 비어 있습니다.')
          break
        case 0x03:
          check(5, 20)
          if (!library || units !== null || activeCell) fail('UNITS의 순서가 올바르지 않습니다.')
          units = [readReal8(offset + 4), readReal8(offset + 12)]
          if (!units.every(value => Number.isFinite(value) && value > 0)) fail('단위 값이 양의 유한수가 아닙니다.')
          break
        case 0x04:
          check(0, 4)
          if (!libraryStarted || activeCell || activeElement) fail('라이브러리가 닫히기 전에 셀이 끝나지 않았습니다.')
          libraryEnded = true
          break
        case 0x05:
          check(2, 28)
          if (!units || activeCell) fail('BGNSTR의 순서가 올바르지 않습니다.')
          activeCell = { name: '', elements: {}, children: [] }
          break
        case 0x06:
          if (!activeCell || activeCell.name) fail('STRNAME의 순서가 올바르지 않습니다.')
          activeCell.name = stringValue()
          if (!activeCell.name || cells.has(activeCell.name)) fail('셀 이름이 비어 있거나 중복되었습니다.')
          cells.set(activeCell.name, activeCell)
          break
        case 0x07:
          check(0, 4)
          if (!activeCell?.name || activeElement) fail('ENDSTR의 순서가 올바르지 않습니다.')
          activeCell = null
          break
        case 0x0d:
          check(2, 6)
          if (!activeElement || activeElement.layer !== null) fail('LAYER의 위치가 올바르지 않습니다.')
          activeElement.layer = view.getUint16(offset + 4, false)
          break
        case 0x0e:
        case 0x16:
        case 0x2a:
        case 0x2e:
          check(2, 6)
          if (!activeElement || activeElement.purpose !== null) fail('요소의 datatype/type 위치가 올바르지 않습니다.')
          activeElement.purpose = view.getUint16(offset + 4, false)
          break
        case 0x10:
          check(3)
          if (!activeElement || activeElement.xy || length < 12 || (length - 4) % 8 !== 0) fail('XY 좌표 레코드가 올바르지 않습니다.')
          activeElement.xy = true
          break
        case 0x12:
          if (!activeElement || !['SREF', 'AREF'].includes(activeElement.name) || activeElement.target !== null) fail('셀 참조 이름의 위치가 올바르지 않습니다.')
          activeElement.target = stringValue()
          break
        case 0x11: {
          check(0, 4)
          if (!activeCell || !activeElement || !activeElement.xy) fail('요소가 완성되기 전에 ENDEL이 나왔습니다.')
          const el = activeElement
          if (el.name === 'SREF' || el.name === 'AREF') {
            if (!el.target) fail('참조 대상 셀 이름이 없습니다.')
            activeCell.children.push(el.target)
          } else {
            if (el.layer === null || el.purpose === null) fail('레이어 또는 datatype/type 정보가 없습니다.')
            const key = el.layer + '/' + el.purpose
            let info = layerMap.get(key)
            if (!info) {
              info = { layer: el.layer, datatype: el.purpose, elements: 0 }
              layerMap.set(key, info)
            }
            info.elements++
          }
          increment(activeCell.elements, el.name)
          increment(elements, el.name)
          activeElement = null
          break
        }
        default:
          // Metadata-only stage. Unused attribute/extension payloads are retained
          // in the original bytes, and are not interpreted as validated geometry.
          break
      }
    }
    recordCount++
    offset += length
  }
  if (!libraryEnded || !library || !units || version === null) fail('필수 HEADER·LIBNAME·UNITS·ENDLIB를 모두 확인하지 못했습니다.')
  for (let i = offset; i < bytes.byteLength; i++) {
    if (bytes[i] !== 0) fail('ENDLIB 뒤에 0이 아닌 추가 데이터가 있습니다.')
  }
  const referenced = new Set<string>()
  for (const cell of cells.values()) {
    cell.children = [...new Set(cell.children)].sort()
    for (const child of cell.children) referenced.add(child)
  }
  const missing = [...referenced].filter(name => !cells.has(name))
  const notes = [
    '파일의 기본 레코드·단위·목록을 확인했습니다. 전체 GDS 문법, 도형 유효성, 설계 규칙은 아직 검사하지 않았습니다.',
    '요소 수는 셀 정의에 저장된 개수입니다. SREF·AREF를 펼친 전체 도형 수가 아닙니다.',
  ]
  if (missing.length) notes.push('정의되지 않은 참조 셀이 있습니다: ' + missing.slice(0, 10).join(', '))
  return {
    version,
    library,
    dbuMicrometers: units[1] * 1e6,
    userUnitMicrometers: units[1] / units[0] * 1e6,
    recordCount,
    paddingBytes: bytes.byteLength - offset,
    cells: [...cells.values()].sort((a, b) => a.name.localeCompare(b.name)),
    topCells: [...cells.keys()].filter(name => !referenced.has(name)).sort(),
    layers: [...layerMap.values()].sort((a, b) => a.layer - b.layer || a.datatype - b.datatype),
    elements,
    notes,
  }
}

