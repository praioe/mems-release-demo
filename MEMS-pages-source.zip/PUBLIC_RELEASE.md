# MEMS Release · GitHub Pages 게시 승인

제안 저장소는 소유 계정의 공개 `mems-release-demo`다. 예상 링크는 `https://<GitHub-계정>.github.io/mems-release-demo/#release-example`이다. 계정명과 공개 승인을 받은 뒤 저장소 생성 및 업로드, Pages의 GitHub Actions 연결, 수동 **Deploy MEMS Release demo** 실행 순서로 게시한다. 게시 후 별도 브라우저 세션에서 해당 링크를 직접 열어 예제·새로고침·계산·GDS와 검사 보고서 링크를 확인한다.

## 공개 범위

- `index.html`, Vite와 TypeScript 설정, `package.json` 및 잠금 파일, 브라우저 소스 `src/`, 수동 실행 워크플로 `.github/workflows/pages.yml`.
- `public/demo-paired.gds`, 폰트와 폰트 라이선스, `public/release-example/`의 합성 입력 GDS, KLayout이 검사한 출력 GDS, 검사 JSON, 좌표·모델 재생 JSON.
- 전체 파일 목록은 공개 소스 ZIP의 `PUBLIC_FILES.txt`에서 확인할 수 있다. 이 ZIP에는 사용자 GDS나 외부 배포 권한을 확인해야 하는 MUMPs 예제, `local-config.json`, `local-runs`, 로컬 로그/경로, 인증 토큰, Windows 실행 도구가 들어 있지 않다.

## 무료 호스팅과 실행 범위

GitHub Free의 GitHub Pages는 공개 저장소에서 정적 HTML/CSS/JS 호스팅을 지원한다. 커스텀 Actions 워크플로로 Vite의 `dist`를 게시한다. Pages의 사이트 크기 제한은 1 GB이고 월 소프트 대역폭 한도는 100 GB다. 정적 호스팅에서 브라우저 Worker의 기하 배치·보정, GDS 내보내기, 대표 두 배치의 공급도 재계산을 지원한다. Windows에서 생성한 검사 기록은 별도 재생으로 제공한다. [GitHub Pages 소개](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages), [Pages 제한](https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits), [Vite 정적 배포](https://vite.dev/guide/static-deploy)

무료 백엔드 후보로 Cloudflare Workers를 비교했다. 무료 플랜은 일반 HTTP 호출당 CPU 10 ms를 제공한다. 전체 최적화와 KLayout을 그 안에서 처리하려면 별도 컴퓨트 환경과 작업 큐가 필요하다. 시연의 재현성과 배포 단순성을 위해 대표 배치의 브라우저 재평가와 Windows 검사 기록의 재생을 선택했다. [Cloudflare Workers 실행 한도](https://developers.cloudflare.com/workers/platform/limits/)

게시 전 로컬에서 `npm.cmd run build:pages`로 빌드했다. HTTP 서버의 `/mems-release-demo/` 아래에 그대로 올려 해시 라우트 새로고침, 상대 경로의 Vite 자산·예제 GDS, 브라우저 기하 배치 63쌍, 확산 길이 48 µm에서 0.08602 → 0.08210 재계산을 확인했다.

## 게시 결과 · 2026년 11월 27일 한국시간

승인된 `praioe/mems-release-demo`에 공개 소스 ZIP을 올리고, 저장소의 워크플로가 ZIP을 푼 뒤 Node.js 24에서 빌드하도록 구성했다. GitHub Actions 배포 실행 #1이 성공했다. [공유용 공개 예제](https://praioe.github.io/mems-release-demo/#release-example), [공개 저장소](https://github.com/praioe/mems-release-demo), [배포 실행 기록](https://github.com/praioe/mems-release-demo/actions/runs/45868051598)

새 탭에서 공개 예제를 열어 기록 재생, 확산 길이 48 µm 재계산, 새로고침을 확인했다. 인증 헤더 없이 HTML과 입력·출력 GDS 및 KLayout 검사 보고서를 내려받았다. 두 GDS의 SHA-256은 검사 보고서와 일치했다. 출력은 `0552e001b5f93c78d2cfaa7fcf28211d1ffdb95c1f192ffb99a75b6b49a2b3d3`이다.
