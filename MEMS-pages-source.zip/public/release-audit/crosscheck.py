"""Check the published MEMS specimen with SciPy and the standalone KLayout API."""
from collections import Counter
import argparse
from hashlib import sha256
import json
from pathlib import Path
from time import perf_counter

import klayout.db as kdb
from importlib.metadata import version
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

FIELD_TOLERANCE = 1e-8
RESIDUAL_TOLERANCE = 1e-10


def solve(grid, holes, size, settings):
    cells = grid["cells"]
    step = grid["step"]
    coordinates = np.array([(cell["x"], cell["y"]) for cell in cells])
    centers = np.array([(hole["x"], hole["y"]) for hole in holes]).reshape(-1, 2)
    half = np.array([hole.get("lowerSize", size) for hole in holes])[:, None] / 2
    widths = np.maximum(
        0,
        np.minimum(coordinates[:, None] + step / 2, centers + half)
        - np.maximum(coordinates[:, None] - step / 2, centers - half),
    )
    covered_area = np.prod(widths, axis=2).sum(axis=1)
    rhs = np.array([2 * cell["open"] for cell in cells], dtype=float)
    rhs += settings["exchange"] * covered_area / step**2
    beta = (step * grid["dbu"] / settings["diffusionLengthUm"]) ** 2
    diagonal = np.array([len(cell["neighbors"]) for cell in cells]) + rhs + beta
    neighbors = [(i, j) for i, cell in enumerate(cells) for j in cell["neighbors"]]
    rows, cols, data = list(range(len(cells))), list(range(len(cells))), list(diagonal)
    for first, second in neighbors:
        rows.append(first)
        cols.append(second)
        data.append(-1)
    matrix = coo_matrix((data, (rows, cols)), shape=(len(cells), len(cells))).tocsc()
    field = spsolve(matrix, rhs, use_umfpack=False)
    if not np.isfinite(field).all():
        raise ValueError("The sparse solver returned a non-finite field.")
    return field, float(np.abs(matrix @ field - rhs).max())


def check_field(grid, holes, size, settings, expected):
    field, residual = solve(grid, holes, size, settings)
    if field.shape != np.asarray(expected["values"]).shape:
        raise ValueError("Reference field length differs from the recorded grid.")
    objective = float(np.mean((1 - field) ** 2))
    field_error = float(np.max(np.abs(field - expected["values"])))
    objective_error = abs(objective - expected["objective"])
    return {
        "objective": objective,
        "referenceObjective": expected["objective"],
        "worstDeficit": float(1 - field.min()),
        "maxFieldDifference": field_error,
        "objectiveDifference": objective_error,
        "maxEquationResidual": residual,
        "passed": max(field_error, objective_error) <= FIELD_TOLERANCE
        and residual <= RESIDUAL_TOLERANCE,
    }


def check_gds(folder, design, proof, expected):
    layout = kdb.Layout()
    layout.read(str(folder / "output.gds"))
    cell = layout.cell(expected["workCell"])
    if cell is None:
        raise ValueError("The work cell is absent from the output GDS.")
    layers = []
    for label, size_key in zip(design["holeLayers"], ["lowerSize", "upperSize"]):
        layer, datatype = map(int, label.split("/"))
        index = layout.find_layer(layer, datatype)
        boxes = Counter()
        non_rectangles = 0
        for shape in ([] if index is None or index < 0 else cell.shapes(index).each()):
            if shape.is_box():
                box = shape.box
            elif shape.is_polygon() and shape.polygon.is_box():
                box = shape.bbox()
            else:
                non_rectangles += 1
                continue
            boxes[box.left + box.right, box.bottom + box.top, box.width(), box.height()] += 1
        planned = Counter()
        for hole in proof["chosen"]:
            size = hole.get(size_key, design["rules"][size_key])
            planned[2 * hole["x"], 2 * hole["y"], size, size] += 1
        layers.append({
            "layer": label,
            "expected": sum(planned.values()),
            "found": sum(boxes.values()) + non_rectangles,
            "missing": sum((planned - boxes).values()),
            "unexpected": sum((boxes - planned).values()) + non_rectangles,
            "passed": planned == boxes and non_rectangles == 0,
        })
    source_hash = sha256((folder / "source.gds").read_bytes()).hexdigest()
    output_hash = sha256((folder / "output.gds").read_bytes()).hexdigest()
    hashes_match = source_hash == expected["sourceSha256"] and output_hash == expected["outputSha256"]
    dbu_matches = abs(layout.dbu - proof["grid"]["dbu"]) < 1e-12
    return {
        "passed": hashes_match and dbu_matches and all(row["passed"] for row in layers),
        "workCell": cell.name,
        "sourceSha256": source_hash,
        "outputSha256": output_hash,
        "hashesMatch": hashes_match,
        "dbuMatches": dbu_matches,
        "layers": layers,
    }


def audit(folder):
    start = perf_counter()
    replay = json.loads((folder / "replay.json").read_text(encoding="utf-8"))
    design, proof = replay["input"], replay["proof"]
    expected_gds = json.loads((folder / "klayout-report.json").read_text(encoding="utf-8"))
    if replay["report"] != expected_gds:
        raise ValueError("The replay and the published KLayout report differ.")
    size = design["rules"]["lowerSize"]
    grid, settings = proof["grid"], proof["settings"]
    before = check_field(grid, proof["baseline"], size, settings, proof["before"])
    after = check_field(grid, proof["chosen"], size, settings, proof["after"])
    gds = check_gds(folder, design, proof, expected_gds)
    return {
        "schema": "mems-release-portable-audit-v1",
        "passed": before["passed"] and after["passed"] and gds["passed"],
        "scope": ["discrete-model-field", "gds-layer-coordinates-and-sizes", "gds-sha256"],
        "solver": "SciPy spsolve (SuperLU)",
        "versions": {name: version(name) for name in ("numpy", "scipy", "klayout")},
        "cells": len(grid["cells"]),
        "diffusionLengthUm": settings["diffusionLengthUm"],
        "fieldTolerance": FIELD_TOLERANCE,
        "residualTolerance": RESIDUAL_TOLERANCE,
        "before": before,
        "after": after,
        "gds": gds,
        "elapsedMs": round((perf_counter() - start) * 1000),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("case_directory", type=Path)
    parser.add_argument("--report", type=Path, required=True)
    arguments = parser.parse_args()
    result = audit(arguments.case_directory)
    arguments.report.parent.mkdir(parents=True, exist_ok=True)
    arguments.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(
        f"{'PASS' if result['passed'] else 'FAIL'}: objective "
        f"{result['before']['objective']:.8f} -> {result['after']['objective']:.8f}; "
        f"GDS {'matches' if result['gds']['passed'] else 'differs'}."
    )
    raise SystemExit(0 if result["passed"] else 2)
